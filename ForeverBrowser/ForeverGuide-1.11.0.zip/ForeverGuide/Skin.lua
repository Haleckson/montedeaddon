-- Путеводитель Forever: оформление окна (золотая рамка, свечение, кнопки, подсветка строк).
-- Все картинки лежат в папке Media аддона (TGA).

local ADDON, ns = ...
local MEDIA = "Interface\\AddOns\\" .. ADDON .. "\\Media\\"
local Skin = { MEDIA = MEDIA }
ns.Skin = Skin

-- Группа из 9 текстур (углы, края, центр), растягивается без искажения углов.
-- file — картинка tw×th, m — поле угла в пикселях картинки, cs — размер угла на экране.
function Skin.NineSlice(parent, file, tw, th, m, cs, layer, sub, inset)
    local g = { tex = {} }
    local L, R, T, B = m / tw, 1 - m / tw, m / th, 1 - m / th
    local coords = {
        { 0, L, 0, T }, { L, R, 0, T }, { R, 1, 0, T },
        { 0, L, T, B }, { L, R, T, B }, { R, 1, T, B },
        { 0, L, B, 1 }, { L, R, B, 1 }, { R, 1, B, 1 },
    }
    for i, c in ipairs(coords) do
        local t = parent:CreateTexture(nil, layer or "BACKGROUND", nil, sub or 0)
        t:SetTexture(file)
        t:SetTexCoord(c[1], c[2], c[3], c[4])
        g.tex[i] = t
    end
    local t, d = g.tex, inset or 0
    t[1]:SetPoint("TOPLEFT", -d, d); t[1]:SetSize(cs, cs)
    t[3]:SetPoint("TOPRIGHT", d, d); t[3]:SetSize(cs, cs)
    t[7]:SetPoint("BOTTOMLEFT", -d, -d); t[7]:SetSize(cs, cs)
    t[9]:SetPoint("BOTTOMRIGHT", d, -d); t[9]:SetSize(cs, cs)
    t[2]:SetPoint("TOPLEFT", t[1], "TOPRIGHT"); t[2]:SetPoint("BOTTOMRIGHT", t[3], "BOTTOMLEFT")
    t[8]:SetPoint("TOPLEFT", t[7], "TOPRIGHT"); t[8]:SetPoint("BOTTOMRIGHT", t[9], "BOTTOMLEFT")
    t[4]:SetPoint("TOPLEFT", t[1], "BOTTOMLEFT"); t[4]:SetPoint("BOTTOMRIGHT", t[7], "TOPRIGHT")
    t[6]:SetPoint("TOPLEFT", t[3], "BOTTOMLEFT"); t[6]:SetPoint("BOTTOMRIGHT", t[9], "TOPRIGHT")
    t[5]:SetPoint("TOPLEFT", t[1], "BOTTOMRIGHT"); t[5]:SetPoint("BOTTOMRIGHT", t[9], "TOPLEFT")
    function g:Show() for _, x in ipairs(self.tex) do x:Show() end end
    function g:Hide() for _, x in ipairs(self.tex) do x:Hide() end end
    function g:SetShown(v) if v then self:Show() else self:Hide() end end
    function g:SetVertexColor(r, gg, b, a) for _, x in ipairs(self.tex) do x:SetVertexColor(r, gg, b, a or 1) end end
    function g:SetAlpha(a) for _, x in ipairs(self.tex) do x:SetAlpha(a) end end
    return g
end

-- Тёмная скруглённая подложка под список/панель
function Skin.Panel(frame)
    return Skin.NineSlice(frame, MEDIA .. "panel", 32, 32, 10, 10, "BACKGROUND", -2)
end

-- Подсветка строки при наведении (слой HIGHLIGHT показывается игрой сам)
function Skin.Hover(button)
    return Skin.NineSlice(button, MEDIA .. "hover", 32, 32, 8, 7, "HIGHLIGHT")
end

-- Выбранная строка: золотая заливка и тонкая золотая рамка
function Skin.Sel(row)
    local g = Skin.NineSlice(row, MEDIA .. "sel", 32, 32, 8, 7, "BACKGROUND", 1)
    g:Hide()
    return g
end

-- Полоса-заголовок раздела
function Skin.Head(row)
    local g = Skin.NineSlice(row, MEDIA .. "head", 32, 32, 8, 7, "BACKGROUND", 1)
    g:Hide()
    return g
end

-- Окно/всплывающее меню: фон-градиент, золотая рамка и (по желанию) свечение вокруг
function Skin.Window(frame, glow, corner)
    local bg = frame:CreateTexture(nil, "BACKGROUND", nil, -7)
    bg:SetTexture(MEDIA .. "bg")
    bg:SetPoint("TOPLEFT", 3, -3)
    bg:SetPoint("BOTTOMRIGHT", -3, 3)
    local border = Skin.NineSlice(frame, MEDIA .. "frame", 64, 64, 16, corner or 16, "BORDER", 7)
    local gl
    if glow then
        gl = Skin.NineSlice(frame, MEDIA .. "glow", 128, 128, 48, 48, "BACKGROUND", -8, 26)
        gl:SetVertexColor(1, 0.62, 0.22, 0.55)
        gl.tex[5]:Hide() -- центр не нужен: светится только ореол вокруг окна
        -- цветные «неоновые» пятна внутри окна: розовое сверху справа, бирюзовое снизу слева
        local pink = frame:CreateTexture(nil, "BACKGROUND", nil, -6)
        pink:SetTexture(MEDIA .. "glow")
        pink:SetPoint("TOPRIGHT", -3, -3)
        pink:SetSize(520, 340)
        pink:SetVertexColor(1, 0.3, 0.62, 0.22)
        local cyan = frame:CreateTexture(nil, "BACKGROUND", nil, -6)
        cyan:SetTexture(MEDIA .. "glow")
        cyan:SetPoint("BOTTOMLEFT", 3, 3)
        cyan:SetSize(520, 340)
        cyan:SetVertexColor(0.1, 0.9, 0.85, 0.14)
    end
    return border, gl, bg
end

-- Кнопка в стиле аддона: красно-коричневый градиент, золотой текст;
-- LockHighlight — «нажатая» вкладка (ярче, белый текст).
function Skin.Button(b)
    b.skinBase = Skin.NineSlice(b, MEDIA .. "btn", 64, 32, 8, 7, "BACKGROUND")
    b.skinOn = Skin.NineSlice(b, MEDIA .. "btn_on", 64, 32, 8, 7, "BACKGROUND", 1)
    b.skinOn:Hide()
    b.skinHl = Skin.NineSlice(b, MEDIA .. "btn_hl", 64, 32, 8, 7, "HIGHLIGHT")
    local fs = b:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    fs:SetPoint("LEFT", 6, 0)
    fs:SetPoint("RIGHT", -6, 0)
    fs:SetWordWrap(false)
    b.skinText = fs
    if b.SetFontString then b:SetFontString(fs) end
    if b.SetNormalFontObject then pcall(b.SetNormalFontObject, b, "GameFontNormal") end
    if b.SetHighlightFontObject then pcall(b.SetHighlightFontObject, b, "GameFontHighlight") end
    if b.SetDisabledFontObject then pcall(b.SetDisabledFontObject, b, "GameFontDisable") end
    if b.SetPushedTextOffset then pcall(b.SetPushedTextOffset, b, 1, -1) end
    b.LockHighlight = function(self)
        self.skinOn:Show()
        self.skinBase:Hide()
        self.skinText:SetTextColor(1, 1, 1)
    end
    b.UnlockHighlight = function(self)
        self.skinOn:Hide()
        self.skinBase:Show()
        self.skinText:SetTextColor(1, 0.82, 0)
    end
    return b
end

-- Полоска шанса выпадения (розовый → оранжевый → жёлтый)
function Skin.Bar(row)
    local t = row:CreateTexture(nil, "ARTWORK")
    t:SetTexture(MEDIA .. "bar")
    t:SetHeight(4)
    t:Hide()
    return t
end

Skin.ICON = MEDIA .. "icon"
Skin.ICON_MM = MEDIA .. "icon_mm" -- компас без рамки для кнопки у миникарты
Skin.THUMB = MEDIA .. "thumb"
