-- Путеводитель Forever: добыча обычных монстров, которую ты сам видел в Forever.
-- Классическая таблица (DungeonTrash.lua) — это классика; здесь аддон запоминает, что реально
-- падает у тебя с обычных монстров в подземельях Forever (включая новые подземелья, где данных
-- ещё нет). Хранится в ForeverGuideDB.trash[ключ подземелья][id вещи] = { n = раз, m = id моба, t = время }.

local _, ns = ...
local L = ns.L

local bossIDs, bossItems
local function BuildBossIndex()
    if bossIDs then return end
    bossIDs, bossItems = {}, {}
    for key, bosses in pairs(ns.LOOT or {}) do
        bossItems[key] = {}
        for _, b in ipairs(bosses) do
            if b.id then bossIDs[b.id] = true end
            for _, it in ipairs(b.items or {}) do bossItems[key][it.id] = true end
        end
    end
end

local function Secret(v) return issecretvalue ~= nil and issecretvalue(v) end

local function Store()
    local root = ForeverGuideDB
    if not root then return nil end
    root.trash = root.trash or {}
    return root.trash
end

function ns.TrashSeenAll(key)
    local t = Store()
    return t and t[key]
end

function ns.TrashSeen(key, itemID)
    local t = ns.TrashSeenAll(key)
    return t and t[itemID]
end

local function NpcID(guid)
    if type(guid) ~= "string" or Secret(guid) then return nil end
    local kind, _, _, _, _, id = strsplit("-", guid)
    if kind == "Creature" or kind == "Vehicle" then return tonumber(id) end
end

local static = {}
local function InStatic(key, id)
    if not static[key] then
        static[key] = {}
        for _, it in ipairs((ns.TRASH and ns.TRASH[key]) or {}) do static[key][it.id] = true end
    end
    return static[key][id]
end

-- В каком подземелье мы: по мобу (знает крылья Монастыря, Забытого города, Стратхольма и Пика),
-- по номеру карты инстанса, а для новых подземелий Forever — по названию.
local lastKey, lastInstance
local function KeyByName(name)
    if type(name) ~= "string" or name == "" then return nil end
    for _, d in ipairs(ns.DUNGEONS or {}) do
        if d.en == name or d.ru == name or (ns.DungeonName and ns.DungeonName(d) == name) then return d.key end
    end
    for _, d in ipairs(ns.DUNGEONS or {}) do
        if d.new and ((d.ru and d.ru:find(name, 1, true)) or (d.en and d.en:find(name, 1, true))) then return d.key end
    end
end

local function CurrentKey(npc)
    local name, _, _, _, _, _, _, mapID = GetInstanceInfo()
    if lastInstance ~= mapID then lastInstance, lastKey = mapID, nil end
    local k = npc and ns.TRASH_NPC and ns.TRASH_NPC[npc]
    if k then lastKey = k; return k end
    local m = ns.TRASH_MAP and mapID and ns.TRASH_MAP[mapID]
    if type(m) == "string" then return m end
    if type(m) == "table" then
        for _, kk in ipairs(m) do if kk == lastKey then return kk end end
        return nil -- крыло пока не узнали
    end
    return KeyByName(name)
end

local counted = {} -- труп+вещь уже посчитаны (окно добычи открывают несколько раз)

local function ItemClass(id)
    local fn = (C_Item and C_Item.GetItemInfoInstant) or GetItemInfoInstant
    if not fn then return nil end
    local ok, _, _, _, _, _, classID = pcall(fn, id)
    if ok then return classID end
end

local function OnLoot()
    local inInstance, kind = IsInInstance()
    if not inInstance or kind ~= "party" then return end
    local store = Store()
    if not store then return end
    BuildBossIndex()
    for slot = 1, (GetNumLootItems() or 0) do
        local link = GetLootSlotLink(slot)
        local id = type(link) == "string" and not Secret(link) and tonumber(link:match("item:(%d+)"))
        if id then
            local _, _, _, _, quality, _, isQuest = GetLootSlotInfo(slot)
            local cls = ItemClass(id)
            if not isQuest and cls ~= 12 and ((quality or 0) >= 2 or cls == 9) then
                local src = { GetLootSourceInfo(slot) }
                for i = 1, #src, 2 do
                    local guid = src[i]
                    local npc = NpcID(guid)
                    if npc and not bossIDs[npc] and not counted[guid .. ":" .. id] then
                        local key = CurrentKey(npc)
                        if key and not (bossItems[key] and bossItems[key][id]) then
                            counted[guid .. ":" .. id] = true
                            store[key] = store[key] or {}
                            local e = store[key][id]
                            local first = not e
                            e = e or { n = 0 }
                            e.n, e.m, e.t = (e.n or 0) + 1, npc, time and time() or nil
                            store[key][id] = e
                            if first and not InStatic(key, id) and ns.Print then
                                ns.Print(string.format(L["Записал новую добычу с обычных монстров: %s"], link))
                            end
                        end
                    end
                end
            end
        end
    end
end

local ev = CreateFrame("Frame")
pcall(ev.RegisterEvent, ev, "LOOT_OPENED")
pcall(ev.RegisterEvent, ev, "PLAYER_ENTERING_WORLD")
ev:SetScript("OnEvent", function(_, event)
    if event == "LOOT_OPENED" then
        local ok, err = pcall(OnLoot)
        if not ok and ns.debug then print("ForeverGuide trash:", err) end
    else
        counted = {}
    end
end)

ns._trash = { CurrentKey = CurrentKey, OnLoot = OnLoot, KeyByName = KeyByName }
