ПУТЕВОДИТЕЛЬ FOREVER (Forever Guide) — версия 1.11.0
===================================================
(English and 中文 below.)

Помощник для World of Warcraft: Forever. Одно окно, четыре вкладки:

  ПОДЗЕМЕЛЬЯ   — все 35 подземелий: какие квесты взять, где начинается цепочка,
                 какая награда; добыча каждого босса и обычных монстров.
  ПОИСК ВЕЩЕЙ  — впиши название вещи и узнай, откуда она падает и с каким шансом.
  ПРОФЕССИИ    — все 12 профессий и ~2 500 рецептов Forever: реагенты, навык,
                 где выучить (тренер, торговец, добыча, Merchant's Favor).
  КНИГИ        — библиотечные книги на карте и прогресс сдачи. Можно выключить.

Открыть: команда /гид или кнопка-карта у миникарты (ПКМ по ней — сразу «Книги»).
Новое в 1.11.0: добыча с обычных монстров (трэша) во вкладке «Добыча» — вещи,
которые падают именно в этом подземелье, с шансом и мобом. Аддон ещё и сам
запоминает, что падает у тебя с трэша в Forever, — так появляется добыча и
для новых подземелий Forever.
Новое в 1.10.0: 10 языков — все, что есть в клиенте игры: English, Deutsch,
Español (EU), Español (AL), Français, Русский, 한국어, Português, 繁體中文, 简体中文.
Новое в 1.9.1: новый логотип — яркий компас; у миникарты теперь компас без рамки.
Новое в 1.9.0: новое оформление — золотая рамка со свечением, яркие вкладки,
подсветка строк и цветные полоски шанса в поиске; своя иконка аддона.
Кнопка «?» в окне — краткая справка.
Язык — по клиенту игры (все 10 языков клиента).
Сменить язык аддона: кнопка «Язык» вверху окна или /гид язык ru | en | de | fr | es | mx | pt | ko | zh | tw | авто.
После выбора аддон попросит перезагрузить интерфейс. Если язык аддона не совпадает с языком игры,
названия квестов, NPC, зон и вещей берутся из базы аддона (где перевода нет — по-английски).


УСТАНОВКА
1. В Battle.net выбери World of Warcraft: Forever → шестерёнка у кнопки «Играть»
   → «Показать в проводнике».
2. Открой Interface\AddOns (если папок нет — создай).
3. Если стояла старая версия, удали папку ForeverLibraryBooks.
4. Скопируй папку ForeverGuide. Должно получиться:
   ...\Interface\AddOns\ForeverGuide\ForeverGuide.toc
5. На экране выбора персонажа → «Модификации» → включи «Путеводитель Forever».
   Если он помечен как устаревший — галочка «Загружать устаревшие модификации».
После переименования настройки (положение кнопки, галочки) начнутся заново.
Прогресс по книгам и квестам не теряется — он берётся из самой игры.


ВКЛАДКА «ПОДЗЕМЕЛЬЯ»
Слева список по уровню. Цвет — насколько подходит тебе: красный — рано,
жёлтый — в самый раз, зелёный — легко, серый — давно пройдено.
Справа число «сделано/всего» квестов для твоей фракции и класса.

«Квесты» — значки:
  жёлтый «!»   можно взять сейчас (написано у кого и где);
  жёлтый «?»   квест в журнале — кому сдать;
  часики       сначала нужен предквест: «Сначала «…» (шаг 1 из 6): взять — NPC · зона x, y»;
  серый «!»    рано по уровню;
  галочка      сделано (видно с галочкой «Выполненные»).
ЛКМ по квесту — КАРТОЧКА: что сделать, вся цепочка с первого шага (у кого взять,
кому сдать, где стоят, что уже сделано) и награда: вещи на выбор/гарантированные,
деньги, репутация. ПКМ — метка маршрута на следующий шаг.
«Показать на карте» — квестодатели выбранного подземелья на карте мира.
«Метки на всё» — все точки в TomTom (без TomTom — ближайшая).

«Добыча» — боссы и их вещи со слотом и шансом. «НОВОЕ» — вещь из Forever.
Ниже — «Обычные монстры»: вещи, которые падают только в этом подземелье
(случайные зелёные вещи мира не показываю), шанс — с моба, у которого он выше
всего; наведи на вещь — увидишь моба. «замечено» и «×N» — то, что ты сам
видел в Forever (аддон записывает добычу с трэша, когда ты её открываешь).


ВКЛАДКА «ПОИСК ВЕЩЕЙ»
Пиши по-русски или по-английски, можно часть названия. Или поставь курсор
в поле и сделай Shift+клик по вещи в сумке/чате. Клик по вещи покажет:
  • с каких боссов подземелий Forever падает;
  • за какие квесты дают (и кто их выдаёт);
  • ВСЕХ мобов, сундуки, точки сбора, обворовывание, снятие шкур — с шансом.
Сортировка кнопками: «Для фарма» (шанс × сколько мобов), «Шанс», «Уровень»
(от маленьких; второй клик — от больших), «Зона».
Клик по мобу или квестодателю — метка маршрута. Дружественные тебе мобы скрыты.
Бонус: наведи на любую вещь в игре — внизу подсказки видно, откуда она.
Выключить это: /гид подсказки.


ВКЛАДКА «ПРОФЕССИИ» (новое в 1.7.0)
Слева профессии, у изученных виден твой навык. Справа все рецепты по навыку:
  цифры справа — навык: выучить / жёлтый / зелёный / серый;
  точка перед названием — цвет рецепта для твоего навыка (красный — рано);
  ★ — рецепт новый в Forever, ◆ — изменён по сравнению с классикой;
  ✓ — уже изучен (аддон запоминает рецепты, когда открываешь окно профессии).
Фильтры: поиск по рецепту или реагенту, раздел (зелья, латные перчатки…),
«Новые Forever», «Не изученные», «SoD» — рецепты из раздела Season of Discovery
(они есть в клиенте Forever, но учат ли им на бете — не подтверждено).
Клик по рецепту — карточка: что получишь, реагенты (сколько есть в сумках и банке),
как выучить: ближайшие тренеры твоей фракции (клик — метка), рецепт-предмет
с продавцами, добычей и ценой в Merchant's Favor. Клик по реагенту — поиск вещей:
где он падает. Кнопка «Ближайший тренер» — метка на тренера профессии.
В поиске вещей теперь видно, какой профессией вещь создаётся, какой рецепт учит
и в каких рецептах нужна.


ВКЛАДКА «КНИГИ»
Галочка «Книги включены» — если выключить, книг не будет на карте, миникарте
и в чате. Ниже — прогресс (до шеи 10, до кольца 20), настройки точек, кнопки
«Ближайшая книга», «Все несданные в TomTom», «Метка на библиотекаря» и список
всех 40 книг по маршруту. Клик по книге — метка.
Значки на карте: книга — не взята, часики — в сумке (неси), галочка — сдана,
красный крестик — только для другой фракции, «?» — твой библиотекарь.


КОМАНДЫ
/гид                 открыть/закрыть окно (ещё: /данж, /fguide)
/гид <подземелье>    сразу к нужному: /гид мк, /гид пещеры, /гид страт, /гид некро
/найти <вещь>        поиск вещи (ещё: /гид поиск <вещь>)
/гид подсказки       вкл/выкл источники вещей в подсказках
/гид кнопка          спрятать/показать кнопку у миникарты
/гид профы           вкладка «Профессии»
/гид язык <код>             язык аддона: ru, en, de, fr, es, mx, pt, ko, zh, tw, авто
/книги               прогресс по книгам в чат · /книги след — ближайшая книга
/книги выкл | вкл    выключить/включить книги · /книги окно — вкладка «Книги»


ОТКУДА ДАННЫЕ И ЧТО ПОМЕЧЕНО
Зелёная пометка — данные Forever, оранжевая — классическая база.
• Цвет, слот и уровень вещей — из клиента Forever (пока не загрузились —
  с Wowhead Forever). Forever поднял много наград подземелий до синих.
• Квесты и цепочки — база Questie для Forever + списки ForeverChanges.
  Выполнено или нет — спрашивается у игры, это всегда точно.
• Награды квестов — сверены с Forever для подземелий, открытых на бете;
  для остальных — классика, в карточке так и написано.
• Добыча боссов — списки Forever (ForeverChanges); проценты классические:
  своих Forever пока никто не публикует.
• Добыча обычных монстров — классическая база (classic-db): только мобы,
  которые есть в базе Forever, и только вещи, которые есть в Forever;
  шансы с учётом групп добычи. Плюс то, что ты сам увидел в Forever.
• Профессии — клиент Forever (сборка 1.60.1): рецепты, реагенты, пороги навыка,
  что новое и что изменено (снято с wowforevertalents.com). Тренеры — база Questie
  для Forever. Продавцы рецептов и добыча рецептов — классическая база (помечено).
  Сколько навыка тренер просит за рецепт «у тренера», знает только сервер —
  там стоит «?». Точка торговцев Merchant's Favor — по сообщениям с беты.
  Около 20 рецептов кожевничества и портняжного дела источник не отдал
  полностью — их пока нет в списке, добавлю с обновлением.
• Мировой дроп в поиске — классическая база (classic-db), шансы посчитаны
  с учётом групп добычи. Аддоны не могут выходить в интернет, поэтому всё
  собрано заранее и лежит внутри аддона.
• Опыт за квесты не показываю: в Forever его дают больше, чем в классике.
• Подземелья 30+ (Excavation Site, Dalaran, Drowned City, Krol'dok, Alcaz,
  Blackmaw, Shaper's Terrace) на бете ещё закрыты — добычи пока нет.
• Книги: «Кровавое колдовство» и «Каменный эскиз» — точки примерные;
  8 книг сета 60 в SoD сдавались учителю магии, в Forever это не проверено.

На английском и китайском клиенте названия квестов, NPC и вещей берутся
из локализации игры (база Questie); у новых квестов Forever перевода ещё нет —
они показываются по-английски.

Проверено на макетах игрового API. Если увидишь ошибку Lua — пришли её текст.
Данные: QuestieDB (Forever), ForeverChanges, Wowhead Forever, wowforeverbuilds,
cmangos classic-db. Сентябрь 2026.


=====================================================================
FOREVER GUIDE (English) — version 1.11.0
=====================================================================
A helper for World of Warcraft: Forever. One window, four tabs:

  DUNGEONS     — all 35 dungeons: which quests to take, where each chain
                 starts, the rewards; boss and trash loot.
  ITEM SEARCH  — type an item name to see where it drops and the chance.
  PROFESSIONS  — all 12 professions and ~2,500 Forever recipes: reagents,
                 skill levels, where to learn (trainer, vendor, drop,
                 Merchant's Favor). ★ new in Forever, ◆ changed.
  BOOKS        — library books on the map and turn-in progress. Can be
                 turned off.

New in 1.11.0: trash loot on the Loot tab — items that drop in that dungeon
specifically, with the chance and the mob. The addon also records what drops
for you from trash in Forever, so new Forever dungeons fill in as you play.
New in 1.10.0: 10 languages — every language of the game client: English,
Deutsch, Español (EU), Español (AL), Français, Русский, 한국어, Português,
繁體中文, 简体中文.
New in 1.9.1: a new logo (a bright compass); the minimap button now shows
just the compass.
Open it with /fguide or the map button by the minimap (right-click it for
Books). The "?" button in the window shows a short help.
The interface language follows your game client (all 10 client languages).
Pick another one with the "Language" button at the top of the window or
/fguide lang ru|en|de|fr|es|mx|pt|ko|zh|tw|auto
(the UI reloads). If it differs from the game language, quest, NPC, zone and
item names come from the addon's own data.

INSTALL
1. In Battle.net pick World of Warcraft: Forever -> the gear next to "Play"
   -> "Show in Explorer".
2. Open Interface\AddOns (create the folders if they don't exist).
3. Copy the ForeverGuide folder so you get
   ...\Interface\AddOns\ForeverGuide\ForeverGuide.toc
4. On the character screen -> AddOns -> enable "Forever Guide". If it's
   marked out of date, tick "Load out of date AddOns".

COMMANDS
/fguide                 open/close the window (also /dungeons)
/fguide <dungeon>       jump to a dungeon: /fguide deadmines, /fguide strat
/flfind <item>          item search (also /fguide search <item>)
/fguide tips            item sources in tooltips on/off
/fguide button          hide/show the minimap button
/fguide prof            the Professions tab
/fguide lang <code>     addon language: ru, en, de, fr, es, mx, pt, ko, zh, tw or auto
/books                  book progress in chat · /books next — nearest book
/books off | on         turn books off/on · /books window — the Books tab

WHERE THE DATA COMES FROM
Green label — Forever data, orange — Classic database.
- Item quality, slot and level come from the Forever client (Wowhead
  Forever until the item loads). Forever made many dungeon rewards blue.
- Quests and chains: Questie's Forever database + ForeverChanges lists.
  Completed or not is asked from the game, so it's always right.
- Quest rewards are checked against Forever for dungeons open on the
  beta; for the rest it's Classic data, and the quest card says so.
- Boss loot: Forever lists (ForeverChanges); drop chances are Classic,
  Forever hasn't published its own yet.
- Trash loot: Classic database (classic-db), only mobs and items that exist
  in Forever, chances with loot groups; plus what you saw drop in Forever.
- World drops in search: Classic database (classic-db), chances computed
  with loot groups. Addons can't go online, so everything is bundled.
- Professions: Forever client build 1.60.1 (recipes, reagents, skill levels,
  new/changed markers, via wowforevertalents.com); trainers from Questie's
  Forever database; recipe vendors/drops from the Classic database (labelled).
  Trainer skill requirements live on the server and show as "?".
- Quest XP is not shown: Forever gives more than Classic.
- New Forever quests have no Chinese translation yet — shown in English.

=====================================================================
Forever指南（中文）— 版本 1.11.0
=====================================================================
魔兽世界：Forever 助手。一个窗口，四个标签页：
  地下城 —— 全部35个地下城：接哪些任务、任务链从哪里开始、奖励；首领和普通怪物掉落。
  物品搜索 —— 输入物品名称，查看掉落来源和几率。
  专业 —— 全部12个专业和约2500个Forever配方：材料、技能、学习途径。
  书籍 —— 地图上的图书馆书籍和上交进度，可以关闭。
1.11.0 新增：「掉落」标签页显示普通怪物（小怪）掉落——仅本地下城特有的物品，附几率和怪物；插件还会记录你在Forever中从小怪获得的掉落。
1.10.0 新增：支持游戏客户端的全部10种语言（English、Deutsch、Español、Français、Русский、한국어、Português、繁體中文、简体中文）。
1.9.1 新增：新图标（彩色罗盘），小地图按钮只显示罗盘。
打开：/fguide 或小地图旁的地图按钮（右键直接打开「书籍」）。
界面语言跟随游戏客户端（支持全部10种客户端语言）。
也可以手动切换：窗口顶部的「语言」按钮或 /fguide lang zh | tw | en | ru | de | fr | es | mx | pt | ko | auto（需重新载入界面）。
命令：/fguide · /fguide <地下城> · /flfind <物品> · /fguide prof · /fguide tips · /books
绿色标记——Forever数据，橙色——经典旧世数据库。Forever新增的任务暂无中文名，
以英文显示。
