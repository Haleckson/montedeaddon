-- Поиск вещей: откуда падает и с каким шансом.
-- Источники: добыча боссов подземелий Forever и награды квестов Forever (DungeonLoot/DungeonData),
-- мировой дроп, сундуки/сбор, обворовывание и снятие шкур — из классической базы (ItemSearchData).

local ADDON, ns = ...
local L = ns.L
local DName = ns.DungeonName

local SI_ITEM, SI_NPC, SI_OBJ, SI_QUEST = ns.SI_ITEM or {}, ns.SI_NPC or {}, ns.SI_OBJ or {}, ns.SI_QUEST or {}
local MAX_RESULTS = 150

local function U() return ns._ui end
local function Print(msg) if ns.Print then ns.Print(msg) end end
local function PlayerFac() return UnitFactionGroup("player") == "Alliance" and "A" or "H" end

---------------------------------------------------------------------------
-- Разбор данных
---------------------------------------------------------------------------

local function Split(s)
    local t, i = {}, 1
    for part in (s .. "\t"):gmatch("([^\t]*)\t") do
        t[i] = part
        i = i + 1
    end
    return t
end

local itemCache = {}
local function ItemRec(id)
    local r = itemCache[id]
    if r ~= nil then return r or nil end
    local s = SI_ITEM[id]
    if not s then itemCache[id] = false return nil end
    local f = Split(s)
    r = { en = f[1], ru = f[2] ~= "" and f[2] or nil, src = {} }
    for kind, body in (f[4] or ""):gmatch("(%a+)=([^;]*)") do
        local list = { more = 0 }
        for tok in body:gmatch("[^,]+") do
            local more = tok:match("^%+(%d+)$")
            if more then
                list.more = tonumber(more)
            elseif kind == "q" then
                local qid, c = tok:match("^(%d+)(c?)$")
                if qid then list[#list + 1] = { id = tonumber(qid), choice = c == "c" } end
            else
                local oid, pct, q = tok:match("^(%w+):([%d%.]+)(q?)$")
                if oid then list[#list + 1] = { id = tonumber(oid, 36), pct = tonumber(pct), quest = q == "q" } end
            end
        end
        r.src[kind] = list
    end
    itemCache[id] = r
    return r
end

local npcCache = {}
local function NpcRec(id)
    local r = npcCache[id]
    if r ~= nil then return r or nil end
    local s = SI_NPC[id]
    if not s then npcCache[id] = false return nil end
    local f = Split(s)
    r = {
        name = ns.Loc("n", id, f[2], f[1]),
        min = tonumber(f[3]) or 0, max = tonumber(f[4]) or 0, rank = tonumber(f[5]) or 0,
        map = tonumber(f[6]), x = tonumber(f[7]), y = tonumber(f[8]),
        dung = f[9] ~= "" and ns.InstName(f[9]) or nil, spawns = tonumber(f[10]) or 0, fr = f[11] or "",
    }
    if r.map == 0 then r.map = nil end
    npcCache[id] = r
    return r
end

local function ObjName(id)
    local s = SI_OBJ[id]
    if not s then return "#" .. id end
    local f = Split(s)
    return ns.Loc("o", id, f[2], f[1])
end

local function QuestRec(id)
    local s = SI_QUEST[id]
    if not s then return nil end
    local f = Split(s)
    return { name = ns.Loc("q", id, f[2], f[1]), lv = tonumber(f[3]), fa = f[4] ~= "" and f[4] or nil, giver = tonumber(f[5]) }
end

---------------------------------------------------------------------------
-- Индексы Forever (подземелья и награды квестов) и имена для поиска
---------------------------------------------------------------------------

local lootIndex, rewardIndex, nameIndex, extraNames

local function Add(t, k, v)
    local l = t[k]
    if not l then l = {} t[k] = l end
    l[#l + 1] = v
end

local function DungeonByKey(key)
    for _, d in ipairs(ns.DUNGEONS or {}) do if d.key == key then return d end end
end

local function BuildIndexes()
    if lootIndex then return end
    lootIndex, rewardIndex, extraNames = {}, {}, {}
    for key, bosses in pairs(ns.LOOT or {}) do
        for _, b in ipairs(bosses) do
            for _, it in ipairs(b.items or {}) do
                Add(lootIndex, it.id, { key = key, boss = b, pct = it.p, new = it.new })
                if not SI_ITEM[it.id] and not extraNames[it.id] then extraNames[it.id] = { en = it.n, ru = it.r } end
            end
        end
    end
    for qid, q in pairs(ns.DQ or {}) do
        if type(qid) == "number" and q.rw then
            for _, it in ipairs(q.rw.c or {}) do Add(rewardIndex, it[1], { id = qid, choice = #q.rw.c > 1, fv = q.rw.fv, dq = true }) end
            for _, it in ipairs(q.rw.i or {}) do Add(rewardIndex, it[1], { id = qid, choice = false, fv = q.rw.fv, dq = true }) end
        end
    end
    for id, it in pairs(ns.DRITEM or {}) do
        if not SI_ITEM[id] and not extraNames[id] then extraNames[id] = { en = it.n, ru = it.r } end
    end
    -- вещи из профессий Forever (созданные, реагенты, рецепты)
    for id, raw in pairs(ns.PNAME or {}) do
        if not SI_ITEM[id] and not extraNames[id] then
            local en, ru = raw:match("^([^\t]*)\t?(.*)$")
            if en and en ~= "" then extraNames[id] = { en = en, ru = (ru ~= "" and ru or nil) } end
        end
    end
end

local function BuildNameIndex()
    if nameIndex then return end
    BuildIndexes()
    local lower = U().LowerRU
    nameIndex = {}
    local zh = ns.LZ and ns.LZ.i or {} -- названия на выбранном языке (не только китайском)
    for id, s in pairs(SI_ITEM) do
        local en, ru = s:match("^([^\t]*)\t([^\t]*)")
        nameIndex[#nameIndex + 1] = { id = id, key = lower((ru or "") .. "\1" .. (en or "") .. "\1" .. (zh[id] or "")) }
    end
    for id, n in pairs(extraNames) do
        nameIndex[#nameIndex + 1] = { id = id, key = lower((n.ru or "") .. "\1" .. (n.en or "") .. "\1" .. (zh[id] or "")) }
    end
end

local function DisplayName(id)
    local n = ns.CachedItemName(id)
    if n then return n end
    local r = ItemRec(id)
    if r then return ns.Loc("i", id, r.en, r.ru) end
    local e = extraNames and extraNames[id]
    if e then return ns.Loc("i", id, e.en, e.ru) or ("#" .. id) end
    local d = ns.DRITEM and ns.DRITEM[id]
    if d then return ns.Loc("i", id, d.n, d.r) end
    return "#" .. id
end

local function Search(text)
    BuildNameIndex()
    text = strtrim(text or "")
    local id = tonumber(text:match("item:(%d+)") or text:match("^#?(%d+)$"))
    if id then return { id } end
    local q = U().LowerRU(text)
    local chars = #(q:gsub("[\128-\191]", ""))
    local cjk = q:find("[\228-\237]") ~= nil -- китайские иероглифы и корейский хангыль
    if chars < (cjk and 1 or 2) then return {} end
    local res = {}
    for _, e in ipairs(nameIndex) do
        local pos = e.key:find(q, 1, true)
        if pos then
            local wrapped = "\1" .. e.key .. "\1"
            local exact = wrapped:find("\1" .. q .. "\1", 1, true)
            local prefix = wrapped:find("\1" .. q, 1, true)
            res[#res + 1] = { id = e.id, score = (exact and 0 or (prefix and 1 or 2)) }
        end
    end
    table.sort(res, function(a, b)
        if a.score ~= b.score then return a.score < b.score end
        return DisplayName(a.id) < DisplayName(b.id)
    end)
    local out = {}
    for i = 1, math.min(#res, MAX_RESULTS) do out[i] = res[i].id end
    return out, #res
end

---------------------------------------------------------------------------
-- Источники предмета
---------------------------------------------------------------------------

local function RankName(r)
    return ({ [1] = L["элита"], [2] = L["редкий элита"], [3] = L["босс"], [4] = L["редкий"] })[r]
end

-- Сортировка списков мобов: "farm" (как в данных: шанс × сколько мобов), "chance", "level", "zone"
local sortMode, sortDesc = "farm", false

local NpcPlaceZone

local function FriendlyToMe(n)
    return n.fr ~= "" and n.fr:find(PlayerFac(), 1, true) ~= nil
end

local function NpcPlace(n)
    if n.dung then return n.dung end
    if n.map then
        if n.x then return string.format("%s %.0f, %.0f", ns.ZoneName(n.map), n.x, n.y) end
        return ns.ZoneName(n.map)
    end
    return ""
end

NpcPlaceZone = function(n)
    if n.dung then return n.dung end
    if n.map then return ns.ZoneName(n.map) end
    return "\255"
end

local function Levels(n)
    if n.min == 0 then return "" end
    if n.min == n.max then return tostring(n.min) end
    return n.min .. "–" .. n.max
end

local function PctText(p)
    if not p then return "|cff888888—|r" end
    return tostring(p) .. "%"
end

-- Строки источников: {kind="head"|"src"|"note", text, right, sub, action}
local function SourceRows(id)
    BuildIndexes()
    local rows = {}
    local function head(t) rows[#rows + 1] = { kind = "head", text = t } end
    local function note(t) rows[#rows + 1] = { kind = "note", text = t } end

    -- Профессии Forever: рецепт учит / вещь создаётся
    local function profRow(e)
        local r = e.r
        rows[#rows + 1] = {
            kind = "src", prof = true,
            text = ns.ProfName(e.key) .. ": " .. ns.ProfRecipeName(r) .. (r.st == "n" and " |cff73bfff★|r" or ""),
            right = L["навык "] .. (r.l or r.y or "?"),
            sub = r.tr and L["учит тренер"] or (r.mf and string.format(L["рецепт за Merchant's Favor: %d"], r.mf)) or L["по рецепту"],
            action = function() if ns.OpenRecipe then ns.OpenRecipe(e.key, r) end end, tipAction = L["открыть рецепт"],
        }
    end
    local teach = ns.ProfIndex and ns.ProfIndex("recipe", id)
    if teach then
        head(L["Учит рецепту |cff5fc48f(данные Forever)|r"])
        for _, e in ipairs(teach) do profRow(e) end
    end
    local made = ns.ProfIndex and ns.ProfIndex("item", id)
    if made then
        head(L["Создаётся профессией |cff5fc48f(данные Forever)|r"])
        for _, e in ipairs(made) do profRow(e) end
    end

    local li = lootIndex[id]
    if li then
        head(L["Подземелья Forever — добыча боссов"])
        for _, e in ipairs(li) do
            local d = DungeonByKey(e.key)
            local bn = ns.BossName(e.boss)
            rows[#rows + 1] = {
                kind = "src", text = bn .. " — " .. (d and DName(d) or e.key), right = PctText(e.pct),
                sub = e.pct and L["шанс — классический с Wowhead, в Forever свой пока не опубликован"] or (e.new and L["новая вещь Forever, шанс пока неизвестен"] or L["шанс неизвестен"]),
                action = function() if ns.OpenDungeonLoot then ns.OpenDungeonLoot(e.key) end end,
            }
        end
    end

    local rec = ItemRec(id)
    local quests, seen = {}, {}
    for _, e in ipairs(rewardIndex[id] or {}) do
        if not seen[e.id] then seen[e.id] = true quests[#quests + 1] = e end
    end
    for _, e in ipairs(rec and rec.src.q or {}) do
        if not seen[e.id] then seen[e.id] = true quests[#quests + 1] = { id = e.id, choice = e.choice } end
    end
    if #quests > 0 then
        head(L["Награда за квест"])
        for _, e in ipairs(quests) do
            local qr = QuestRec(e.id)
            local dq = ns.DQ and ns.DQ[e.id]
            local name = (dq and U().QuestName(e.id)) or (qr and qr.name) or ("#" .. e.id)
            local fa = (dq and dq.fa) or (qr and qr.fa)
            local lv = (dq and dq.lv) or (qr and qr.lv)
            local where = ""
            if qr and qr.giver then
                local n = NpcRec(qr.giver)
                if n then where = n.name .. (NpcPlace(n) ~= "" and (" · " .. NpcPlace(n)) or "") end
            end
            local src = e.fv and L["|cff5fc48fданные Forever|r"] or L["|cffff9f4cпо классике|r"]
            rows[#rows + 1] = {
                kind = "src", text = "«" .. name .. "»" .. (lv and (" [" .. lv .. "]") or "") .. (fa == "A" and L[" |cff4f8fff(Альянс)|r"] or fa == "H" and L[" |cffff4f4f(Орда)|r"] or ""),
                right = e.choice and L["на выбор"] or L["награда"],
                sub = (where ~= "" and (L["выдаёт: "] .. where .. " · ") or "") .. src,
                action = function()
                    if dq and ns.ShowQuestCard then
                        ns.ShowQuestCard(e.id)
                    elseif qr and qr.giver then
                        local n = NpcRec(qr.giver)
                        if n and n.map and n.x then
                            U().WaypointTarget({ map = n.map, x = n.x, y = n.y }, name .. " — " .. n.name)
                        else
                            Print(name .. L[": выдаёт "] .. (n and n.name or "?") .. (n and NpcPlace(n) ~= "" and (", " .. NpcPlace(n)) or "") .. ".")
                        end
                    end
                end,
            }
        end
    end

    local function sorted(list, isObj)
        local arr = {}
        for i, e in ipairs(list) do arr[i] = e; e.order = i end
        if sortMode == "farm" then return arr end
        local function key(e)
            if isObj then return nil end
            return NpcRec(e.id)
        end
        table.sort(arr, function(a, b)
            if sortMode == "chance" or isObj then
                if a.pct ~= b.pct then
                    if sortDesc or sortMode ~= "chance" then return a.pct > b.pct end
                    return a.pct < b.pct
                end
                return a.order < b.order
            end
            local na, nb = key(a), key(b)
            if not na or not nb then return (na and true or false) and not nb end
            if sortMode == "level" then
                local la = sortDesc and na.max or na.min
                local lb = sortDesc and nb.max or nb.min
                if la ~= lb then
                    if sortDesc then return la > lb end
                    return la < lb
                end
                if a.pct ~= b.pct then return a.pct > b.pct end
                return a.order < b.order
            end
            -- zone
            local za, zb = NpcPlaceZone(na), NpcPlaceZone(nb)
            if za ~= zb then return za < zb end
            if a.pct ~= b.pct then return a.pct > b.pct end
            return a.order < b.order
        end)
        return arr
    end

    local function listKind(kind, title, isObj)
        local list = rec and rec.src[kind]
        if not list or #list == 0 then return end
        head(title .. "  |cffaaaaaa— " .. #list .. "|r")
        local hidden, objSeen = 0, {}
        local pmax = 0
        for _, e in ipairs(list) do if e.pct and e.pct > pmax then pmax = e.pct end end
        for _, e in ipairs(sorted(list, isObj)) do
            if isObj then
                local on = ObjName(e.id)
                if not objSeen[on] then -- один и тот же тип сундука разных уровней: показываем лучший шанс
                    objSeen[on] = true
                    rows[#rows + 1] = { kind = "src", text = on, right = PctText(e.pct), pct = e.pct, pmax = pmax, sub = e.quest and L["только с квестом"] or nil }
                end
            else
                local n = NpcRec(e.id)
                if n and FriendlyToMe(n) then
                    hidden = hidden + 1
                elseif n then
                    local lv = Levels(n)
                    local tag = RankName(n.rank)
                    rows[#rows + 1] = {
                        kind = "src",
                        text = n.name .. (lv ~= "" and (" (" .. lv .. (tag and (", " .. tag) or "") .. ")") or ""),
                        right = PctText(e.pct), pct = e.pct, pmax = pmax,
                        sub = NpcPlace(n) .. (e.quest and L[" · только с квестом"] or "") .. (n.spawns > 0 and n.spawns < 3 and L[" · одиночный"] or ""),
                        action = function()
                            if n.map and n.x then
                                U().WaypointTarget({ map = n.map, x = n.x, y = n.y }, n.name)
                            else
                                Print(n.name .. ": " .. (NpcPlace(n) ~= "" and NpcPlace(n) or L["место неизвестно"]) .. ".")
                            end
                        end,
                    }
                end
            end
        end
        if list.more and list.more > 0 then note(L["…и ещё "] .. list.more .. L[" источников с меньшим шансом"]) end
        if hidden > 0 then note(hidden .. L[" — дружественные твоей фракции, скрыты"]) end
    end
    listKind("d", L["Выпадает с существ |cffff9f4c(классика)|r"])
    listKind("o", L["Сундуки и сбор |cffff9f4c(классика)|r"], true)
    listKind("pp", L["Обворовывание |cffff9f4c(классика)|r"])
    listKind("sk", L["Снятие шкур |cffff9f4c(классика)|r"])

    local used = ns.ProfIndex and ns.ProfIndex("reagent", id)
    if used then
        local arr = {}
        for i, e in ipairs(used) do arr[i] = e end
        table.sort(arr, function(a, b) return (a.r.l or a.r.y or 0) < (b.r.l or b.r.y or 0) end)
        head(L["Нужен в рецептах"] .. "  |cffaaaaaa— " .. #arr .. "|r")
        for i = 1, math.min(12, #arr) do profRow(arr[i]) end
        if #arr > 12 then note(L["…и ещё рецептов: "] .. (#arr - 12) .. L[" (вкладка «Профессии», поиск по реагенту)"]) end
    end

    if #rows == 0 then
        note(L["Откуда падает, в базе нет. Возможно, вещь продаётся у торговца,"])
        note(L["делается профессией или добавлена в Forever и её ещё никто не выбил."])
    end
    return rows
end

---------------------------------------------------------------------------
-- Строки в подсказке предмета (наведение на любую вещь в игре)
---------------------------------------------------------------------------

local function TooltipLines(id)
    BuildIndexes()
    local out = {}
    local li = lootIndex[id]
    if li and li[1] then
        local e = li[1]
        local d = DungeonByKey(e.key)
        out[#out + 1] = { "Forever: " .. ns.BossName(e.boss) .. " (" .. (d and DName(d) or e.key) .. ")" .. (e.pct and (" " .. e.pct .. "%") or ""), 0.37, 0.77, 0.56 }
    end
    local made = ns.ProfIndex and ns.ProfIndex("item", id)
    if made and made[1] then
        local r = made[1].r
        out[#out + 1] = { L["Создаётся: "] .. ns.ProfName(made[1].key) .. " (" .. (r.l or r.y or "?") .. ")", 0.37, 0.77, 0.56 }
    end
    local rw = rewardIndex[id]
    local rec = ItemRec(id)
    local qid = (rw and rw[1] and rw[1].id) or (rec and rec.src.q and rec.src.q[1] and rec.src.q[1].id)
    if qid then
        local dq = ns.DQ and ns.DQ[qid]
        local qr = QuestRec(qid)
        local name = (dq and U() and U().QuestName(qid)) or (qr and qr.name) or ("#" .. qid)
        out[#out + 1] = { L["Награда за квест: «"] .. name .. "»", 1, 0.82, 0 }
    end
    local d = rec and rec.src.d
    if d then
        local shown = 0
        for _, e in ipairs(d) do
            local n = NpcRec(e.id)
            if n and not FriendlyToMe(n) and shown < 2 then
                out[#out + 1] = { L["Падает (классика): "] .. n.name .. (NpcPlace(n) ~= "" and (" — " .. (n.dung or (n.map and ns.ZoneName(n.map)) or "")) or "") .. " " .. e.pct .. "%", 0.8, 0.8, 0.8 }
                shown = shown + 1
            end
        end
    end
    return out
end

local function OnTooltipItem(tt, id)
    if not id or ns.tipSuppress then return end
    local root = ForeverGuideDB
    if root and root.dq and root.dq.tipSources == false then return end
    local ok, lines = pcall(TooltipLines, id)
    if not ok or #lines == 0 then return end
    for _, l in ipairs(lines) do tt:AddLine(l[1], l[2], l[3], l[4], true) end
    return true
end

local function HookTooltips()
    if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType and Enum.TooltipDataType.Item then
        pcall(TooltipDataProcessor.AddTooltipPostCall, Enum.TooltipDataType.Item, function(tt, data)
            if tt == GameTooltip or tt == ItemRefTooltip then
                OnTooltipItem(tt, data and data.id)
            end
        end)
        return
    end
    for _, tt in ipairs({ GameTooltip, ItemRefTooltip }) do
        if tt and tt.HookScript then
            pcall(tt.HookScript, tt, "OnTooltipSetItem", function(self)
                local _, link = self:GetItem()
                local id = link and tonumber(link:match("item:(%d+)"))
                if OnTooltipItem(self, id) then self:Show() end
            end)
        end
    end
end

---------------------------------------------------------------------------
-- Панель поиска
---------------------------------------------------------------------------

local panel, box, list, info, back, sortBar
local sortButtons = {}
local mode, results, current, lastQuery = "results", {}, nil, ""

local function CreateRow(parent)
    local r = CreateFrame("Button", nil, parent)
    r:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    r.hl = ns.Skin.Hover(r)
    r.bg = ns.Skin.Head(r)
    r.icon = r:CreateTexture(nil, "ARTWORK")
    r.icon:SetSize(22, 22)
    r.icon:SetPoint("LEFT", 4, 0)
    r.text = r:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    r.text:SetJustifyH("LEFT")
    r.text:SetWordWrap(false)
    r.right = r:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    r.right:SetPoint("TOPRIGHT", -6, -4)
    r.right:SetJustifyH("RIGHT")
    r.sub = r:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    r.sub:SetJustifyH("LEFT")
    r.sub:SetWordWrap(false)
    r.pbar = ns.Skin.Bar(r) -- полоска шанса
    r:SetScript("OnClick", function(self)
        local d = self.data
        if not d then return end
        if d.kind == "item" then
            if IsShiftKeyDown() then
                local link = U().ItemLink(d.id)
                if link and ChatEdit_InsertLink then ChatEdit_InsertLink(link) end
                return
            end
            ns.ShowItemSources(d.id)
        elseif d.action then
            d.action()
        end
    end)
    r:SetScript("OnEnter", function(self)
        local d = self.data
        if not d then return end
        if d.kind == "item" or d.kind == "itemhead" then
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            ns.tipSuppress = true
            local ok = GameTooltip.SetItemByID and pcall(GameTooltip.SetItemByID, GameTooltip, d.id)
            ns.tipSuppress = false
            if not ok or GameTooltip:NumLines() == 0 then GameTooltip:SetText(DisplayName(d.id), 1, 1, 1) end
            GameTooltip:AddLine(d.kind == "item" and L["Клик — откуда падает · Shift+клик — ссылка в чат"] or L["Shift+клик по вещи в сумке или чате — искать её"], 0.45, 0.75, 1, true)
            GameTooltip:Show()
        elseif d.action then
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText(d.plain or d.text, 1, 1, 1, 1, true)
            if d.sub then GameTooltip:AddLine(d.sub, 0.8, 0.8, 0.8, true) end
            GameTooltip:AddLine(L["Клик — "] .. (d.tipAction or L["метка / открыть"]), 0.45, 0.75, 1)
            GameTooltip:Show()
        end
    end)
    r:SetScript("OnLeave", function() GameTooltip:Hide() end)
    return r
end

local function UpdateRow(r, d)
    r.pbar:Hide()
    r.bg:Hide()
    r.icon:Hide()
    r.text:ClearAllPoints()
    r.sub:ClearAllPoints()
    r.sub:SetText("")
    r.right:SetText("")
    if d.kind == "item" or d.kind == "itemhead" then
        r.icon:Show()
        r.icon:SetTexture(U().ItemIcon(d.id))
        local name = DisplayName(d.id)
        local hex = U().ItemQualityHex(d.id)
        if not hex then
            local di = ns.DRITEM and ns.DRITEM[d.id]
            if di and di.q and ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[di.q] then hex = ITEM_QUALITY_COLORS[di.q].hex end
            U().RequestItem(d.id)
        end
        if hex and hex:sub(1, 2) ~= "|c" then hex = "|c" .. hex end
        r.text:SetPoint("TOPLEFT", r.icon, "TOPRIGHT", 6, -1)
        r.text:SetPoint("RIGHT", r.right, "LEFT", -8, 0)
        r.text:SetText((hex or "|cffd8d8d8") .. name .. "|r")
        r.sub:SetPoint("TOPLEFT", r.text, "BOTTOMLEFT", 0, -2)
        r.sub:SetPoint("RIGHT", -6, 0)
        r.sub:SetText(U().ClientSlot(d.id) or "")
        if d.kind == "itemhead" then r.bg:Show() end
    elseif d.kind == "head" then
        r.bg:Show()
        r.text:SetPoint("LEFT", 8, 0)
        r.text:SetPoint("RIGHT", -8, 0)
        r.text:SetText("|cffffd100" .. d.text .. "|r")
    elseif d.kind == "note" then
        r.text:SetPoint("LEFT", 10, 0)
        r.text:SetPoint("RIGHT", -8, 0)
        r.text:SetText("|cff9a9a9a" .. d.text .. "|r")
    else
        r.text:SetPoint("TOPLEFT", 10, -4)
        r.text:SetPoint("RIGHT", r.right, "LEFT", -8, 0)
        r.text:SetText(d.text)
        r.right:SetText(d.right or "")
        if d.pct and d.pmax and d.pmax > 0 then
            local w = (r:GetWidth() or 0)
            if w < 100 then w = 500 end
            r.pbar:ClearAllPoints()
            r.pbar:SetPoint("BOTTOMLEFT", 10, 1)
            r.pbar:SetWidth(math.max(4, (w - 90) * math.min(1, d.pct / d.pmax)))
            r.pbar:Show()
        end
        if d.sub then
            r.sub:SetPoint("TOPLEFT", r.text, "BOTTOMLEFT", 0, -2)
            r.sub:SetPoint("RIGHT", -6, 0)
            r.sub:SetText(d.sub)
        end
    end
end

local function ShowResults()
    mode = "results"
    back:Hide()
    sortBar:Hide()
    info:Show()
    local rows = {}
    for _, id in ipairs(results) do rows[#rows + 1] = { kind = "item", id = id } end
    if #rows == 0 then
        if #strtrim(box:GetText() or "") < 2 then
            info:SetText(L["Введи название вещи (от 2 букв, можно по-русски или по-английски) или Shift+клик по вещи."])
        else
            info:SetText(L["Ничего не нашлось. Попробуй часть названия или английское название."])
        end
    end
    list:SetData(rows)
end

local function RunSearch(text)
    lastQuery = text or ""
    local res, total = Search(lastQuery)
    results = res
    if #res > 0 then
        info:SetText(string.format(L["Найдено: %d%s. Клик по вещи — откуда падает."], total or #res, (total or 0) > #res and (L[" (показаны первые "] .. #res .. ")") or ""))
    end
    if #res == 1 then
        ns.ShowItemSources(res[1])
        return
    end
    ShowResults()
end

local SORTS = {
    { mode = "farm", label = function() return L["Для фарма"] end },
    { mode = "chance", label = function(active) return active and not sortDesc and L["Шанс: мин"] or L["Шанс: макс"] end },
    { mode = "level", label = function(active) return active and sortDesc and L["Уровень: макс"] or L["Уровень: мин"] end },
    { mode = "zone", label = function() return L["Зона: А–Я"] end },
}

local function UpdateSortButtons()
    for i, def in ipairs(SORTS) do
        local b = sortButtons[i]
        if b then
            local active = sortMode == def.mode
            b:SetText(def.label(active))
            if active then b:LockHighlight() else b:UnlockHighlight() end
        end
    end
end

function ns.ShowItemSources(id, keepScroll)
    if not panel then return end
    current = id
    mode = "sources"
    back:Show()
    info:Hide()
    sortBar:Show()
    UpdateSortButtons()
    local rows = { { kind = "itemhead", id = id } }
    for _, r in ipairs(SourceRows(id)) do
        if r.kind == "src" then r.plain = r.text end
        rows[#rows + 1] = r
    end
    list:SetData(rows, keepScroll)
end

function ns.CreateSearchPanel(parent)
    panel = CreateFrame("Frame", nil, parent)
    local bg = ns.Skin.Panel(panel)

    box = CreateFrame("EditBox", "ForeverGuideSearchBox", panel, "InputBoxTemplate")
    box:SetAutoFocus(false)
    box:SetSize(300, 22)
    box:SetPoint("TOPLEFT", 12, -6)
    box:SetMaxLetters(80)
    local pending = 0
    box:SetScript("OnTextChanged", function(self, user)
        if not user then return end
        pending = pending + 1
        local token = pending
        C_Timer.After(0.35, function()
            if token == pending then RunSearch(self:GetText()) end
        end)
    end)
    box:SetScript("OnEnterPressed", function(self)
        RunSearch(self:GetText())
        self:ClearFocus()
    end)
    box:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)

    back = U().MakeButton(panel, L["« К результатам"], 130, function() ShowResults() end)
    back:SetPoint("LEFT", box, "RIGHT", 10, 0)
    back:Hide()

    info = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    info:SetPoint("TOPLEFT", box, "BOTTOMLEFT", -4, -6)
    info:SetPoint("RIGHT", -8, 0)
    info:SetJustifyH("LEFT")
    info:SetText(L["Введи название вещи (от 2 букв, можно по-русски или по-английски) или Shift+клик по вещи."])

    sortBar = CreateFrame("Frame", nil, panel)
    sortBar:SetPoint("TOPLEFT", box, "BOTTOMLEFT", -6, -4)
    sortBar:SetPoint("RIGHT", -6, 0)
    sortBar:SetHeight(22)
    local lbl = sortBar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    lbl:SetPoint("LEFT", 0, 0)
    lbl:SetText(L["Сортировка:"])
    local prev = lbl
    for i, def in ipairs(SORTS) do
        local b = U().MakeButton(sortBar, def.label(false), 106, function()
            if sortMode == def.mode then
                sortDesc = not sortDesc
            else
                sortMode = def.mode
                sortDesc = def.mode == "chance" -- шанс сразу от большего, уровень — от меньшего
            end
            if current then ns.ShowItemSources(current) end
        end)
        b:SetHeight(20)
        b:SetPoint("LEFT", prev, "RIGHT", i == 1 and 6 or 3, 0)
        sortButtons[i] = b
        prev = b
    end
    sortBar:Hide()

    list = U().CreateScrollList(panel, 36, CreateRow, UpdateRow)
    list:SetPoint("TOPLEFT", 2, -52)
    list:SetPoint("BOTTOMRIGHT", -2, 2)

    -- Shift+клик по вещи в сумке/чате, пока поле поиска в фокусе
    if hooksecurefunc then
        pcall(hooksecurefunc, "HandleModifiedItemClick", function(link)
            if box and box:HasFocus() and link and IsShiftKeyDown() then
                local id = tonumber(tostring(link):match("item:(%d+)"))
                if id then
                    box:SetText(DisplayName(id))
                    box:ClearFocus()
                    ns.ShowItemSources(id)
                end
            end
        end)
    end
    return panel
end

function ns.SearchRefresh()
    if not panel then return end
    if mode == "sources" and current then
        ns.ShowItemSources(current)
    else
        ShowResults()
    end
end

function ns.SearchSetQuery(text)
    if not box then return end
    box:SetText(text or "")
    RunSearch(text or "")
end

---------------------------------------------------------------------------

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:SetScript("OnEvent", function()
    HookTooltips()
end)

local function FindSlash(msg)
    msg = strtrim(msg or "")
    if ns.OpenSearch then ns.OpenSearch(msg) end
end
SLASH_FOREVERGUIDE_FIND1 = "/найти"
SLASH_FOREVERGUIDE_FIND2 = "/flfind"
SlashCmdList.FOREVERGUIDE_FIND = FindSlash

ns._search = { Search = Search, SourceRows = SourceRows, TooltipLines = TooltipLines, ItemRec = ItemRec }
