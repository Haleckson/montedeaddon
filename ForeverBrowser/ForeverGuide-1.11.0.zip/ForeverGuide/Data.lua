-- Путеводитель Forever (Forever Guide): данные библиотечных книг.
-- quest/item ID и точки взяты из базы Questie (Season of Discovery) и сверены
-- с ForeverChanges (бета Forever, сборка 1.60.1.69913, 22.09.2026).
-- spawns = { {uiMapID, x, y, approx} }, координаты в процентах, как на карте игры.

local _, ns = ...

-- ns.ADDON_TITLE и ns.ADDON_TAGLINE задаются в Locale.lua (по языку клиента).
ns.ADDON_ICON = "Interface\\Icons\\INV_Misc_Map_01"

-- uiMapID зон классического мира (те же в Forever)
local M = {
    TIRISFAL = 1420, SILVERPINE = 1421, UNDERCITY = 1458, ORGRIMMAR = 1454,
    BARRENS = 1413, STONETALON = 1442, NEEDLES = 1441, DUSTWALLOW = 1445,
    DARKSHORE = 1439, STV = 1434, DUSKWOOD = 1431, WESTFALL = 1436,
    ALTERAC = 1416, ARATHI = 1417, WETLANDS = 1437, LOCH_MODAN = 1432,
    SWAMP = 1435, BADLANDS = 1418, DESOLACE = 1443, BURNING_STEPPES = 1428,
    TANARIS = 1446, FERALAS = 1444, AZSHARA = 1447, HINTERLANDS = 1425,
    SEARING_GORGE = 1427, BLASTED_LANDS = 1419, ELWYNN = 1429,
    IRONFORGE = 1455, STORMWIND = 1453,
    WPL = 1422, EPL = 1423, FELWOOD = 1448, WINTERSPRING = 1452,
}
ns.MAPS = M

ns.LIBRARIANS = {
    Horde = {
        npc = 211022, name = "Оуэн Тадд", nameEN = "Owen Thadd",
        place = "Квартал Магов, Подгород", map = M.UNDERCITY, x = 73.4, y = 33.0,
    },
    Alliance = {
        npc = 211033, name = "Гэрион Уэнделл", nameEN = "Garion Wendell",
        place = "Квартал Магов, Штормград", map = M.STORMWIND, x = 48.8, y = 87.0,
    },
}

-- Сет 60: в SoD эти книги принимали учителя магии, а не библиотекари.
ns.TRAINERS = {
    Horde = { npc = 7825, name = "Оран Змеиные Кольца", place = "Квартал Магов, Подгород", map = M.UNDERCITY, x = 73.1, y = 32.9 },
    Alliance = { npc = 5497, name = "Джинния Пушка", place = "Башня магов, Штормград", map = M.STORMWIND, x = 49.6, y = 85.8 },
}

-- Квесты-награды: 10 книг — шея, 20 книг — кольцо.
ns.REWARD_QUESTS = { neck = 78150, ring = 79536 }

ns.GROUPS = {
    [1] = "Выход 1 · Тирисфаль и Серебряный бор",
    [2] = "Выход 2 · Калимдор",
    [3] = "Выход 3 · юг Восточных королевств",
    [4] = "Выход 4 · Альтерак, Арати, Болотина, Лок Модан",
    [5] = "Добор · две на выбор",
    [6] = "Запас · сет 45",
    [7] = "Только для Альянса",
    [8] = "Сет 60 · в SoD сдавались учителю магии",
}

-- faction: книгу принимает только библиотекарь этой фракции (по данным SoD).
ns.BOOKS = {
    -- Выход 1
    { key = "apothecary", group = 1, set = 20, quest = 79095, item = 208185, faction = "Horde",
      ru = "Учебник аптекаря по метафизике", en = "The Apothecary's Metaphysical Primer",
      spawns = { { M.TIRISFAL, 59.4, 52.3 } },
      note = "Брилл." },
    { key = "ataeric", group = 1, set = 20, quest = 79096, item = 210177, faction = "Horde",
      ru = "Атаерик: \"О любопытных свойствах тайной магии\"", en = "Ataeric: On Arcane Curiosities",
      spawns = { { M.SILVERPINE, 43.4, 41.2 } },
      note = "Гробница: книга внутри склепа, на столе у Себастьяна Мелоша. Сверху, на земле, её нет." },
    { key = "dalaran", group = 1, set = 20, quest = 78127, item = 209844,
      ru = "Даларанский справочник, том 23", en = "The Dalaran Digest, Vol. 23",
      spawns = { { M.SILVERPINE, 63.5, 63.1 } },
      note = "Янтарная мельница, среди магов Даларана." },

    -- Выход 2
    { key = "tazo", group = 2, set = 20, quest = 79094, item = 207972, faction = "Horde",
      ru = "Уроки Та'зо", en = "The Lessons of Ta'zo",
      spawns = { { M.ORGRIMMAR, 38.7, 78.4 } },
      note = "Роспись на стене в Оргриммаре. Точка из SoD, в Forever пока не подтверждена." },
    { key = "arcanic", group = 2, set = 20, quest = 78145, item = 209847,
      ru = "Руководство по магическим системам", en = "Arcanic Systems Manual",
      spawns = { { M.BARRENS, 56.3, 8.8 } },
      note = "Гоблинская вышка на самом севере Степей (Sludge Fen)." },
    { key = "baxtan", group = 2, set = 20, quest = 79097, item = 208800,
      ru = "Бакстан: о разрушительной магии", en = "Baxtan: On Destructive Magics",
      spawns = { { M.BARRENS, 62.7, 36.3 } },
      note = "Кабестан, гоблинский том." },
    { key = "dreamers", group = 2, set = 20, quest = 78143, item = 209846,
      ru = "Тайны Дремлющих", en = "Secrets of the Dreamers",
      spawns = { { M.BARRENS, 46.0, 36.5 } },
      note = "Точка — вход в пещеру у оазиса. Внутри иди в зал перед входом в Пещеры Стенаний: свитки на 52.8, 54.7 по карте пещеры. В инстанс не заходить." },
    { key = "fury", group = 2, set = 20, quest = 78149, item = 209851,
      ru = "Ярость земли", en = "Fury of the Land",
      spawns = { { M.STONETALON, 74.4, 85.7 } },
      note = "Лагерь клана Зловещего Тотема на юго-востоке Когтистых гор." },
    { key = "geomancy", group = 2, set = 35, quest = 79947, item = 215683,
      ru = "Геомантия: истины, высеченные в камне", en = "Geomancy: The Stone-Cold Truth",
      spawns = { { M.NEEDLES, 34.4, 40.1 } },
      note = "Спуск из Степей на Великом подъёмнике. Тропа на пик начинается на 31.0, 37.0, свитки в самом большом шатре." },
    { key = "rwl", group = 2, set = 35, quest = 79952, item = 215822,
      ru = "Рвл-рвл-рвл!", en = "RwlRwlRwlRwl!",
      spawns = { { M.DUSTWALLOW, 57.2, 20.8 } },
      note = "На земле у восточного края мурлочьего лагеря. В сам лагерь заходить не надо." },
    { key = "narthalas", group = 2, set = 20, quest = 78124, item = 209843,
      ru = "Нар'таласский альманах, том 74", en = "Nar'thalas Almanac, Vol. 74",
      spawns = { { M.DARKSHORE, 59.6, 22.2 } },
      note = "Руины на севере Темных берегов. Мобы низкие, но идти далеко." },

    -- Выход 3
    { key = "basilisks", group = 3, set = 35, quest = 79535, item = 213165,
      ru = "Василиски: стоит ли бояться окаменения?", en = "Basilisks: Should Petrification be Feared?",
      spawns = { { M.STV, 41.4, 50.9 } },
      note = "Деревянная платформа справа от входа в шахту. В саму шахту не нужно." },
    { key = "crimes", group = 3, set = 20, quest = 78147, item = 209849,
      ru = "Преступления против анатомии", en = "Crimes Against Anatomy",
      spawns = { { M.DUSKWOOD, 16.6, 28.5 } },
      note = "Запад Сумеречного леса, у реки." },
    { key = "bewitch", group = 3, set = 20, quest = 78142, item = 209845,
      ru = "Заговоры и чары", en = "Bewitchments and Glamours",
      spawns = { { M.WESTFALL, 45.4, 70.4 } },
      note = "Луноречье." },

    -- Выход 4
    { key = "defensive", group = 4, set = 35, quest = 79948, item = 215815,
      ru = "Защитные чары для чайников", en = "Defensive Magics 101",
      spawns = { { M.ALTERAC, 48.4, 57.6 } },
      note = "Первая башня огров, если идти от Мельницы Таррен. Книга внутри башни." },
    { key = "web", group = 4, set = 35, quest = 79949, item = 215816,
      ru = "Паутина лжи: разоблачение популярных мифов", en = "A Web of Lies: Debunking Myths and Legends",
      spawns = { { M.ARATHI, 73.6, 65.2 } },
      note = "Глубоко в деревне троллей на юго-востоке Арати." },
    { key = "goaz", group = 4, set = 20, quest = 78146, item = 209848,
      ru = "Свитки Гоаз", en = "Goaz Scrolls",
      spawns = { { M.WETLANDS, 33.6, 47.9 } },
      note = "Раскопки дворфов на западе Болотины." },
    { key = "runes", group = 4, set = 20, quest = 78148, item = 209850,
      ru = "Руны королей-чародеев", en = "Runes of the Sorcerer-Kings",
      spawns = { { M.LOCH_MODAN, 77.4, 14.0 } },
      note = "Крепость огров на северо-востоке Лок Модана." },

    -- Добор: две на выбор
    { key = "luddite", group = 5, set = 35, quest = 79953, item = 215824,
      ru = "Демонические питомцы: содержание и уход", en = "A Luddite's Guide to Caring for Your Demonic Pet",
      spawns = { { M.SWAMP, 61.4, 22.4 } },
      note = "Север Болота Печали. Ближайшая точка полёта — Каменор." },
    { key = "sanguine", group = 5, set = 45, quest = 81947, item = 220345,
      ru = "Кровавое колдовство", en = "Sanguine Sorcery",
      spawns = { { M.SWAMP, 70.0, 51.0, true } },
      note = "Самая верхняя дорожка храма Атал'Хаккар, лежит на виду." },
    { key = "mummies", group = 5, set = 35, quest = 79951, item = 215820,
      ru = "Мумии: крайне неприятная нежить", en = "Mummies: A Guide to the Unsavory Undead",
      spawns = { { M.BADLANDS, 56.7, 39.9 } },
      note = "Центр Бесплодных земель. Удобно после Лок Модана, улетать из Каргата." },
    { key = "demons", group = 5, set = 35, quest = 79950, item = 215817,
      ru = "Демоны и вы", en = "Demons and You",
      spawns = { { M.DESOLACE, 55.1, 26.2 } },
      note = "Глубоко в крепости Громового Топора. Худший вариант из четырёх." },

    -- Запас: сет 45
    { key = "stonewrought", group = 6, set = 45, quest = 81953, item = 220349,
      ru = "Каменный эскиз", en = "Stonewrought Design",
      spawns = { { M.BURNING_STEPPES, 29.0, 28.9, true } },
      note = "Внутри Черной горы, в самом низу: комната с алтарём Franclorn Forgewright, рядом с Lothos Riftwaker. Точка на карте — сама гора." },
    { key = "tidesages", group = 6, set = 45, quest = 81949, item = 220346,
      ru = "Легенды жрецов моря", en = "Legends of the Tidesages",
      spawns = { { M.TANARIS, 72.7, 47.8 } },
      note = "Пиратская бухта на востоке Танариса." },
    { key = "liminal", group = 6, set = 45, quest = 81951, item = 220347,
      ru = "О переходности и магии", en = "The Liminal and the Arcane",
      spawns = { { M.FERALAS, 50.6, 15.7 } },
      note = "Онейрос на севере Фераласа. В SoD книга была за порталом в Изумрудный Кошмар; есть ли он в Forever — неизвестно." },
    { key = "etiquette", group = 6, set = 45, quest = 81952, item = 220348,
      ru = "Повседневный этикет", en = "Everyday Etiquette",
      spawns = { { M.AZSHARA, 20.7, 62.0 } },
      note = "Лагерь на западе Азшары." },
    { key = "venomous", group = 6, set = 45, quest = 81954, item = 220350,
      ru = "Ядовитые странствия", en = "Venomous Journeys",
      spawns = { { M.HINTERLANDS, 36.0, 72.8 } },
      note = "Шадра'Алор, храм троллей на юге Внутренних земель." },
    { key = "mindmetal", group = 6, set = 45, quest = 81955, item = 220352,
      ru = "Металлический разум", en = "A Mind of Metal",
      spawns = { { M.SEARING_GORGE, 37.8, 49.3 } },
      note = "Котёл в центре Тлеющего ущелья." },
    { key = "codex", group = 6, set = 45, quest = 81956, item = 220353,
      ru = "Кодекс кудесника", en = "Conjurer's Codex",
      spawns = { { M.BLASTED_LANDS, 55.4, 32.2 } },
      note = "Выжженные земли." },

    -- Только для Альянса (по данным SoD)
    { key = "theocritus", group = 7, set = 20, quest = 79092, item = 203755, faction = "Alliance",
      ru = "Научные записи верховного мага Теокрита", en = "Archmage Theocritus' Research Journal",
      spawns = { { M.ELWYNN, 65.4, 70.1 } },
      note = "Башня Азоры." },
    { key = "antonidas", group = 7, set = 20, quest = 79091, item = 203754, faction = "Alliance",
      ru = "Верховный маг Антонидас: полная автобиография", en = "Archmage Antonidas: The Unabridged Autobiography",
      spawns = { { M.IRONFORGE, 75.7, 10.5 } },
      note = "Стальгорн." },
    { key = "rumi", group = 7, set = 20, quest = 79093, item = 208860, faction = "Alliance",
      ru = "Руми из Гномрегана: собрание трудов", en = "Rumi of Gnomeregan: The Collected Works",
      spawns = { { M.LOCH_MODAN, 35.6, 48.9 }, { M.WESTFALL, 52.7, 53.8 } },
      note = "Две точки: Телсамар в Лок Модане и Сторожевой холм в Западном Крае." },

    -- Сет 60 (SoD, фаза 6). Квесты есть в базе Forever, но работают ли — не подтверждено.
    { key = "potatoes", group = 8, set = 60, quest = 84395, item = 228132, trainer = true,
      ru = "Картофель-нежить", en = "Undead Potatoes",
      spawns = { { M.WPL, 38.2, 54.6 } },
      note = "Ферма в центре Западных Чумных земель, книга в доме." },
    { key = "magma", group = 8, set = 60, quest = 84396, item = 228133, trainer = true,
      ru = "Магма или лава?", en = "Magma or Lava?",
      spawns = { { M.BURNING_STEPPES, 26.4, 24.5, true } },
      note = "Черная гора, у входа в Глубины Черной горы. Точка на карте — сама гора." },
    { key = "kalimdor", group = 8, set = 60, quest = 84397, item = 228134, trainer = true,
      ru = "Северный Калимдор: подробный путеводитель", en = "Northern Kalimdor - A Comprehensive Guide",
      spawns = { { M.FELWOOD, 65.2, 3.3 } },
      note = "Север Оскверненного леса, у входа в туннель Древобрюхов." },
    { key = "light", group = 8, set = 60, quest = 84398, item = 228135, trainer = true,
      ru = "Наука о Свете", en = "A Study of the Light",
      spawns = { { M.EPL, 71.9, 48.3 } },
      note = "Часовня Последней Надежды." },
    { key = "kaboom", group = 8, set = 60, quest = 84399, item = 228136, trainer = true,
      ru = "Ба-бах!", en = "Ka-Boom!",
      spawns = { { M.WINTERSPRING, 60.7, 37.7 } },
      note = "Круговзор." },
    { key = "knight", group = 8, set = 60, quest = 84400, item = 228138, trainer = true,
      ru = "Рыцарь и дева", en = "The Knight and the Lady",
      spawns = { { M.EPL, 47.3, 42.2 } },
      note = "Центр Восточных Чумных земель." },
    { key = "scourge", group = 8, set = 60, quest = 84401, item = 228140, trainer = true,
      ru = "Плеть: жуткая нежить или непонятые души?", en = "Scourge: Undead Menace or Misunderstood?",
      spawns = { { M.EPL, 26.4, 15.1 } },
      note = "Северо-запад Восточных Чумных земель." },
    { key = "necromancy", group = 8, set = 60, quest = 84402, item = 228141, trainer = true,
      ru = "Некромантия для чайников", en = "Necromancy 101",
      spawns = { { M.WPL, 69.4, 72.8, true } },
      note = "Внутри Некроситета (Каэр Дарроу), на столе наверху. Точка на карте — остров." },
}
