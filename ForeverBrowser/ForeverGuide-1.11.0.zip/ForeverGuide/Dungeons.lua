-- Подземелья: квесты (с цепочками предквестов и проверкой выполнения), добыча боссов и обычных монстров.

local ADDON, ns = ...
local L = ns.L
local DName, DLoc = ns.DungeonName, ns.DungeonLoc

local DUNGEONS, DQ, DNPC, DOBJ, DITEM, LOOT = ns.DUNGEONS, ns.DQ, ns.DNPC, ns.DOBJ, ns.DITEM, ns.LOOT

local TEX_AVAIL = "Interface\\GossipFrame\\AvailableQuestIcon"
local TEX_ACTIVE = "Interface\\GossipFrame\\ActiveQuestIcon"
local TEX_DONE = "Interface\\RaidFrame\\ReadyCheck-Ready"
local TEX_WAIT = "Interface\\RaidFrame\\ReadyCheck-Waiting"
local TEX_NO = "Interface\\RaidFrame\\ReadyCheck-NotReady"
local TEX_UNKNOWN = "Interface\\Icons\\INV_Misc_QuestionMark"
local TEX_ENTRANCE = "Interface\\Icons\\INV_Misc_Bone_HumanSkull_01"
local TEX_BUTTON = (ns.Skin and ns.Skin.ICON) or ns.ADDON_ICON or "Interface\\Icons\\INV_Misc_Map_01"

local DB -- ForeverGuideDB.dq
local MM -- ForeverGuideDB.mmbtn

local function Print(msg) if ns.Print then ns.Print(msg) end end

---------------------------------------------------------------------------
-- Игрок
---------------------------------------------------------------------------

local function PlayerLevel() return UnitLevel("player") or 1 end
local function PlayerFac() return UnitFactionGroup("player") == "Alliance" and "A" or "H" end
local function PlayerRaceID() local _, _, id = UnitRace("player"); return id end
local function PlayerClassID() local _, _, id = UnitClass("player"); return id end

local function HasBit(mask, index)
    local b = 2 ^ (index - 1)
    return math.floor(mask / b) % 2 == 1
end

---------------------------------------------------------------------------
-- Квесты: статусы
---------------------------------------------------------------------------

local function IsNumeric(id) return type(id) == "number" end

local function Done(id)
    if not IsNumeric(id) then return false end
    return ns.IsDone(id)
end

local function InLog(id)
    if not IsNumeric(id) then return false end
    return ns.OnQuest(id)
end

-- Разрешён ли квест персонажу (фракция, раса, класс). Второе значение — причина.
local function Allowed(id)
    local q = DQ[id]
    if not q then return false, "nodata" end
    if q.fa and q.fa ~= PlayerFac() then return false, "faction" end
    local race = PlayerRaceID()
    if q.rc and race and race <= 8 then
        local ok = false
        for _, r in ipairs(q.rc) do if r == race then ok = true break end end
        if not ok then return false, "race" end
    end
    local class = PlayerClassID()
    if q.cl and class and class > 0 then
        if not HasBit(q.cl, class) then return false, "class" end
    end
    return true
end

local function ExclusiveDone(q)
    if not q.ex then return false end
    for _, e in ipairs(q.ex) do
        if Done(e) then return true end
    end
    return false
end

-- Предквесты выполнены?
local function PrereqsMet(q)
    if q.pg then
        for _, p in ipairs(q.pg) do
            if not Done(p) and Allowed(p) then return false end
        end
    end
    if q.pre then
        for _, p in ipairs(q.pre) do
            if not Done(p) then return false end
        end
    end
    if q.ps and #q.ps > 0 then
        local any, anyAllowed = false, false
        for _, p in ipairs(q.ps) do
            if Done(p) then any = true break end
            if Allowed(p) then anyAllowed = true end
        end
        if not any and anyAllowed then return false end
    end
    return true
end

-- Следующий шаг цепочки: квест, который надо взять/сдать прямо сейчас.
-- Возвращает id шага и действие: "take" | "turnin".
local function NextStep(id, depth, seen)
    depth = depth or 0
    seen = seen or {}
    if depth > 25 or seen[id] then return nil end
    seen[id] = true
    local q = DQ[id]
    if not q or Done(id) then return nil end
    if InLog(id) then return id, "turnin" end
    local function try(p)
        if DQ[p] and not Done(p) and Allowed(p) then
            return NextStep(p, depth + 1, seen)
        end
    end
    if q.pg then
        for _, p in ipairs(q.pg) do
            local s, a = try(p)
            if s then return s, a end
        end
    end
    if q.pre then
        for _, p in ipairs(q.pre) do
            if not Done(p) then
                local s, a = try(p)
                if s then return s, a end
            end
        end
    end
    if q.ps and #q.ps > 0 then
        local any = false
        for _, p in ipairs(q.ps) do if Done(p) then any = true break end end
        if not any then
            -- сначала то, что уже в журнале, потом первый доступный вариант
            for _, p in ipairs(q.ps) do
                if InLog(p) and Allowed(p) then return p, "turnin" end
            end
            for _, p in ipairs(q.ps) do
                local s, a = try(p)
                if s then return s, a end
            end
        end
    end
    return id, "take"
end

-- "done" | "active" | "avail" | "low" | "locked" | "closed" | "na" | "unknown"
local function QStatus(id)
    local q = DQ[id]
    if not q then return "unknown" end
    if Done(id) then return "done" end
    if InLog(id) then return "active" end
    local ok = Allowed(id)
    if not ok then return "na" end
    if ExclusiveDone(q) then return "closed" end
    if not IsNumeric(id) then return "unknown" end
    if not PrereqsMet(q) then return "locked" end
    if (q.rl or 0) > PlayerLevel() then return "low" end
    return "avail"
end

local STATUS_ORDER = { active = 1, avail = 2, locked = 3, low = 4, unknown = 5, closed = 6, done = 7, na = 8 }
local STATUS_ICON = {
    active = TEX_ACTIVE, avail = TEX_AVAIL, locked = TEX_WAIT, low = TEX_AVAIL,
    unknown = TEX_UNKNOWN, closed = TEX_NO, done = TEX_DONE, na = TEX_NO,
}

---------------------------------------------------------------------------
-- Имена и места
---------------------------------------------------------------------------

local questTitleTry = {}
local function QuestName(id)
    local q = DQ[id]
    if ns.IS_RU and q and q.r then return q.r end
    if ns.LZ and ns.LZ.q and IsNumeric(id) and ns.LZ.q[id] then return ns.LZ.q[id] end
    if IsNumeric(id) and C_QuestLog and ns.CLIENT_NAMES ~= false then
        -- название из клиента; если его нет, повторно не спрашиваем чаще раза в 10 минут
        local now = GetTime and GetTime() or 0
        local last = questTitleTry[id]
        if not last or now - last > 600 then
            local fn = C_QuestLog.GetTitleForQuestID or C_QuestLog.GetQuestInfo
            if fn then
                local ok, t = pcall(fn, id)
                if ok and type(t) == "string" and t ~= "" then return t end
                questTitleTry[id] = now
            end
        end
    end
    return (q and ns.Loc("q", id, q.n, q.r)) or ("#" .. tostring(id))
end

local function NpcName(nid)
    local n = DNPC[nid]
    if not n then return "#" .. nid end
    return ns.Loc("n", nid, n.n, n.r)
end

local function ObjName(oid)
    local o = DOBJ[oid]
    if not o then return "#" .. oid end
    return ns.Loc("o", oid, o.n, o.r)
end

local function ItemName(iid)
    local n = ns.CachedItemName(iid)
    if n then return n end
    local it = DITEM[iid]
    return (it and ns.Loc("i", iid, it.n, it.r)) or ("#" .. iid)
end

-- Точка на карте: {map, x, y, inside=bool, name=...}
local function SpawnTarget(sp, name)
    if not sp or not sp[1] then return nil end
    local s = sp[1]
    return { map = s[1], x = s[2], y = s[3], inside = s[4] and true or false, name = name }
end

local function NpcTarget(nid)
    local n = DNPC[nid]
    if not n then return nil end
    -- предпочитаем точку вне подземелья, если есть
    local best
    for _, s in ipairs(n.sp or {}) do
        if not s[4] then best = s break end
    end
    best = best or (n.sp and n.sp[1])
    if not best then return nil end
    return { map = best[1], x = best[2], y = best[3], inside = best[4] and true or false, name = NpcName(nid) }
end

local function ObjTarget(oid)
    local o = DOBJ[oid]
    if not o then return nil end
    return SpawnTarget(o.sp, ObjName(oid))
end

-- Кто выдаёт квест: цель и текст.
local function StarterInfo(id)
    local q = DQ[id]
    if not q then return nil, "?" end
    if q.new then
        if q.gn then
            local t = NpcTarget(q.gn)
            if t then return t, t.name end
        end
        if q.gxy and q.g then
            return { map = q.gxy[1], x = q.gxy[2], y = q.gxy[3] }, q.g
        end
        if q.it then
            local t = q.inside and { inside = true } or nil
            return t, L["предмет «"] .. q.it .. "»" .. (q.inside and L[" (добыча внутри)"] or "")
        end
        if q.g then
            if q.inside then return { inside = true }, q.g end
            if q.gz then return { zone = q.gz }, q.g end
            return nil, q.g
        end
        return nil, L["продолжение цепочки"]
    end
    local starters = q.s
    local fac = PlayerFac()
    if fac == "H" and q.sH then starters = q.sH elseif fac == "A" and q.sA then starters = q.sA end
    if starters and #starters > 0 then
        for _, nid in ipairs(starters) do
            local n = DNPC[nid]
            if n and (not n.fr or n.fr:find(fac)) then
                local t = NpcTarget(nid)
                if t then return t, t.name end
            end
        end
        local t = NpcTarget(starters[1])
        return t, NpcName(starters[1])
    end
    if q.so and #q.so > 0 then
        local t = ObjTarget(q.so[1])
        return t, ObjName(q.so[1])
    end
    if q.si and #q.si > 0 then
        local iid = q.si[1]
        local it = DITEM[iid]
        local txt = L["предмет «"] .. ItemName(iid) .. "»"
        if it and it.d and it.d[1] then
            local t = NpcTarget(it.d[1])
            txt = txt .. L[", падает с: "] .. NpcName(it.d[1])
            return t, txt
        elseif it and it.od and it.od[1] then
            local t = ObjTarget(it.od[1])
            txt = txt .. L[", лежит в: "] .. ObjName(it.od[1])
            return t, txt
        end
        return nil, txt
    end
    return nil, "?"
end

local function FinisherInfo(id)
    local q = DQ[id]
    if not q then return nil, "?" end
    if q.new then
        if q.en then
            local t = NpcTarget(q.en)
            if t then return t, t.name end
        end
        if q.exy and q.e then
            return { map = q.exy[1], x = q.exy[2], y = q.exy[3] }, q.e
        end
        if q.e then return q.ez and { zone = q.ez } or nil, q.e end
        return StarterInfo(id)
    end
    if q.f and #q.f > 0 then
        local t = NpcTarget(q.f[1])
        return t, NpcName(q.f[1])
    end
    if q.fo and #q.fo > 0 then
        local t = ObjTarget(q.fo[1])
        return t, ObjName(q.fo[1])
    end
    return nil, "?"
end

local function WhereText(t)
    if not t then return "" end
    if t.inside then return L["внутри подземелья"] end
    if t.map and t.x then return string.format("%s %.0f, %.0f", ns.ZoneName(t.map), t.x, t.y) end
    if t.zone then return ns.ZoneName(t.zone) end
    return ""
end

local function Colorize(text, r, g, b)
    return string.format("|cff%02x%02x%02x%s|r", math.floor(r * 255), math.floor(g * 255), math.floor(b * 255), text)
end

-- Строка-подсказка «что делать дальше» и цель для метки.
-- Вся цепочка до квеста: от самого первого шага до него самого.
-- Возвращает список {id, alts, group}, необязательные «наводки» и продолжение цепочки.
local function ChainOf(id)
    local list, seen = {}, {}
    -- для чужого квеста (другая фракция/класс) показываем его цепочку как есть
    local relax = not Allowed(id)
    local function ok(p) return relax or Allowed(p) or Done(p) end
    local function prereqs(q)
        local pres = {}
        for _, p in ipairs(q.pg or {}) do
            if DQ[p] and ok(p) then pres[#pres + 1] = { id = p, group = true } end
        end
        for _, p in ipairs(q.pre or {}) do
            if DQ[p] then pres[#pres + 1] = { id = p } end
        end
        if q.ps and #q.ps > 0 then
            local chosen
            for _, p in ipairs(q.ps) do if Done(p) then chosen = p break end end
            if not chosen then for _, p in ipairs(q.ps) do if InLog(p) and Allowed(p) then chosen = p break end end end
            if not chosen then for _, p in ipairs(q.ps) do if DQ[p] and ok(p) then chosen = p break end end end
            if chosen then
                local alts = {}
                for _, p in ipairs(q.ps) do
                    if p ~= chosen and DQ[p] and ok(p) then alts[#alts + 1] = p end
                end
                pres[#pres + 1] = { id = chosen, alts = alts }
            end
        end
        return pres
    end
    local function walk(qid, depth, info)
        if depth > 15 or seen[qid] then return end
        seen[qid] = true
        local q = DQ[qid]
        if not q then return end
        for _, p in ipairs(prereqs(q)) do walk(p.id, depth + 1, p) end
        list[#list + 1] = { id = qid, alts = info and info.alts, group = info and info.group }
    end
    walk(id, 0, nil)
    local opts = {}
    for _, e in ipairs(list) do
        for _, o in ipairs(DQ[e.id].li or {}) do
            if DQ[o] and not seen[o] and ok(o) then
                seen[o] = true
                opts[#opts + 1] = { id = o, leadsTo = e.id }
            end
        end
    end
    local nexts, cur, guard = {}, DQ[id] and DQ[id].nx, 0
    while cur and DQ[cur] and not seen[cur] and guard < 5 do
        seen[cur] = true
        if ok(cur) then nexts[#nexts + 1] = cur end
        cur = DQ[cur].nx
        guard = guard + 1
    end
    return list, opts, nexts
end

local function StepText(id, status)
    status = status or QStatus(id)
    local q = DQ[id]
    if status == "done" then return L["Выполнено"], nil end
    if status == "na" then
        local _, why = Allowed(id)
        local w = why == "class" and L["другой класс"] or why == "race" and L["другая раса"] or L["другая фракция"]
        return L["Не для тебя: "] .. w, nil
    end
    if status == "closed" then return L["Закрыт: выполнен альтернативный квест"], nil end
    local step, action = NextStep(id)
    if not step then
        if q and q.pt then return L["Нужен предквест «"] .. q.pt .. "»", nil end
        return "", nil
    end
    local target, who
    if action == "turnin" then
        target, who = FinisherInfo(step)
    else
        target, who = StarterInfo(step)
    end
    local where = WhereText(target)
    local verb = action == "turnin" and L["сдать"] or L["взять"]
    local txt
    if step == id then
        if action == "turnin" then
            txt = L["В журнале · сдать: "] .. who
        else
            txt = L["Взять: "] .. who
        end
    else
        local chain = ChainOf(id)
        local pos
        for i, e in ipairs(chain) do if e.id == step then pos = i break end end
        local where2 = pos and string.format(L[" (шаг %d из %d)"], pos, #chain) or ""
        txt = L["Сначала «"] .. QuestName(step) .. "»" .. where2 .. L[": "] .. verb .. " — " .. who
    end
    if where ~= "" then txt = txt .. " · " .. where end
    local sq = DQ[step]
    if action == "take" and sq and (sq.rl or 0) > PlayerLevel() then
        txt = txt .. Colorize(L[" · с "] .. sq.rl .. L[" ур."], 1, 0.5, 0.3)
    end
    if q and q.pt and step == id and status ~= "active" then
        txt = txt .. L[" · нужен «"] .. q.pt .. "»"
    end
    return txt, target, step, action
end

---------------------------------------------------------------------------
-- Метки
---------------------------------------------------------------------------

local function DungeonOf(key)
    for _, d in ipairs(DUNGEONS) do if d.key == key then return d end end
end

local function WaypointTarget(target, title, dungeon)
    if target and target.inside and dungeon and dungeon.map then
        target = { map = dungeon.map, x = dungeon.x, y = dungeon.y }
        title = title .. L[" (вход в подземелье)"]
    end
    if not target or not target.map or not target.x then
        Print(title .. L[": точных координат нет"] .. (target and target.zone and (" — " .. ns.ZoneName(target.zone)) or "") .. ".")
        return false
    end
    local how = ns.SetWaypoint(target.map, target.x, target.y, title)
    local where = string.format("%s %.1f, %.1f", ns.ZoneName(target.map), target.x, target.y)
    if how then
        Print(string.format("%s — %s (%s).", title, where, how))
    else
        Print(string.format(L["%s — %s. Метку поставить не получилось: введи координаты вручную или поставь TomTom."], title, where))
    end
    return true
end

local function WaypointQuest(id, dungeon)
    local txt, target, step, action = StepText(id)
    if not step then
        Print(QuestName(id) .. ": " .. (txt ~= "" and txt or L["шагов нет."]))
        return
    end
    local who
    if action == "turnin" then
        _, who = FinisherInfo(step)
    else
        _, who = StarterInfo(step)
    end
    WaypointTarget(target, QuestName(step) .. " — " .. who, dungeon)
end

---------------------------------------------------------------------------
-- Список квестов подземелья
---------------------------------------------------------------------------

local function DungeonQuests(d)
    local rows, stats = {}, { done = 0, open = 0, avail = 0, total = 0 }
    local seen = {}
    for _, id in ipairs(d.q or {}) do
        if not seen[id] and DQ[id] then
            seen[id] = true
            local st = QStatus(id)
            if st ~= "na" then
                stats.total = stats.total + 1
                if st == "done" then stats.done = stats.done + 1
                elseif st ~= "closed" then stats.open = stats.open + 1 end
                if st == "avail" or st == "active" then stats.avail = stats.avail + 1 end
            end
            local show = true
            if st == "na" and not DB.showAll then show = false end
            if st == "done" and not DB.showDone then show = false end
            if st == "closed" and not DB.showDone then show = false end
            if show then
                rows[#rows + 1] = { kind = "quest", id = id, status = st }
            end
        end
    end
    table.sort(rows, function(a, b)
        local oa, ob = STATUS_ORDER[a.status] or 9, STATUS_ORDER[b.status] or 9
        if oa ~= ob then return oa < ob end
        local la, lb = DQ[a.id].lv or 0, DQ[b.id].lv or 0
        if la ~= lb then return la < lb end
        return tostring(a.id) < tostring(b.id)
    end)
    return rows, stats
end

---------------------------------------------------------------------------
-- Пины на карте для отслеживаемого подземелья
---------------------------------------------------------------------------

local function QuestTooltip(tip, id)
    local q = DQ[id]
    local st = QStatus(id)
    tip:AddLine(QuestName(id) .. (q.lv and (" [" .. q.lv .. "]") or ""), 1, 0.82, 0)
    local obj = ns.QuestObjective(id, q)
    if obj then tip:AddLine(obj, 0.9, 0.9, 0.9, true) end
    local s1, s2 = StarterInfo(id)
    if s2 and s2 ~= "?" then tip:AddDoubleLine(L["Выдаёт:"], s2 .. (s1 and (" · " .. WhereText(s1)) or ""), 0.6, 0.6, 0.6, 1, 1, 1) end
    local f1, f2 = FinisherInfo(id)
    if f2 and f2 ~= "?" then tip:AddDoubleLine(L["Сдать:"], f2 .. (f1 and (" · " .. WhereText(f1)) or ""), 0.6, 0.6, 0.6, 1, 1, 1) end
    if q.rl then tip:AddDoubleLine(L["Мин. уровень:"], tostring(q.rl), 0.6, 0.6, 0.6, 1, 1, 1) end
    if q.sk then tip:AddLine(L["Нужна профессия (навык "] .. tostring(q.sk[2] or "") .. ").", 1, 0.6, 0.3) end
    if q.rep then tip:AddLine(L["Нужна репутация с фракцией."], 1, 0.6, 0.3) end
    if q.new then tip:AddLine(L["Новый квест Forever: данных меньше, координаты могут отсутствовать."], 0.45, 0.75, 1, true) end
    -- цепочка предквестов
    local chain, seen = {}, {}
    local function walk(qid, depth)
        if depth > 12 or seen[qid] then return end
        seen[qid] = true
        local qq = DQ[qid]
        if not qq then return end
        local pres = {}
        for _, p in ipairs(qq.pg or {}) do pres[#pres + 1] = p end
        for _, p in ipairs(qq.pre or {}) do pres[#pres + 1] = p end
        if qq.ps and #qq.ps > 0 then
            local pick
            for _, p in ipairs(qq.ps) do if Done(p) then pick = p break end end
            if not pick then for _, p in ipairs(qq.ps) do if Allowed(p) then pick = p break end end end
            pres[#pres + 1] = pick or qq.ps[1]
        end
        for _, p in ipairs(pres) do
            if DQ[p] and (Allowed(p) or Done(p)) then
                walk(p, depth + 1)
                chain[#chain + 1] = p
            end
        end
    end
    walk(id, 0)
    if #chain > 0 then
        tip:AddLine(" ")
        tip:AddLine(L["Цепочка до этого квеста:"], 0.45, 0.75, 1)
        for _, p in ipairs(chain) do
            local ps = QStatus(p)
            local mark = ps == "done" and "|TInterface\\RaidFrame\\ReadyCheck-Ready:12|t " or (ps == "active" and "|TInterface\\GossipFrame\\ActiveQuestIcon:12|t " or "|TInterface\\RaidFrame\\ReadyCheck-Waiting:12|t ")
            local lv = DQ[p].lv and (" [" .. DQ[p].lv .. "]") or ""
            if ps == "done" then
                tip:AddLine(mark .. QuestName(p) .. lv, 0.5, 0.5, 0.5)
            else
                tip:AddLine(mark .. QuestName(p) .. lv, 1, 1, 1)
            end
        end
    end
    if q.rw and (q.rw.c or q.rw.i) then
        local names = {}
        local function add(list)
            for _, it in ipairs(list or {}) do
                local info = ns.DRITEM and ns.DRITEM[it[1]]
                local n = ns.CachedItemName(it[1])
                n = n or (info and ns.Loc("i", it[1], info.n, info.r)) or ("#" .. it[1])
                names[#names + 1] = n
            end
        end
        add(q.rw.c)
        add(q.rw.i)
        tip:AddLine(" ")
        tip:AddLine(L["Награда"] .. (q.rw.c and #q.rw.c > 1 and L[" (на выбор)"] or "") .. ": " .. table.concat(names, ", "), 1, 0.82, 0, true)
    end
    local txt = StepText(id, st)
    if txt and txt ~= "" then
        tip:AddLine(" ")
        tip:AddLine(txt, 0.37, 0.77, 0.56, true)
    end
end

function ns.DungeonMapEntries()
    if not DB or not DB.track then return nil end
    local d = DungeonOf(DB.track)
    if not d then return nil end
    local groups, order = {}, {}
    for _, id in ipairs(d.q or {}) do
        local st = QStatus(id)
        if st == "avail" or st == "active" or st == "locked" or st == "low" then
            local _, target, step, action = StepText(id, st)
            if target and target.inside then target = nil end
            if target and target.map and target.x then
                local key = target.map .. ":" .. target.x .. ":" .. target.y
                local gr = groups[key]
                if not gr then
                    gr = { target = target, items = {} }
                    groups[key] = gr
                    order[#order + 1] = key
                end
                gr.items[#gr.items + 1] = { id = id, step = step, action = action, status = st }
            end
        end
    end
    local list = {}
    for _, key in ipairs(order) do
        local gr = groups[key]
        local anyTurnin, allLow = false, true
        for _, it in ipairs(gr.items) do
            if it.action == "turnin" then anyTurnin = true end
            local sq = DQ[it.step]
            if not (sq and (sq.rl or 0) > PlayerLevel()) then allLow = false end
        end
        list[#list + 1] = {
            kind = "dq", map = gr.target.map, x = gr.target.x, y = gr.target.y,
            icon = anyTurnin and TEX_ACTIVE or TEX_AVAIL, grey = allLow,
            tooltip = function(tip)
                tip:SetText(gr.target.name or L["Квесты"], 1, 1, 1)
                tip:AddLine(DName(d) .. L[" — квесты"], 0.45, 0.75, 1)
                local steps, order2 = {}, {}
                for _, it in ipairs(gr.items) do
                    local k = tostring(it.step) .. it.action
                    if not steps[k] then
                        steps[k] = { it = it, goals = {} }
                        order2[#order2 + 1] = k
                    end
                    if it.step ~= it.id then table.insert(steps[k].goals, QuestName(it.id)) end
                end
                for _, k in ipairs(order2) do
                    local st = steps[k]
                    local verb = st.it.action == "turnin" and L["сдать"] or L["взять"]
                    local sq = DQ[st.it.step]
                    local low = st.it.action == "take" and sq and (sq.rl or 0) > PlayerLevel() and (L[" |cffff7f4c(с "] .. sq.rl .. L[" ур.)|r"]) or ""
                    tip:AddLine("• " .. verb .. ": " .. QuestName(st.it.step) .. low, 1, 1, 1, true)
                    if #st.goals > 0 then
                        tip:AddLine(L["   ведёт к: "] .. table.concat(st.goals, ", "), 0.7, 0.7, 0.7, true)
                    end
                end
                tip:AddLine(L["Клик — метка маршрута"], 0.45, 0.75, 1)
            end,
            onClick = function()
                local it = gr.items[1]
                WaypointQuest(it.id, d)
            end,
        }
    end
    if d.map then
        list[#list + 1] = {
            kind = "dq", map = d.map, x = d.x, y = d.y, icon = TEX_ENTRANCE,
            tooltip = function(tip)
                tip:SetText(DName(d), 1, 0.82, 0)
                tip:AddLine(L["Вход в подземелье · "] .. (d.min or "?") .. "–" .. (d.max or "?"), 1, 1, 1)
            end,
            onClick = function() WaypointTarget({ map = d.map, x = d.x, y = d.y }, DName(d) .. L[" — вход"]) end,
        }
    end
    return list
end

---------------------------------------------------------------------------
-- UI: список с прокруткой
---------------------------------------------------------------------------

local function CreateScrollList(parent, rowHeight, createRow, updateRow)
    local sl = CreateFrame("Frame", nil, parent)
    sl.rows, sl.data, sl.offset, sl.visible = {}, {}, 0, 0
    local bar = CreateFrame("Slider", nil, sl)
    bar:SetWidth(10)
    bar:SetPoint("TOPRIGHT", 0, 0)
    bar:SetPoint("BOTTOMRIGHT", 0, 0)
    bar:SetOrientation("VERTICAL")
    bar:SetThumbTexture(ns.Skin.THUMB)
    local thumb = bar:GetThumbTexture()
    if thumb then thumb:SetSize(6, 40) end
    local bg = bar:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(1, 0.82, 0, 0.07)
    bar:EnableMouse(true)
    bar:SetMinMaxValues(0, 0)
    bar:SetValueStep(1)
    if bar.SetObeyStepOnDrag then bar:SetObeyStepOnDrag(true) end
    sl.bar = bar

    function sl:Refresh()
        local total = #self.data
        local maxOff = math.max(0, total - self.visible)
        if self.offset > maxOff then self.offset = maxOff end
        if self.offset < 0 then self.offset = 0 end
        self.updating = true
        bar:SetMinMaxValues(0, maxOff)
        bar:SetValue(self.offset)
        self.updating = false
        if maxOff == 0 then bar:Hide() else bar:Show() end
        for i, r in ipairs(self.rows) do
            local item = self.data[self.offset + i]
            if item and i <= self.visible then
                r.data = item
                updateRow(r, item)
                r:Show()
            else
                r.data = nil
                r:Hide()
            end
        end
    end

    function sl:Layout()
        local h = self:GetHeight() or 0
        local n = math.max(1, math.floor(h / rowHeight))
        for i = #self.rows + 1, n do
            local r = createRow(self)
            r:SetPoint("TOPLEFT", self, "TOPLEFT", 0, -(i - 1) * rowHeight)
            r:SetPoint("RIGHT", bar, "LEFT", -3, 0)
            r:SetHeight(rowHeight)
            self.rows[i] = r
        end
        self.visible = n
        self:Refresh()
    end

    function sl:SetData(data, keepOffset)
        self.data = data or {}
        if not keepOffset then self.offset = 0 end
        if self.visible == 0 then self:Layout() else self:Refresh() end
    end

    bar:SetScript("OnValueChanged", function(_, v)
        if sl.updating then return end
        v = math.floor(v + 0.5)
        if v ~= sl.offset then
            sl.offset = v
            sl:Refresh()
        end
    end)
    sl:EnableMouseWheel(true)
    sl:SetScript("OnMouseWheel", function(_, delta)
        sl.offset = sl.offset - delta * 3
        sl:Refresh()
    end)
    sl:SetScript("OnSizeChanged", function() sl:Layout() end)
    return sl
end

---------------------------------------------------------------------------
-- UI: окно
---------------------------------------------------------------------------

local F, dungeonList, questList, lootList
local header = {}
local selected -- dungeon table
local tab = "quests"
local section = "dungeons" -- "dungeons" | "search" | "books"
local views, topTabs, foot = {}, {}, nil
local card, cardID, RenderCard -- карточка квеста (ниже)

local function LevelColor(d)
    local lvl = PlayerLevel()
    if not d.min then return 0.7, 0.7, 0.7 end
    if lvl < d.min - 2 then return 1, 0.25, 0.2 end
    if lvl < d.min then return 1, 0.55, 0.2 end
    if lvl <= d.max then return 1, 0.9, 0.2 end
    if lvl <= d.max + 5 then return 0.3, 0.85, 0.3 end
    return 0.6, 0.6, 0.6
end

local function QuestNameColor(q)
    if q and q.lv and GetQuestDifficultyColor then
        local ok, c = pcall(GetQuestDifficultyColor, q.lv)
        if ok and c then return c.r, c.g, c.b end
    end
    return 1, 1, 1
end

local function ItemQualityHex(id)
    local q = ns.CachedItemQuality(id)
    if q and ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[q] then
        local c = ITEM_QUALITY_COLORS[q]
        return c.hex or string.format("|cff%02x%02x%02x", math.floor(c.r * 255), math.floor(c.g * 255), math.floor(c.b * 255))
    end
    return nil
end

local function ItemIcon(id)
    local icon
    if C_Item and C_Item.GetItemIconByID then icon = C_Item.GetItemIconByID(id) end
    if not icon and GetItemIcon then icon = GetItemIcon(id) end
    return icon or TEX_UNKNOWN
end

-- Слот и тип предмета из клиента игры (это клиент Forever, так что данные всегда по Forever).
local function ClientSlot(iid)
    local fn = (C_Item and C_Item.GetItemInfoInstant) or GetItemInfoInstant
    if not fn or ns.CLIENT_NAMES == false then return nil end -- слот из клиента — на языке клиента
    local ok, _, _, subType, equipLoc = pcall(fn, iid)
    if not ok then return nil end
    local loc = equipLoc and equipLoc ~= "" and _G[equipLoc] or nil
    if type(loc) ~= "string" then loc = nil end
    if subType == "" then subType = nil end
    if loc and subType and subType ~= loc then return loc .. ", " .. subType end
    return loc or subType
end

-- Требуемый уровень из клиента (когда предмет уже загружен).
local function ClientMinLevel(iid)
    local fn = (C_Item and C_Item.GetItemInfo) or GetItemInfo
    if not fn or ns.ItemCached(iid) == false then return nil end
    local ok, name, _, _, _, minLevel = pcall(fn, iid)
    if ok and name and type(minLevel) == "number" then return minLevel end
    return nil
end

local function RequestItem(id)
    ns.RequestItem(id)
end

local function LootItemName(it)
    local n = ns.CachedItemName(it.id)
    if n then return n, true end
    local en, ru = it.n, it.r
    if not en and not ru and ns.SI_ITEM and ns.SI_ITEM[it.id] then
        en, ru = ns.SI_ITEM[it.id]:match("^([^\t]*)\t([^\t]*)")
    end
    return ns.Loc("i", it.id, en, ru) or ("#" .. it.id), false
end

local function ItemLink(id)
    local link
    if C_Item and C_Item.GetItemInfo then
        link = select(2, C_Item.GetItemInfo(id))
    elseif GetItemInfo then
        link = select(2, GetItemInfo(id))
    end
    return link
end

local RefreshAll

local function MakeCheck(parent, label, onClick)
    local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    cb:SetSize(22, 22)
    local text = cb.text or cb.Text
    if not text then
        text = cb:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        text:SetPoint("LEFT", cb, "RIGHT", 2, 0)
    else
        text:SetFontObject("GameFontHighlightSmall")
    end
    text:SetText(label)
    cb.label = text
    cb:SetScript("OnClick", function(self) onClick(self:GetChecked() and true or false) end)
    return cb
end

local function MakeButton(parent, label, width, onClick)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(width, 22)
    ns.Skin.Button(b)
    b:SetText(label)
    b:SetScript("OnClick", onClick)
    return b
end

-- Строка подземелья (левая колонка)
local function CreateDungeonRow(parent)
    local r = CreateFrame("Button", nil, parent)
    ns.Skin.Hover(r)
    r.sel = ns.Skin.Sel(r)
    r.name = r:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    r.name:SetPoint("TOPLEFT", 4, -3)
    r.name:SetPoint("RIGHT", -40, 0)
    r.name:SetJustifyH("LEFT")
    r.name:SetWordWrap(false)
    r.sub = r:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    r.sub:SetPoint("BOTTOMLEFT", 4, 3)
    r.sub:SetJustifyH("LEFT")
    r.count = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    r.count:SetPoint("RIGHT", -4, 0)
    r:SetScript("OnClick", function(self)
        selected = self.data.d
        DB.sel = selected.key
        cardID = nil
        RefreshAll(true)
    end)
    return r
end

local function UpdateDungeonRow(r, item)
    local d = item.d
    r.name:SetText(DName(d))
    r.name:SetTextColor(LevelColor(d))
    local lv = d.min and (d.min .. "–" .. d.max) or "?"
    r.sub:SetText(lv .. (d.new and L["  · |cff73bfffновое|r"] or ""))
    local st = item.stats
    if st and st.total > 0 then
        local c = st.avail > 0 and "|cff5fc48f" or "|cffaaaaaa"
        r.count:SetText(c .. st.done .. "/" .. st.total .. "|r")
    else
        r.count:SetText("")
    end
    if selected == d then r.sel:Show() else r.sel:Hide() end
end

-- Строка квеста
local function CreateQuestRow(parent)
    local r = CreateFrame("Button", nil, parent)
    r:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    ns.Skin.Hover(r)
    r.icon = r:CreateTexture(nil, "ARTWORK")
    r.icon:SetSize(16, 16)
    r.icon:SetPoint("TOPLEFT", 4, -3)
    r.name = r:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    r.name:SetPoint("TOPLEFT", r.icon, "TOPRIGHT", 5, 0)
    r.name:SetPoint("RIGHT", -60, 0)
    r.name:SetJustifyH("LEFT")
    r.name:SetWordWrap(false)
    r.lvl = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    r.lvl:SetPoint("TOPRIGHT", -4, -4)
    r.sub = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    r.sub:SetPoint("TOPLEFT", r.name, "BOTTOMLEFT", 0, -3)
    r.sub:SetPoint("RIGHT", -4, 0)
    r.sub:SetJustifyH("LEFT")
    r.sub:SetJustifyV("TOP")
    r.sub:SetWordWrap(true)
    if r.sub.SetMaxLines then pcall(r.sub.SetMaxLines, r.sub, 2) end
    r.sub:SetHeight(26)
    r.sub:SetTextColor(0.7, 0.7, 0.7)
    r:SetScript("OnClick", function(self, button)
        if not self.data then return end
        if button == "RightButton" then
            WaypointQuest(self.data.id, selected)
            return
        end
        if ns.ShowQuestCard then ns.ShowQuestCard(self.data.id) end
    end)
    r:SetScript("OnEnter", function(self)
        if not self.data then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        QuestTooltip(GameTooltip, self.data.id)
        GameTooltip:AddLine(L["ЛКМ — карточка: награда и вся цепочка · ПКМ — метка на следующий шаг"], 0.45, 0.75, 1, true)
        GameTooltip:Show()
    end)
    r:SetScript("OnLeave", function() GameTooltip:Hide() end)
    return r
end

local function UpdateQuestRow(r, item)
    local id, st = item.id, item.status
    local q = DQ[id]
    r.icon:SetTexture(STATUS_ICON[st] or TEX_UNKNOWN)
    r.icon:SetDesaturated(st == "low" or st == "done" or st == "na" or st == "closed")
    local name = QuestName(id)
    if q.fa and DB.showAll then name = name .. (q.fa == "A" and L[" |cff4f8fff(Альянс)|r"] or L[" |cffff4f4f(Орда)|r"]) end
    r.name:SetText(name)
    if st == "done" or st == "na" or st == "closed" then
        r.name:SetTextColor(0.5, 0.5, 0.5)
    else
        r.name:SetTextColor(QuestNameColor(q))
    end
    r.lvl:SetText((q.lv and ("[" .. q.lv .. "]") or "") .. (q.rl and (L[" от "] .. q.rl) or ""))
    local txt = StepText(id, st)
    r.sub:SetText(txt or "")
end

-- Строка добычи
local function CreateLootRow(parent)
    local r = CreateFrame("Button", nil, parent)
    r:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    r.hl = ns.Skin.Hover(r)
    r.bg = ns.Skin.Head(r)
    r.icon = r:CreateTexture(nil, "ARTWORK")
    r.icon:SetSize(18, 18)
    r.icon:SetPoint("LEFT", 6, 0)
    r.name = r:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    r.name:SetPoint("LEFT", r.icon, "RIGHT", 6, 0)
    r.name:SetJustifyH("LEFT")
    r.name:SetWordWrap(false)
    r.pct = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    r.pct:SetPoint("RIGHT", -4, 0)
    r.pct:SetWidth(52)
    r.pct:SetJustifyH("RIGHT")
    r.slot = r:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    r.slot:SetPoint("RIGHT", r.pct, "LEFT", -6, 0)
    r.slot:SetJustifyH("RIGHT")
    r.name:SetPoint("RIGHT", r.slot, "LEFT", -6, 0)
    r:SetScript("OnEnter", function(self)
        local it = self.data and self.data.item
        if not it then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        local ok = false
        ns.tipSuppress = true
        if GameTooltip.SetItemByID then ok = pcall(GameTooltip.SetItemByID, GameTooltip, it.id) end
        if not ok then pcall(GameTooltip.SetHyperlink, GameTooltip, "item:" .. it.id) end
        ns.tipSuppress = false
        if GameTooltip:NumLines() == 0 then
            GameTooltip:SetText(LootItemName(it), 1, 1, 1)
            GameTooltip:AddLine(ns.SlotText(it.sl), 0.7, 0.7, 0.7)
        end
        GameTooltip:AddLine(" ")
        if it.trash then
            if it.p and it.m then
                local mob = ns.Loc("n", it.m, it.mn, it.mr) or ""
                GameTooltip:AddLine(string.format(L["С обычных монстров: %s — %s%% (классическая база)"], mob, tostring(it.p)), 0.37, 0.77, 0.56, true)
                if it.mc and it.mc > 1 then
                    GameTooltip:AddLine(string.format(L["Падает ещё с %d видов монстров здесь"], it.mc - 1), 0.6, 0.6, 0.6)
                end
            end
            local seen = selected and ns.TrashSeen and ns.TrashSeen(selected.key, it.id)
            if seen and seen.n and seen.n > 0 then
                GameTooltip:AddLine(string.format(L["Ты видел это в Forever: %d раз"], seen.n), 0.45, 0.75, 1)
            end
        elseif it.p then
            GameTooltip:AddLine(string.format(L["Шанс выпадения: %s%% (классика, Wowhead)"], tostring(it.p)), 0.37, 0.77, 0.56)
        elseif it.new then
            GameTooltip:AddLine(L["Новый предмет Forever — шанс пока неизвестен."], 0.45, 0.75, 1)
        end
        GameTooltip:AddLine(L["Shift+клик — ссылка в чат · Ctrl+клик — примерить"], 0.6, 0.6, 0.6)
        GameTooltip:Show()
    end)
    r:SetScript("OnLeave", function() GameTooltip:Hide() end)
    r:SetScript("OnClick", function(self)
        local it = self.data and self.data.item
        if not it then return end
        local link = ItemLink(it.id)
        if IsShiftKeyDown() then
            if link and ChatEdit_InsertLink then ChatEdit_InsertLink(link) end
        elseif IsControlKeyDown() then
            if link and DressUpItemLink then DressUpItemLink(link) end
        end
    end)
    return r
end

local function UpdateLootRow(r, item)
    if item.kind == "boss" then
        local b = item.boss
        r.bg:Show()
        r.icon:Hide()
        r.name:SetPoint("LEFT", r, "LEFT", 6, 0)
        local nm = ns.BossName(b)
        if nm ~= b.n then nm = nm .. " |cff888888(" .. b.n .. ")|r" end
        r.name:SetText("|cffffd100" .. nm .. "|r" .. (b.rare and L["  |cffc0c0c0редкий|r"] or ""))
        r.slot:SetText(b.lv and (L["ур. "] .. b.lv) or "")
        r.pct:SetText(#b.items == 0 and L["|cff888888нет данных|r"] or "")
        return
    elseif item.kind == "trash" then
        r.bg:Show()
        r.icon:Hide()
        r.name:SetPoint("LEFT", r, "LEFT", 6, 0)
        r.name:SetText("|cffffd100" .. L["Обычные монстры"] .. "|r")
        r.slot:SetText("")
        r.pct:SetText(item.count > 0 and ("|cff888888" .. item.count .. "|r") or "")
        return
    elseif item.kind == "note" then
        r.bg:Hide()
        r.icon:Hide()
        r.name:SetPoint("LEFT", r, "LEFT", 6, 0)
        r.name:SetText("|cffaaaaaa" .. item.text .. "|r")
        r.slot:SetText("")
        r.pct:SetText("")
        return
    end
    local it = item.item
    r.bg:Hide()
    r.icon:Show()
    r.name:SetPoint("LEFT", r.icon, "RIGHT", 6, 0)
    r.icon:SetTexture(ItemIcon(it.id))
    local name, cached = LootItemName(it)
    if not cached then RequestItem(it.id) end
    local hex = ItemQualityHex(it.id)
    local tag = (it.new and L[" |cff73bfffНОВОЕ|r"]) or (it.found and L[" |cff5fc48fзамечено|r"]) or ""
    if hex then
        if hex:sub(1, 2) ~= "|c" then hex = "|c" .. hex end
        r.name:SetText(hex .. name .. "|r" .. tag)
    else
        r.name:SetText(name .. tag)
    end
    r.slot:SetText(ClientSlot(it.id) or ns.SlotText(it.sl) or "")
    if it.p then
        r.pct:SetText(tostring(it.p) .. "%")
    elseif it.found then
        r.pct:SetText("|cff5fc48f×" .. it.found .. "|r")
    else
        r.pct:SetText("|cff888888—|r")
    end
end

-- Добыча обычных монстров: вещи, которые падают именно в этом подземелье (DungeonTrash.lua),
-- плюс то, что аддон сам заметил у тебя в Forever (Trash.lua).
local function TrashRows(d, rows)
    local list = (ns.TRASH and ns.TRASH[d.key]) or {}
    local items, shown = {}, {}
    for _, it in ipairs(list) do
        it.trash = true
        items[#items + 1] = { kind = "item", item = it }
        shown[it.id] = true
    end
    local extra = {}
    for id, e in pairs((ns.TrashSeenAll and ns.TrashSeenAll(d.key)) or {}) do
        if not shown[id] and type(e) == "table" then
            extra[#extra + 1] = { id = id, trash = true, found = e.n or 1, m = e.m }
        end
    end
    table.sort(extra, function(a, b) if a.found ~= b.found then return a.found > b.found end return a.id < b.id end)
    for _, it in ipairs(extra) do items[#items + 1] = { kind = "item", item = it } end
    rows[#rows + 1] = { kind = "trash", count = #items }
    if #items == 0 then
        if d.new or not ns.TRASH or not ns.TRASH[d.key] then
            rows[#rows + 1] = { kind = "note", text = L["С обычных монстров пока ничего не записано: аддон сам запоминает, что у тебя падает."] }
        else
            rows[#rows + 1] = { kind = "note", text = L["Особой добычи с обычных монстров здесь нет — только случайные вещи по уровню."] }
        end
    else
        if #list > 0 then
            rows[#rows + 1] = { kind = "note", text = L["Только то, что падает именно здесь (без случайных вещей мира). Шанс — с лучшего моба, наведи на вещь."] }
        end
        for _, r in ipairs(items) do rows[#rows + 1] = r end
    end
    if ns.TRASH_CARDS and ns.TRASH_CARDS[d.key] then
        rows[#rows + 1] = { kind = "note", text = L["Ещё здесь изредка падают карты Новолуния."] }
    end
end

local function LootRows(d)
    local rows = {}
    local bosses = LOOT[d.key]
    if not bosses or #bosses == 0 then
        rows[1] = { kind = "note", text = L["Данных о боссах и добыче пока нет."] }
        if d.new then
            rows[2] = { kind = "note", text = L["Подземелье ещё не открыто на бете (кап уровня) — таблицы появятся позже."] }
        end
        TrashRows(d, rows)
        return rows
    end
    local anyItems = false
    for _, b in ipairs(bosses) do
        rows[#rows + 1] = { kind = "boss", boss = b }
        for _, it in ipairs(b.items) do
            rows[#rows + 1] = { kind = "item", item = it }
            anyItems = true
        end
    end
    if not anyItems then
        rows[#rows + 1] = { kind = "note", text = L["Боссы известны, добычу ещё никто не записал."] }
    end
    TrashRows(d, rows)
    return rows
end

local function UpdateHeader()
    local d = selected
    if not d then return end
    header.title:SetText(DName(d))
    local lv = d.min and (L["Уровни "] .. d.min .. "–" .. d.max) or ""
    header.sub:SetText(lv .. " · " .. DLoc(d) .. (d.en ~= DName(d) and ("  |cff888888" .. d.en .. "|r") or ""))
    if d.map then header.entrance:Enable() else header.entrance:Disable() end
    header.track:SetChecked(DB.track == d.key)
    header.showDone:SetChecked(DB.showDone)
    header.showAll:SetChecked(DB.showAll)
end

local dungeonStats = {}

local function Footers()
    return {
    dungeons = {
        quests = "|T" .. TEX_AVAIL .. ":14|t " .. L["можно взять"] .. "   |T" .. TEX_ACTIVE .. ":14|t " .. L["в журнале — сдать"] .. "   |T" .. TEX_WAIT .. ":14|t " .. L["сначала предквест"] .. "   |T" .. TEX_DONE .. ":14|t " .. L["сделано"] .. "     " .. L["ЛКМ — карточка квеста (награда, цепочка) · ПКМ — метка маршрута"],
        loot = L["Шансы — классические с Wowhead: своих Forever пока не публикует. «НОВОЕ» — вещь, добавленная в Forever. Наведи на вещь — подсказка, Shift+клик — ссылка в чат."],
    },
    search = L["Ищи по-русски или по-английски. Зелёным — данные Forever, оранжевым — классическая база. Клик по мобу или квестодателю — метка маршрута."],
    books = L["Библиотечные книги: сдавай Оуэну Тадду (Орда) или Гэриону Уэнделлу (Альянс). Клик по книге — метка маршрута, наведение — подробности."],
    profs = L["Рецепты из клиента Forever. Цифры — навык: выучить / жёлтый / зелёный / серый. ★ — новый в Forever, ◆ — изменён. Клик — реагенты и где выучить."],
    }
end

local function ShowSection()
    for i, b in ipairs(topTabs) do
        if b.section == section then b:LockHighlight() else b:UnlockHighlight() end
    end
    for name, v in pairs(views) do
        if name == section then v:Show() else v:Hide() end
    end
    if foot then
        local f = Footers()[section]
        if type(f) == "table" then f = f[tab] or f.quests end
        foot:SetText(f or "")
    end
end

RefreshAll = function(resetOffset)
    if not F or not F:IsShown() then return end
    ShowSection()
    if section == "search" then
        if ns.SearchRefresh then ns.SearchRefresh() end
        return
    elseif section == "books" then
        if ns.BooksRefresh then ns.BooksRefresh() end
        return
    elseif section == "profs" then
        if ns.ProfsRefresh then ns.ProfsRefresh(resetOffset) end
        return
    end
    local items = {}
    for _, d in ipairs(DUNGEONS) do
        local _, st = DungeonQuests(d)
        dungeonStats[d.key] = st
        items[#items + 1] = { d = d, stats = st }
    end
    dungeonList:SetData(items, true)
    if not selected then return end
    UpdateHeader()
    local rows, st = DungeonQuests(selected)
    header.tabQuests:SetText(L["Квесты ("] .. (st.total - st.done) .. ")")
    if tab == "quests" and cardID and DQ[cardID] and card then
        header.listArea:Hide()
        lootList:Hide()
        header.qbar:Hide()
        header.empty:Hide()
        header.tabQuests:LockHighlight()
        header.tabLoot:UnlockHighlight()
        card:Show()
        RenderCard(cardID, not resetOffset)
        return
    end
    if card then card:Hide() end
    if tab == "quests" then
        header.listArea:Show()
        questList:Show()
        lootList:Hide()
        header.qbar:Show()
        header.tabQuests:LockHighlight()
        header.tabLoot:UnlockHighlight()
        if #rows == 0 then
            local msg
            if st.total == 0 then
                msg = selected.new and L["Квестов пока не известно (новое подземелье)."] or L["Квестов для твоей фракции/класса нет."]
            else
                msg = L["Все квесты выполнены! Поставь галочку «Выполненные», чтобы увидеть их."]
            end
            header.empty:SetText(msg)
            header.empty:Show()
        else
            header.empty:Hide()
        end
        questList:SetData(rows, not resetOffset)
    else
        header.empty:Hide()
        header.listArea:Hide()
        lootList:Show()
        header.qbar:Hide()
        header.tabLoot:LockHighlight()
        header.tabQuests:UnlockHighlight()
        lootList:SetData(LootRows(selected), not resetOffset)
    end
end

local function AllWaypoints()
    local d = selected
    if not d then return end
    local targets = {}
    for _, id in ipairs(d.q or {}) do
        local st = QStatus(id)
        if st == "avail" or st == "active" or st == "locked" then
            local _, target, step, action = StepText(id, st)
            if target then
                if target.inside and d.map then target = { map = d.map, x = d.x, y = d.y, name = DName(d) } end
                if target.map and target.x then
                    local who = select(2, (action == "turnin" and FinisherInfo or StarterInfo)(step))
                    targets[#targets + 1] = { t = target, title = QuestName(step) .. " — " .. who }
                end
            end
        end
    end
    if #targets == 0 then
        Print(DName(d) .. L[": нет квестов, которые можно взять или сдать прямо сейчас."])
        return
    end
    if TomTom and TomTom.AddWaypoint then
        local seen, n = {}, 0
        for _, x in ipairs(targets) do
            local k = x.t.map .. ":" .. x.t.x .. ":" .. x.t.y
            if not seen[k] then
                seen[k] = true
                TomTom:AddWaypoint(x.t.map, x.t.x / 100, x.t.y / 100, { title = x.title, persistent = false, minimap = true, world = true })
                n = n + 1
            end
        end
        Print(string.format(L["%s: добавлено меток в TomTom — %d."], DName(d), n))
        return
    end
    -- без TomTom: ближайшая точка
    local cont, pos = ns.PlayerWorld()
    local best, bestD
    if cont then
        local px, py = pos:GetXY()
        for _, x in ipairs(targets) do
            local w = ns.WorldPos(x.t)
            if w and w[1] == cont then
                local bx, by = w[2]:GetXY()
                local dd = (px - bx) ^ 2 + (py - by) ^ 2
                if not bestD or dd < bestD then best, bestD = x, dd end
            end
        end
    end
    best = best or targets[1]
    Print(string.format(L["%s: точек %d, без TomTom ставлю метку на ближайшую."], DName(d), #targets))
    WaypointTarget(best.t, best.title, d)
end

---------------------------------------------------------------------------
-- Карточка квеста: награда и вся цепочка
---------------------------------------------------------------------------

local DRITEM = ns.DRITEM or {}

local FACTION_RU = {
    [72] = "Штормград", [47] = "Стальгорн", [69] = "Дарнас", [54] = "Изгнанники Гномрегана", [76] = "Оргриммар",
    [68] = "Подгород", [81] = "Громовой Утес", [530] = "Племя Черного Копья", [21] = "Пиратская Бухта",
    [369] = "Прибамбасск", [470] = "Кабестан", [577] = "Круговзор", [59] = "Братство Тория",
    [529] = "Серебряный Рассвет", [576] = "Древобрюхи", [609] = "Круг Кенария", [749] = "Гидраксианские Повелители Вод",
    [809] = "Шен'дралар", [469] = "Альянс", [67] = "Орда", [471] = "Клан Громового Молота", [270] = "Племя Зандалар",
    [87] = "Пираты Кровавого Паруса", [92] = "Кентавры из племени Гелкис", [93] = "Кентавры из племени Маграм",
    [169] = "Картель Хитрой Шестеренки", [510] = "Осквернители", [509] = "Лига Аратора", [730] = "Стража Грозовой Вершины",
    [729] = "Клан Северного Волка", [889] = "Всадники Песни Войны", [890] = "Среброкрылые Часовые",
    [910] = "Род Ноздорму", [349] = "Черный Ворон", [70] = "Синдикат", [589] = "Укротители ледопардов",
}

local function FactionName(id)
    if FACTION_RU[id] and not ns.CLIENT_NAMES then return L[FACTION_RU[id]] end
    if C_Reputation and C_Reputation.GetFactionDataByID then
        local ok, d = pcall(C_Reputation.GetFactionDataByID, id)
        if ok and type(d) == "table" and d.name then return d.name end
    end
    if GetFactionInfoByID then
        local ok, name = pcall(GetFactionInfoByID, id)
        if ok and type(name) == "string" and name ~= "" then return name end
    end
    return (FACTION_RU[id] and L[FACTION_RU[id]]) or (L["фракция #"] .. id)
end

local function MoneyText(copper)
    if GetCoinTextureString then
        local ok, t = pcall(GetCoinTextureString, copper)
        if ok and t then return t end
    end
    local g, sv, c = math.floor(copper / 10000), math.floor(copper / 100) % 100, copper % 100
    local parts = {}
    if g > 0 then parts[#parts + 1] = g .. L["з"] end
    if sv > 0 then parts[#parts + 1] = sv .. L["с"] end
    if c > 0 or #parts == 0 then parts[#parts + 1] = c .. L["м"] end
    return table.concat(parts, " ")
end

local function RewardItemName(id)
    local n = ns.CachedItemName(id)
    if n then return n end
    local it = DRITEM[id]
    return (it and ns.Loc("i", id, it.n, it.r)) or ("#" .. id)
end

local function RewardItemColor(id)
    local hex = ItemQualityHex(id)
    if hex then
        if hex:sub(1, 2) ~= "|c" then hex = "|c" .. hex end
        return hex
    end
    local it = DRITEM[id] -- q есть только у вещей, проверенных по Wowhead Forever
    if it and it.q and ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[it.q] then
        local c = ITEM_QUALITY_COLORS[it.q]
        local h = c.hex or string.format("|cff%02x%02x%02x", math.floor(c.r * 255), math.floor(c.g * 255), math.floor(c.b * 255))
        if h:sub(1, 2) ~= "|c" then h = "|c" .. h end
        return h
    end
    return "|cffd8d8d8"
end

local function ItemSlotText(iid)
    local sl = ClientSlot(iid)
    if sl then return sl end
    local info = DRITEM[iid]
    return (info and ns.SlotText(info.sl)) or ""
end

local function StepTarget(id)
    if InLog(id) then return FinisherInfo(id) end
    return StarterInfo(id)
end

local function ItemTooltip(owner, id, extra)
    GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
    local ok = false
    ns.tipSuppress = true
    if GameTooltip.SetItemByID then ok = pcall(GameTooltip.SetItemByID, GameTooltip, id) end
    if not ok then pcall(GameTooltip.SetHyperlink, GameTooltip, "item:" .. id) end
    ns.tipSuppress = false
    if GameTooltip:NumLines() == 0 then
        GameTooltip:SetText(RewardItemName(id), 1, 1, 1)
        local it = DRITEM[id]
        if it and it.sl then GameTooltip:AddLine(ns.SlotText(it.sl), 0.7, 0.7, 0.7) end
    end
    if extra then GameTooltip:AddLine(extra, 0.6, 0.6, 0.6, true) end
    GameTooltip:AddLine(L["Shift+клик — ссылка в чат · Ctrl+клик — примерить"], 0.6, 0.6, 0.6)
    GameTooltip:Show()
end

local function CreateCard(parent)
    local c = CreateFrame("Frame", nil, parent)
    c.fs, c.steps, c.items = {}, {}, {}
    local bg = ns.Skin.Panel(c)

    c.back = MakeButton(c, L["« К списку"], 110, function()
        cardID = nil
        RefreshAll()
    end)
    c.back:SetPoint("TOPLEFT", 4, -4)
    c.mark = MakeButton(c, L["Метка на следующий шаг"], 200, function()
        if cardID then WaypointQuest(cardID, selected) end
    end)
    c.mark:SetPoint("TOPRIGHT", -4, -4)

    local sf = CreateFrame("ScrollFrame", nil, c)
    sf:SetPoint("TOPLEFT", 8, -32)
    sf:SetPoint("BOTTOMRIGHT", -16, 4)
    local content = CreateFrame("Frame", nil, sf)
    content:SetSize(500, 10)
    sf:SetScrollChild(content)
    c.sf, c.content = sf, content

    local bar = CreateFrame("Slider", nil, c)
    bar:SetWidth(10)
    bar:SetPoint("TOPRIGHT", -3, -32)
    bar:SetPoint("BOTTOMRIGHT", -3, 4)
    bar:SetOrientation("VERTICAL")
    bar:SetThumbTexture(ns.Skin.THUMB)
    local thumb = bar:GetThumbTexture()
    if thumb then thumb:SetSize(6, 40) end
    local bbg = bar:CreateTexture(nil, "BACKGROUND")
    bbg:SetAllPoints()
    bbg:SetColorTexture(1, 0.82, 0, 0.07)
    bar:EnableMouse(true)
    bar:SetMinMaxValues(0, 0)
    bar:SetValueStep(1)
    bar:SetScript("OnValueChanged", function(_, v)
        if c.updating then return end
        sf:SetVerticalScroll(v)
    end)
    c.bar = bar

    sf:EnableMouseWheel(true)
    sf:SetScript("OnMouseWheel", function(_, delta)
        local maxv = c.maxScroll or 0
        local v = (sf:GetVerticalScroll() or 0) - delta * 40
        if v < 0 then v = 0 end
        if v > maxv then v = maxv end
        sf:SetVerticalScroll(v)
        c.updating = true
        bar:SetValue(v)
        c.updating = false
    end)
    return c
end

local function CardFS(c, font)
    c.nfs = c.nfs + 1
    local fs = c.fs[c.nfs]
    if not fs then
        fs = c.content:CreateFontString(nil, "OVERLAY", font)
        fs:SetJustifyH("LEFT")
        fs:SetJustifyV("TOP")
        fs:SetWordWrap(true)
        c.fs[c.nfs] = fs
    end
    fs:SetFontObject(font)
    fs:ClearAllPoints()
    fs:SetTextColor(1, 1, 1)
    fs:Show()
    return fs
end

local function CardStep(c)
    c.nsteps = c.nsteps + 1
    local b = c.steps[c.nsteps]
    if not b then
        b = CreateFrame("Button", nil, c.content)
        b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
        ns.Skin.Hover(b)
        b.cur = ns.Skin.Sel(b)
        b.icon = b:CreateTexture(nil, "ARTWORK")
        b.icon:SetSize(16, 16)
        b.icon:SetPoint("TOPLEFT", 4, -3)
        b.title = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        b.title:SetPoint("TOPLEFT", b.icon, "TOPRIGHT", 5, 0)
        b.title:SetJustifyH("LEFT")
        b.title:SetWordWrap(true)
        b.sub = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        b.sub:SetJustifyH("LEFT")
        b.sub:SetWordWrap(true)
        b.sub:SetTextColor(0.75, 0.75, 0.75)
        b:SetScript("OnClick", function(self, button)
            if not self.qid then return end
            if button == "RightButton" or self.qid == cardID then
                WaypointQuest(self.qid, selected)
            else
                ns.ShowQuestCard(self.qid)
            end
        end)
        b:SetScript("OnEnter", function(self)
            if not self.qid then return end
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            QuestTooltip(GameTooltip, self.qid)
            GameTooltip:AddLine(L["ЛКМ — открыть карточку этого шага · ПКМ — метка"], 0.45, 0.75, 1, true)
            GameTooltip:Show()
        end)
        b:SetScript("OnLeave", function() GameTooltip:Hide() end)
        c.steps[c.nsteps] = b
    end
    b:ClearAllPoints()
    b:Show()
    return b
end

local function CardItem(c)
    c.nitems = c.nitems + 1
    local b = c.items[c.nitems]
    if not b then
        b = CreateFrame("Button", nil, c.content)
        b:SetHeight(36)
        b.hl = ns.Skin.Hover(b)
        b.icon = b:CreateTexture(nil, "ARTWORK")
        b.icon:SetSize(30, 30)
        b.icon:SetPoint("LEFT", 2, 0)
        b.count = b:CreateFontString(nil, "OVERLAY", "NumberFontNormal")
        b.count:SetPoint("BOTTOMRIGHT", b.icon, "BOTTOMRIGHT", -1, 1)
        b.name = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        b.name:SetPoint("TOPLEFT", b.icon, "TOPRIGHT", 6, -1)
        b.name:SetPoint("RIGHT", -2, 0)
        b.name:SetJustifyH("LEFT")
        b.name:SetWordWrap(false)
        b.sub = b:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        b.sub:SetPoint("TOPLEFT", b.name, "BOTTOMLEFT", 0, -3)
        b.sub:SetPoint("RIGHT", -2, 0)
        b.sub:SetJustifyH("LEFT")
        b.sub:SetWordWrap(false)
        b:SetScript("OnEnter", function(self) if self.itemID then ItemTooltip(self, self.itemID) end end)
        b:SetScript("OnLeave", function() GameTooltip:Hide() end)
        b:SetScript("OnClick", function(self)
            if not self.itemID then return end
            local link = ItemLink(self.itemID)
            if IsShiftKeyDown() then
                if link and ChatEdit_InsertLink then ChatEdit_InsertLink(link) end
            elseif IsControlKeyDown() then
                if link and DressUpItemLink then DressUpItemLink(link) end
            end
        end)
        c.items[c.nitems] = b
    end
    b:ClearAllPoints()
    b:Show()
    return b
end

RenderCard = function(id, keepScroll)
    local c = card
    local oldScroll = keepScroll and c and c.sf:GetVerticalScroll() or 0
    local q = DQ[id]
    if not c or not q then return end
    for _, fs in ipairs(c.fs) do fs:Hide() end
    for _, b in ipairs(c.steps) do b:Hide(); b.qid = nil end
    for _, b in ipairs(c.items) do b:Hide(); b.itemID = nil end
    c.nfs, c.nsteps, c.nitems = 0, 0, 0

    local W = c.sf:GetWidth()
    if not W or W < 200 then W = 540 end
    c.content:SetWidth(W)
    local y = 4

    local function Text(txt, font, r, g, b, indent, gap)
        local fs = CardFS(c, font or "GameFontHighlight")
        indent = indent or 0
        fs:SetPoint("TOPLEFT", c.content, "TOPLEFT", indent, -y)
        fs:SetWidth(W - indent - 4)
        fs:SetText(txt)
        if r then fs:SetTextColor(r, g, b) end
        local h = fs:GetStringHeight() or 14
        if h < 10 then h = 14 end
        y = y + h + (gap or 4)
        return fs
    end
    local function Header(txt)
        y = y + 8
        Text(txt, "GameFontNormal", 1, 0.82, 0, 0, 5)
    end

    local st = QStatus(id)
    local title = QuestName(id)
    Text(title, "GameFontNormalLarge", QuestNameColor(q))
    local meta = {}
    if q.lv then meta[#meta + 1] = L["уровень "] .. q.lv end
    if q.rl then meta[#meta + 1] = L["взять можно с "] .. q.rl end
    if q.fa then meta[#meta + 1] = q.fa == "A" and L["только Альянс"] or L["только Орда"] end
    if q.cl then meta[#meta + 1] = L["классовый"] end
    if q.new then meta[#meta + 1] = L["новый квест Forever"] end
    if #meta > 0 then Text(table.concat(meta, " · "), "GameFontHighlightSmall", 0.7, 0.7, 0.7) end
    local stepTxt = StepText(id, st)
    if stepTxt and stepTxt ~= "" then Text(stepTxt, "GameFontHighlight", 0.37, 0.77, 0.56, 0, 2) end
    local objective = ns.QuestObjective(id, q)
    if objective then
        Header(L["Задание"])
        Text(objective, "GameFontHighlight", 0.9, 0.9, 0.9)
    end

    -- цепочка
    local chain, opts, nexts = ChainOf(id)
    local chainFmt = (ns.IS_RU and #chain >= 2 and #chain <= 4) and L["Цепочка: %d шага с самого начала"] or L["Цепочка: %d шагов с самого начала"]
    Header(#chain > 1 and string.format(chainFmt, #chain) or L["Цепочка"])
    if #chain <= 1 and #opts == 0 and #nexts == 0 then
        Text(L["Предквестов нет — квест можно брать сразу."] .. (q.pt and (L[" Нужен «"] .. q.pt .. "».") or ""), "GameFontHighlightSmall", 0.8, 0.8, 0.8)
    end
    local function Step(qid, num, note, dim)
        local b = CardStep(c)
        b.qid = qid
        local sst = QStatus(qid)
        b.icon:SetTexture(STATUS_ICON[sst] or TEX_UNKNOWN)
        b.icon:SetDesaturated(sst == "low" or sst == "done" or sst == "na" or sst == "closed")
        local qq = DQ[qid]
        local label = (num and (num .. ". ") or "") .. QuestName(qid) .. (qq.lv and (" [" .. qq.lv .. "]") or "")
        b.title:SetText(label)
        if sst == "done" or dim then b.title:SetTextColor(0.55, 0.55, 0.55) else b.title:SetTextColor(QuestNameColor(qq)) end
        local lines = {}
        if sst == "done" then
            lines[#lines + 1] = L["выполнено"]
        else
            local t1, w1 = StarterInfo(qid)
            local wt1 = WhereText(t1)
            lines[#lines + 1] = L["взять: "] .. w1 .. (wt1 ~= "" and (" — " .. wt1) or "")
            local t2, w2 = FinisherInfo(qid)
            if w2 and w2 ~= "?" and w2 ~= w1 then
                local wt2 = WhereText(t2)
                lines[#lines + 1] = L["сдать: "] .. w2 .. (wt2 ~= "" and (" — " .. wt2) or "")
            end
            if sst == "active" then lines[1] = L["в журнале"] end
            if sst == "low" and qq.rl then lines[#lines + 1] = L["|cffff7f4cс "] .. qq.rl .. L[" уровня|r"] end
        end
        if note then lines[#lines + 1] = note end
        b.sub:SetText(table.concat(lines, "\n"))
        b:SetPoint("TOPLEFT", c.content, "TOPLEFT", 0, -y)
        b:SetWidth(W - 4)
        b.title:SetWidth(W - 34)
        b.sub:ClearAllPoints()
        b.sub:SetPoint("TOPLEFT", b.title, "BOTTOMLEFT", 0, -2)
        b.sub:SetWidth(W - 34)
        local h = (b.title:GetStringHeight() or 14) + (b.sub:GetStringHeight() or 12) + 10
        if h < 30 then h = 30 end
        b:SetHeight(h)
        if qid == id then b.cur:Show() else b.cur:Hide() end
        y = y + h + 2
    end
    for _, o in ipairs(opts) do
        Step(o.id, nil, L["необязательно: наводка, ведёт к «"] .. QuestName(o.leadsTo) .. "»", true)
    end
    for i, e in ipairs(chain) do
        local note
        if e.alts and #e.alts > 0 then
            local names = {}
            for _, a in ipairs(e.alts) do names[#names + 1] = "«" .. QuestName(a) .. "»" end
            note = L["или вместо него: "] .. table.concat(names, ", ")
        end
        if e.group then note = (note and (note .. " · ") or "") .. L["обязателен для продолжения"] end
        Step(e.id, #chain > 1 and i or nil, note)
    end
    if #nexts > 0 then
        Text(L["Дальше по цепочке:"], "GameFontHighlightSmall", 0.7, 0.7, 0.7, 0, 2)
        for _, n in ipairs(nexts) do Step(n, nil, nil, true) end
    end

    -- награда
    local rw = q.rw
    if rw and rw.fv then
        Header(L["Награда |cff5fc48f(данные Forever)|r"])
    elseif rw then
        Header(L["Награда |cffff9f4c(по классике — в Forever ещё не проверено)|r"])
    else
        Header(L["Награда"])
    end
    local function Items(list, label)
        Text(label, "GameFontHighlightSmall", 0.85, 0.85, 0.85, 0, 3)
        local colW = math.floor((W - 8) / 2)
        for i, it in ipairs(list) do
            local b = CardItem(c)
            local iid, cnt = it[1], it[2] or 1
            b.itemID = iid
            b.icon:SetTexture(ItemIcon(iid))
            b.count:SetText(cnt > 1 and cnt or "")
            local info = DRITEM[iid]
            b.name:SetText(RewardItemColor(iid) .. RewardItemName(iid) .. "|r" .. (info and info.nw and L[" |cff73bfffНОВОЕ|r"] or ""))
            local sub = ItemSlotText(iid)
            local req = ClientMinLevel(iid) or (info and info.rq)
            if req and req > 1 then sub = sub .. (sub ~= "" and " · " or "") .. L["с "] .. req .. L[" ур."] end
            b.sub:SetText(sub)
            if not ns.CachedItemName(iid) then RequestItem(iid) end
            local col = (i - 1) % 2
            b:SetWidth(colW - 4)
            b:SetPoint("TOPLEFT", c.content, "TOPLEFT", col * colW, -y)
            if col == 1 or i == #list then y = y + 38 end
        end
        y = y + 2
    end
    if rw then
        if rw.c then Items(rw.c, #rw.c > 1 and L["На выбор (одна вещь):"] or L["Вы получите:"]) end
        if rw.i then Items(rw.i, rw.c and L["И ещё получите:"] or L["Вы получите:"]) end
        if rw.m then Text(L["Деньги: "] .. MoneyText(rw.m), "GameFontHighlight", 1, 1, 1) end
        if rw.rep then
            local names = {}
            for _, f in ipairs(rw.rep) do names[#names + 1] = FactionName(f) end
            Text(L["Репутация: "] .. table.concat(names, ", "), "GameFontHighlight", 1, 1, 1)
        end
        if rw.sp then Text(L["Плюс заклинание или способность (видно у квестодателя)."], "GameFontHighlightSmall", 0.8, 0.8, 0.8) end
    elseif q.new then
        Text(L["Данных о награде пока нет: квест новый, его ещё мало кто сделал."], "GameFontHighlightSmall", 0.8, 0.8, 0.8)
    else
        Text(L["Только опыт."], "GameFontHighlight", 1, 1, 1)
    end
    Text(L["Цвет, слот и уровень вещей берутся из клиента Forever (если вещь ещё не загрузилась — из Wowhead Forever). "] ..
        L["Опыт не пишу: в Forever его дают больше, чем в классике. "] ..
        (rw and not rw.fv and L["Список наград для этого квеста в Forever пока никто не опубликовал — точную награду видно в журнале, когда квест взят."] or ""),
        "GameFontDisableSmall", 0.6, 0.6, 0.6, 0, 2)

    c.content:SetHeight(y + 8)
    local viewH = c.sf:GetHeight() or 300
    c.maxScroll = math.max(0, y + 8 - viewH)
    local sc = math.min(oldScroll or 0, c.maxScroll)
    c.sf:SetVerticalScroll(sc)
    c.updating = true
    c.bar:SetMinMaxValues(0, c.maxScroll)
    c.bar:SetValue(sc)
    c.updating = false
    if c.maxScroll > 0 then c.bar:Show() else c.bar:Hide() end
end

function ns.ShowQuestCard(id)
    if not DQ[id] then return end
    cardID = id
    tab = "quests"
    section = "dungeons"
    if DB then DB.tab = tab; DB.section = section end
    RefreshAll()
end

local function CreateMain()
    F = CreateFrame("Frame", "ForeverGuideFrame", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
    F:SetSize(900, 580)
    F:SetPoint("CENTER")
    F:SetFrameStrata("HIGH")
    F:SetToplevel(true)
    F:SetClampedToScreen(true)
    F:SetMovable(true)
    F:EnableMouse(true)
    F:RegisterForDrag("LeftButton")
    F:SetScript("OnDragStart", F.StartMoving)
    F:SetScript("OnDragStop", F.StopMovingOrSizing)
    -- тёмный градиент, золотая рамка и тёплое свечение вокруг окна
    ns.Skin.Window(F, true, 18)
    tinsert(UISpecialFrames, "ForeverGuideFrame")

    local close = CreateFrame("Button", nil, F, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -4, -4)

    local help = MakeButton(F, "?", 24, function() end)
    help:SetHeight(22)
    help:SetPoint("RIGHT", close, "LEFT", -2, 0)

    -- выбор языка аддона
    local LANG_SHORT = { ruRU = "RU", enUS = "EN", deDE = "DE", esES = "ES", esMX = "MX", frFR = "FR", ptBR = "PT",
        koKR = "한국어", zhCN = "中文", zhTW = "繁體" }
    local LANG_OPTS = { { "auto" } }
    for _, code in ipairs(ns.LANGUAGES or {}) do LANG_OPTS[#LANG_OPTS + 1] = { code, ns.LANGUAGE_NAMES[code] } end
    local langMenu
    local langBtn = MakeButton(F, L["Язык"] .. ": " .. (LANG_SHORT[ns.LOCALE] or "EN"), 104, function(self)
        if langMenu and langMenu:IsShown() then langMenu:Hide() return end
        if not langMenu then
            langMenu = CreateFrame("Frame", nil, F, BackdropTemplateMixin and "BackdropTemplate" or nil)
            langMenu:SetFrameStrata("DIALOG")
            ns.Skin.Window(langMenu, false, 12)
            langMenu:EnableMouse(true)
            langMenu.buttons = {}
            for i, o in ipairs(LANG_OPTS) do
                local b = CreateFrame("Button", nil, langMenu)
                b:SetSize(176, 20)
                b:SetPoint("TOPLEFT", 6, -6 - (i - 1) * 20)
                ns.Skin.Hover(b)
                b.t = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                b.t:SetPoint("LEFT", 6, 0)
                b:SetScript("OnClick", function()
                    langMenu:Hide()
                    if ns.ChooseLanguage then ns.ChooseLanguage(o[1]) end
                end)
                langMenu.buttons[i] = b
            end
            langMenu:SetSize(188, 12 + #LANG_OPTS * 20)
            langMenu:Hide()
        end
        local chosen = ForeverGuideDB and ForeverGuideDB.lang
        for i, o in ipairs(LANG_OPTS) do
            local on = (o[1] == "auto" and not chosen) or o[1] == chosen
            local label = o[2] or L["Авто — как в игре"]
            langMenu.buttons[i].t:SetText(on and ("|cffffd100• " .. label .. "|r") or ("   " .. label))
        end
        langMenu:ClearAllPoints()
        langMenu:SetPoint("TOPRIGHT", self, "BOTTOMRIGHT", 0, -2)
        langMenu:Show()
    end)
    langBtn:SetHeight(22)
    langBtn:SetPoint("RIGHT", help, "LEFT", -4, 0)
    langBtn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOMLEFT")
        GameTooltip:SetText(L["Язык аддона"], 1, 0.82, 0)
        local names = {}
        for _, code in ipairs(ns.LANGUAGES or {}) do names[#names + 1] = ns.LANGUAGE_NAMES[code] end
        GameTooltip:AddLine(table.concat(names, " · "), 1, 1, 1, true)
        GameTooltip:AddLine(L["Меняет язык окна, подсказок и названий. Названия вещей и квестов берутся из базы аддона, если язык отличается от языка игры."], 0.8, 0.8, 0.8, true)
        GameTooltip:Show()
    end)
    langBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
    F:HookScript("OnHide", function() if langMenu then langMenu:Hide() end end)
    help:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOMLEFT")
        GameTooltip:SetText(ns.ADDON_TITLE .. L[" — как пользоваться"], 1, 0.82, 0)
        GameTooltip:AddLine(L["Подземелья"], 1, 0.82, 0)
        GameTooltip:AddLine(L["Слева выбери подземелье. «Квесты» — что взять и где; клик по квесту — карточка с наградой и всей цепочкой, ПКМ — метка маршрута. «Добыча» — боссы и их вещи."], 1, 1, 1, true)
        GameTooltip:AddLine(L["Поиск вещей"], 1, 0.82, 0)
        GameTooltip:AddLine(L["Впиши название или сделай Shift+клик по вещи — увидишь всех мобов, боссов, квесты и сундуки, откуда она берётся. Сортировка по шансу, уровню и зоне."], 1, 1, 1, true)
        GameTooltip:AddLine(L["Профессии"], 1, 0.82, 0)
        GameTooltip:AddLine(L["Все профессии и рецепты Forever: реагенты, навык, где выучить (тренер, торговец, добыча, Merchant's Favor). Поиск по рецепту и реагенту."], 1, 1, 1, true)
        GameTooltip:AddLine(L["Книги"], 1, 0.82, 0)
        GameTooltip:AddLine(L["Библиотечные книги с точками на карте и прогрессом. Можно выключить совсем."], 1, 1, 1, true)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine(L["Команды: /гид · /найти <вещь> · /гид <подземелье> · /гид профы · /книги · /гид подсказки"], 0.6, 0.8, 1, true)
        GameTooltip:AddLine(L["Язык: кнопка «Язык» вверху окна или /гид язык"], 0.6, 0.8, 1, true)
        GameTooltip:AddLine(L["Зелёная пометка — данные Forever, оранжевая — классическая база."], 0.6, 0.6, 0.6, true)
        GameTooltip:Show()
    end)
    help:SetScript("OnLeave", function() GameTooltip:Hide() end)

    local logo = F:CreateTexture(nil, "ARTWORK")
    logo:SetSize(30, 30)
    logo:SetPoint("TOPLEFT", 14, -10)
    logo:SetTexture(TEX_BUTTON)
    logo:SetTexCoord(0, 1, 0, 1)
    local title = F:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("LEFT", logo, "RIGHT", 8, 0)
    local version = ""
    local meta = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
    if meta then
        local ok, v = pcall(meta, ADDON, "Version")
        if ok and v then version = v end
    end
    title:SetText(ns.ADDON_TITLE .. (version ~= "" and ("  |cff888888" .. version .. "|r") or ""))
    local tagline = F:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    tagline:SetPoint("LEFT", title, "RIGHT", 12, -1)
    tagline:SetText(ns.ADDON_TAGLINE or L["квесты подземелий · добыча · поиск вещей · профессии · книги"])

    -- верхние вкладки
    local ICON = "|TInterface\\Icons\\%s:16:16:0:0:64:64:5:59:5:59|t  "
    local TABS = {
        { "dungeons", ICON:format("INV_Misc_Bone_HumanSkull_01") .. L["Подземелья"] },
        { "search", ICON:format("INV_Misc_Spyglass_03") .. L["Поиск вещей"] },
        { "profs", ICON:format("Trade_BlackSmithing") .. L["Профессии"] },
        { "books", ICON:format("INV_Misc_Book_09") .. L["Книги"] },
    }
    for i, t in ipairs(TABS) do
        local b = MakeButton(F, t[2], 162, function()
            section = t[1]
            DB.section = section
            cardID = nil
            RefreshAll(true)
        end)
        b:SetHeight(26)
        if i == 1 then b:SetPoint("TOPLEFT", 12, -42) else b:SetPoint("LEFT", topTabs[i - 1], "RIGHT", 4, 0) end
        b.section = t[1]
        topTabs[i] = b
    end
    local line = F:CreateTexture(nil, "ARTWORK")
    line:SetTexture(ns.Skin.MEDIA .. "bar") -- розово-оранжево-жёлтая линия под вкладками
    line:SetHeight(2)
    line:SetPoint("TOPLEFT", 12, -72)
    line:SetPoint("TOPRIGHT", -12, -72)

    local function View()
        local v = CreateFrame("Frame", nil, F)
        v:SetPoint("TOPLEFT", 12, -78)
        v:SetPoint("BOTTOMRIGHT", -12, 34)
        v:Hide()
        return v
    end
    views.dungeons, views.search, views.books, views.profs = View(), View(), View(), View()

    -- левая колонка
    local left = CreateFrame("Frame", nil, views.dungeons, BackdropTemplateMixin and "BackdropTemplate" or nil)
    left:SetPoint("TOPLEFT", 0, 0)
    left:SetPoint("BOTTOMLEFT", 0, 0)
    left:SetWidth(262)
    local lbg = ns.Skin.Panel(left)
    dungeonList = CreateScrollList(left, 30, CreateDungeonRow, UpdateDungeonRow)
    dungeonList:SetPoint("TOPLEFT", 2, -2)
    dungeonList:SetPoint("BOTTOMRIGHT", -2, 2)

    -- правая часть: шапка
    local right = CreateFrame("Frame", nil, views.dungeons)
    right:SetPoint("TOPLEFT", left, "TOPRIGHT", 10, 0)
    right:SetPoint("BOTTOMRIGHT", 0, 0)

    header.title = right:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    header.title:SetPoint("TOPLEFT", 2, -2)
    header.title:SetPoint("RIGHT", -150, 0)
    header.title:SetJustifyH("LEFT")
    header.title:SetWordWrap(false)
    header.sub = right:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    header.sub:SetPoint("TOPLEFT", header.title, "BOTTOMLEFT", 0, -4)
    header.sub:SetPoint("RIGHT", -4, 0)
    header.sub:SetJustifyH("LEFT")
    header.sub:SetWordWrap(false)

    header.entrance = MakeButton(right, L["Метка на вход"], 140, function()
        if selected and selected.map then
            WaypointTarget({ map = selected.map, x = selected.x, y = selected.y }, DName(selected) .. L[" — вход"])
        end
    end)
    header.entrance:SetPoint("TOPRIGHT", 0, 0)

    header.tabQuests = MakeButton(right, L["Квесты"], 130, function() tab = "quests"; DB.tab = tab; cardID = nil; RefreshAll(true) end)
    header.tabQuests:SetPoint("TOPLEFT", header.sub, "BOTTOMLEFT", -2, -8)
    header.tabLoot = MakeButton(right, L["Добыча"], 130, function() tab = "loot"; DB.tab = tab; cardID = nil; RefreshAll(true) end)
    header.tabLoot:SetPoint("LEFT", header.tabQuests, "RIGHT", 4, 0)

    -- панель фильтров квестов
    local qbar = CreateFrame("Frame", nil, right)
    qbar:SetPoint("TOPLEFT", header.tabQuests, "BOTTOMLEFT", 0, -6)
    qbar:SetPoint("RIGHT", 0, 0)
    qbar:SetHeight(24)
    header.qbar = qbar
    header.showDone = MakeCheck(qbar, L["Выполненные"], function(v) DB.showDone = v; RefreshAll() end)
    header.showDone:SetPoint("LEFT", 0, 0)
    header.showAll = MakeCheck(qbar, L["Чужие (фракция/класс)"], function(v) DB.showAll = v; RefreshAll() end)
    header.showAll:SetPoint("LEFT", header.showDone, "RIGHT", 90, 0)
    header.track = MakeCheck(qbar, L["Показать на карте"], function(v)
        DB.track = v and selected and selected.key or nil
        if ns.QueueRefresh then ns.QueueRefresh() end
        if v then Print((selected and DName(selected) or "") .. L[": квестодатели на карте мира и миникарте (миникарта — если стоит Questie/HereBeDragons)."]) end
    end)
    header.track:SetPoint("LEFT", header.showAll, "RIGHT", 150, 0)
    header.all = MakeButton(qbar, L["Метки на всё"], 110, AllWaypoints)
    header.all:SetPoint("RIGHT", 0, 0)

    local listArea = CreateFrame("Frame", nil, right)
    header.listArea = listArea
    listArea:SetPoint("TOPLEFT", qbar, "BOTTOMLEFT", 0, -4)
    listArea:SetPoint("BOTTOMRIGHT", 0, 0)
    local abg = ns.Skin.Panel(listArea)

    questList = CreateScrollList(listArea, 46, CreateQuestRow, UpdateQuestRow)
    questList:SetPoint("TOPLEFT", 2, -2)
    questList:SetPoint("BOTTOMRIGHT", -2, 2)

    lootList = CreateScrollList(right, 22, CreateLootRow, UpdateLootRow)
    lootList:SetPoint("TOPLEFT", header.tabQuests, "BOTTOMLEFT", 2, -6)
    lootList:SetPoint("BOTTOMRIGHT", -2, 2)
    local lbg2 = ns.Skin.Panel(lootList)

    card = CreateCard(right)
    card:SetPoint("TOPLEFT", header.tabQuests, "BOTTOMLEFT", 2, -6)
    card:SetPoint("BOTTOMRIGHT", -2, 2)
    card:Hide()

    if ns.CreateSearchPanel then
        local sp = ns.CreateSearchPanel(views.search)
        sp:SetAllPoints(views.search)
    end
    if ns.CreateBooksPanel then
        local bp = ns.CreateBooksPanel(views.books)
        bp:SetAllPoints(views.books)
    end
    if ns.CreateProfessionsPanel then
        local pp = ns.CreateProfessionsPanel(views.profs)
        pp:SetAllPoints(views.profs)
    end

    header.empty = listArea:CreateFontString(nil, "OVERLAY", "GameFontDisable")
    header.empty:SetPoint("TOP", 0, -30)
    header.empty:SetWidth(460)

    foot = F:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    foot:SetPoint("BOTTOMLEFT", 16, 13)
    foot:SetPoint("BOTTOMRIGHT", -16, 13)
    foot:SetJustifyH("LEFT")

    F:SetScript("OnShow", function() RefreshAll(true) end)
    F:Hide()
end

local function PickDefault()
    if DB.sel then
        local d = DungeonOf(DB.sel)
        if d then return d end
    end
    local lvl = PlayerLevel()
    local best
    for _, d in ipairs(DUNGEONS) do
        if d.min and lvl >= d.min - 3 and lvl <= d.max then
            best = best or d
        end
    end
    return best or DUNGEONS[1]
end

function ns.ToggleDungeons(key)
    if not F then CreateMain() end
    if key then
        selected = DungeonOf(key) or selected
        cardID = nil
    end
    if not selected then selected = PickDefault() end
    if DB.tab == "search" then DB.tab = "quests"; DB.section = "search" end
    tab = DB.tab or "quests"
    section = key and "dungeons" or DB.section or "dungeons"
    if key then DB.section = section end
    if F:IsShown() and not key then
        F:Hide()
    else
        F:Show()
        RefreshAll(true)
        -- прокрутить список подземелий к выбранному
        for i, d in ipairs(DUNGEONS) do
            if d == selected then
                dungeonList.offset = math.max(0, i - 4)
                dungeonList:Refresh()
                break
            end
        end
    end
end

---------------------------------------------------------------------------
-- Кнопка у миникарты
---------------------------------------------------------------------------

local mmButton
local function PlaceMinimapButton()
    local a = math.rad(MM.angle or 200)
    local r = (Minimap:GetWidth() / 2) + 8
    mmButton:ClearAllPoints()
    mmButton:SetPoint("CENTER", Minimap, "CENTER", math.cos(a) * r, math.sin(a) * r)
end

local function CreateMinimapButton()
    if mmButton or not Minimap then return end
    local b = CreateFrame("Button", "ForeverGuideMinimapButton", Minimap)
    b:SetSize(31, 31)
    b:SetFrameStrata("MEDIUM")
    b:SetFrameLevel(8)
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    b:RegisterForDrag("LeftButton")
    local overlay = b:CreateTexture(nil, "OVERLAY")
    overlay:SetSize(53, 53)
    overlay:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    overlay:SetPoint("TOPLEFT")
    local bg = b:CreateTexture(nil, "BACKGROUND")
    bg:SetSize(20, 20)
    bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
    bg:SetPoint("TOPLEFT", 7, -5)
    local icon = b:CreateTexture(nil, "ARTWORK")
    icon:SetSize(19, 19)
    if ns.Skin and ns.Skin.ICON_MM then
        icon:SetTexture(ns.Skin.ICON_MM) -- только компас: вокруг и так круглая рамка миникарты
    else
        icon:SetTexture(TEX_BUTTON)
        icon:SetTexCoord(0.12, 0.88, 0.12, 0.88)
    end
    icon:SetPoint("TOPLEFT", 6, -5)
    b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    b:SetScript("OnClick", function(_, button)
        if button == "RightButton" then
            ns.OpenBooks()
        else
            ns.ToggleDungeons()
        end
    end)
    b:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local cx, cy = GetCursorPosition()
            local s = Minimap:GetEffectiveScale()
            cx, cy = cx / s, cy / s
            MM.angle = math.deg(math.atan2(cy - my, cx - mx))
            PlaceMinimapButton()
        end)
    end)
    b:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText(ns.ADDON_TITLE, 1, 0.82, 0)
        GameTooltip:AddLine(L["ЛКМ — окно: подземелья, поиск вещей, книги"], 1, 1, 1)
        GameTooltip:AddLine(L["ПКМ — вкладка «Книги»"], 1, 1, 1)
        GameTooltip:AddLine(L["Перетащи, чтобы передвинуть"], 0.6, 0.6, 0.6)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    mmButton = b
    PlaceMinimapButton()
    if MM.hide then b:Hide() end
end

---------------------------------------------------------------------------
-- События и команды
---------------------------------------------------------------------------

local pending = false
function ns.OnQuestChanged()
    if pending then return end
    pending = true
    C_Timer.After(0.5, function()
        pending = false
        if F and F:IsShown() then RefreshAll() end
    end)
end

function ns.OnLogin()
    local root = ForeverGuideDB
    root.dq = root.dq or {}
    root.mmbtn = root.mmbtn or { angle = 200 }
    DB, MM = root.dq, root.mmbtn
    if DB.showDone == nil then DB.showDone = false end
    if DB.showAll == nil then DB.showAll = false end
    CreateMinimapButton()
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LEVEL_UP")
local itemPending = false
-- пришёл предмет, который мы сами просили: перерисовать добычу/карточку (не чаще раза в 0.5 с)
ns.OnItemData(function()
    if itemPending or not (F and F:IsShown()) then return end
    if section ~= "dungeons" or (tab ~= "loot" and not cardID) then return end
    itemPending = true
    C_Timer.After(0.5, function()
        itemPending = false
        if not (F and F:IsShown()) then return end
        if tab == "loot" then
            lootList:Refresh()
        elseif cardID and card and card:IsShown() then
            RenderCard(cardID, true)
        end
    end)
end)
ev:SetScript("OnEvent", function()
    ns.OnQuestChanged()
end)

-- string.lower не трогает кириллицу: переводим А-Я/Ё в строчные вручную (UTF-8).
local function LowerRU(s)
    s = string.lower(s or "")
    s = s:gsub("\208([\144-\159])", function(c) return "\208" .. string.char(c:byte() + 32) end)
    s = s:gsub("\208([\160-\175])", function(c) return "\209" .. string.char(c:byte() - 32) end)
    s = s:gsub("\208\129", "\209\145")
    -- латиница с диакритикой (Ä, É, Ñ, Ç, Õ …) → строчные
    s = s:gsub("\195([\128-\158])", function(c)
        if c == "\151" then return "\195\151" end
        return "\195" .. string.char(c:byte() + 32)
    end)
    return s
end

local ALIASES = {
    ["оп"] = "rfc", ["огненная"] = "rfc", ["пс"] = "wc", ["мк"] = "dm", ["копи"] = "dm", ["ктк"] = "sfk",
    ["нп"] = "bfd", ["пучина"] = "bfd", ["тюрьма"] = "stocks", ["гномер"] = "gnomer", ["ли"] = "rfk",
    ["ки"] = "rfd", ["мао"] = "smgy", ["кладбище"] = "smgy", ["библиотека"] = "smlib", ["оружейная"] = "smarm",
    ["собор"] = "smcath", ["ульда"] = "ulda", ["зф"] = "zf", ["маро"] = "mara", ["храм"] = "st", ["зх"] = "st",
    ["бгг"] = "brd", ["гчг"] = "brd", ["нпчг"] = "lbrs", ["впчг"] = "ubrs", ["некро"] = "scholo", ["шоло"] = "scholo",
    ["страт"] = "stratlive", ["андед"] = "stratdead", ["зг"] = "dme", ["лордерон"] = "lordaeron", ["таны"] = "thanes",
    -- English
    ["vc"] = "dm", ["deadmines"] = "dm", ["sm"] = "smgy", ["gy"] = "smgy", ["lib"] = "smlib", ["arm"] = "smarm",
    ["cath"] = "smcath", ["uld"] = "ulda", ["strat"] = "stratlive", ["ud"] = "stratdead", ["dm e"] = "dme",
    ["dm n"] = "dmn", ["dm w"] = "dmw", ["scholo"] = "scholo", ["sunken"] = "st", ["stockade"] = "stocks",
}

local function DungeonSlash(msg)
    msg = strtrim(LowerRU(msg or ""))
    if msg == "подсказки" or msg == "tips" then
        DB.tipSources = DB.tipSources == false
        Print(DB.tipSources and L["Источники вещей в подсказках включены."] or L["Источники вещей в подсказках выключены."])
        return
    end
    local lg = msg:match("^язык%s*(.*)$") or msg:match("^lang%s*(.*)$") or msg:match("^language%s*(.*)$")
    if lg then
        local map = { ru = "ruRU", ["рус"] = "ruRU", ["русский"] = "ruRU", en = "enUS", eng = "enUS", english = "enUS", ["англ"] = "enUS",
            zh = "zhCN", cn = "zhCN", ["中文"] = "zhCN", ["简体"] = "zhCN", ["简体中文"] = "zhCN", tw = "zhTW", ["繁體"] = "zhTW", ["繁体"] = "zhTW",
            ["繁體中文"] = "zhTW", auto = "auto", ["авто"] = "auto", ["自动"] = "auto", ["自動"] = "auto",
            de = "deDE", deu = "deDE", deutsch = "deDE", german = "deDE",
            es = "esES", esp = "esES", ["español"] = "esES", espanol = "esES", spanish = "esES", eu = "esES",
            mx = "esMX", esmx = "esMX", al = "esMX", latam = "esMX", ["español (al)"] = "esMX",
            fr = "frFR", ["français"] = "frFR", francais = "frFR", french = "frFR",
            pt = "ptBR", br = "ptBR", ptbr = "ptBR", ["português"] = "ptBR", portugues = "ptBR", portuguese = "ptBR",
            ko = "koKR", kr = "koKR", ["한국어"] = "koKR", korean = "koKR", ["자동"] = "auto",
            ru_ru = "ruRU", en_us = "enUS" }
        for _, c in ipairs(ns.LANGUAGES or {}) do map[string.lower(c)] = c end
        local code = map[strtrim(lg)]
        if code then
            ns.ChooseLanguage(code)
        else
            Print(L["Язык аддона: "] .. ((ns.LANGUAGE_NAMES or {})[ns.LOCALE] or ns.LOCALE) .. L[". Сменить: /гид язык ru / en / de / fr / es / mx / pt / ko / zh / tw / авто"])
        end
        return
    end
    if msg == "профы" or msg == "профессии" or msg == "prof" or msg == "profs" or msg == "professions" then
        ns.OpenProfessions()
        return
    end
    local q = msg:match("^поиск%s*(.*)$") or msg:match("^search%s*(.*)$")
    if q then
        ns.OpenSearch(q)
        return
    end
    if msg == "кнопка" or msg == "button" then
        MM.hide = not MM.hide
        if mmButton then if MM.hide then mmButton:Hide() else mmButton:Show() end end
        Print(MM.hide and L["Кнопка у миникарты скрыта."] or L["Кнопка у миникарты снова видна."])
        return
    end
    if msg ~= "" then
        if ALIASES[msg] then
            ns.ToggleDungeons(ALIASES[msg])
            return
        end
        for _, d in ipairs(DUNGEONS) do
            if d.key == msg or LowerRU(d.ru):find(msg, 1, true) or LowerRU(d.en):find(msg, 1, true) or LowerRU(DName(d)):find(msg, 1, true) then
                ns.ToggleDungeons(d.key)
                return
            end
        end
        Print(L["Подземелье «"] .. msg .. L["» не найдено. Примеры: /гид мк, /гид пещеры, /гид страт"])
        return
    end
    ns.ToggleDungeons()
end

SLASH_FOREVERGUIDE_MAIN1 = "/данж"
SLASH_FOREVERGUIDE_MAIN2 = "/подземелья"
SLASH_FOREVERGUIDE_MAIN3 = "/dungeons"
SLASH_FOREVERGUIDE_MAIN4 = "/fld"
SLASH_FOREVERGUIDE_MAIN5 = "/гид"
SLASH_FOREVERGUIDE_MAIN6 = "/fguide"
SlashCmdList.FOREVERGUIDE_MAIN = DungeonSlash

-- для тестов
function ns.OpenSearch(text)
    if not F then CreateMain() end
    if not selected then selected = PickDefault() end
    section = "search"
    DB.section = section
    cardID = nil
    if not F:IsShown() then F:Show() end
    RefreshAll(true)
    if text and text ~= "" and ns.SearchSetQuery then ns.SearchSetQuery(text) end
end

function ns.OpenDungeonLoot(key)
    if not F then CreateMain() end
    selected = DungeonOf(key) or selected
    DB.sel = selected and selected.key
    tab = "loot"
    DB.tab = tab
    section = "dungeons"
    DB.section = section
    cardID = nil
    if not F:IsShown() then F:Show() end
    RefreshAll(true)
end

function ns.OpenProfessions(key)
    if not F then CreateMain() end
    section = "profs"
    DB.section = section
    cardID = nil
    if not F:IsShown() then F:Show() end
    RefreshAll(true)
end

function ns.OpenRecipe(key, r)
    ns.OpenProfessions()
    if ns.ShowRecipe then ns.ShowRecipe(key, r) end
end

function ns.OpenBooks()
    if not F then CreateMain() end
    if not selected then selected = PickDefault() end
    section = "books"
    DB.section = section
    cardID = nil
    if not F:IsShown() then F:Show() end
    RefreshAll(true)
end

ns._ui = {
    CreateScrollList = CreateScrollList, MakeButton = MakeButton, ItemIcon = ItemIcon, ItemQualityHex = ItemQualityHex,
    RequestItem = RequestItem, ItemLink = ItemLink, ClientSlot = ClientSlot, LowerRU = LowerRU, QuestName = QuestName,
    WaypointTarget = WaypointTarget, MakeCheck = MakeCheck,
}

ns._dq = { ChainOf = ChainOf, LowerRU = LowerRU, QStatus = QStatus, NextStep = NextStep, StepText = StepText, DungeonQuests = DungeonQuests, LootRows = LootRows }
