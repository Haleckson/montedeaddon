-- Путеводитель Forever: вкладка «Профессии» — все профессии и рецепты Forever.
-- Рецепты, реагенты и пороги навыка — из клиента Forever (ProfessionData.lua).
-- Тренеры — база Questie для Forever; торговцы рецептами — классическая база.

local ADDON, ns = ...
local L = ns.L

local function U() return ns._ui end
local function Print(msg) if ns.Print then ns.Print(msg) end end
local function PlayerFac() return UnitFactionGroup("player") == "Alliance" and "A" or "H" end

local PROF_RU = {
    alchemy = "Алхимия", blacksmithing = "Кузнечное дело", enchanting = "Наложение чар",
    engineering = "Инженерное дело", leatherworking = "Кожевничество", tailoring = "Портняжное дело",
    mining = "Горное дело", herbalism = "Травничество", skinning = "Снятие шкур",
    cooking = "Кулинария", ["first-aid"] = "Первая помощь", fishing = "Рыбная ловля",
}
local PROF_EN = {
    alchemy = "Alchemy", blacksmithing = "Blacksmithing", enchanting = "Enchanting", engineering = "Engineering",
    leatherworking = "Leatherworking", tailoring = "Tailoring", mining = "Mining", herbalism = "Herbalism",
    skinning = "Skinning", cooking = "Cooking", ["first-aid"] = "First Aid", fishing = "Fishing",
}
-- названия профессий на всех языках клиента (для поиска навыка в списке навыков игры)
local PROF_ALL = {
    alchemy = { "炼金术", "鍊金術", "Alchemie", "Alquimia", "Alchimie", "연금술" },
    blacksmithing = { "锻造", "鍛造", "Schmiedekunst", "Herrería", "Forge", "Ferraria", "대장기술" },
    enchanting = { "附魔", "Verzauberkunst", "Encantamiento", "Enchantement", "Encantamento", "마법부여" },
    engineering = { "工程学", "工程學", "Ingenieurskunst", "Ingeniería", "Ingénierie", "Engenharia", "기계공학" },
    leatherworking = { "制皮", "製皮", "Lederverarbeitung", "Peletería", "Travail du cuir", "Couraria", "가죽세공" },
    tailoring = { "裁缝", "裁縫", "Schneiderei", "Sastrería", "Couture", "Alfaiataria", "재봉술" },
    mining = { "采矿", "採礦", "Bergbau", "Minería", "Minage", "Mineração", "채광" },
    herbalism = { "草药学", "草藥學", "Kräuterkunde", "Herboristería", "Herboristerie", "Herborismo", "약초채집" },
    skinning = { "剥皮", "剝皮", "Kürschnerei", "Desuello", "Dépeçage", "Esfolamento", "무두질" },
    cooking = { "烹饪", "烹飪", "Kochkunst", "Cocina", "Cuisine", "Culinária", "요리" },
    ["first-aid"] = { "急救", "Erste Hilfe", "Primeros auxilios", "Secourisme", "Primeiros Socorros", "응급치료" },
    fishing = { "钓鱼", "釣魚", "Angeln", "Pesca", "Pêche", "낚시" },
}
local PROF_ICON = {
    alchemy = "Trade_Alchemy", blacksmithing = "Trade_BlackSmithing", enchanting = "Trade_Engraving",
    engineering = "Trade_Engineering", leatherworking = "INV_Misc_ArmorKit_17", tailoring = "Trade_Tailoring",
    mining = "Trade_Mining", herbalism = "Trade_Herbalism", skinning = "INV_Misc_Pelt_Wolf_01",
    cooking = "INV_Misc_Food_15", ["first-aid"] = "Spell_Holy_SealOfSacrifice", fishing = "Trade_Fishing",
}
local RANK_CAP = { [2] = 150, [3] = 225, [4] = 300 }
-- Торговцы рецептами за Merchant's Favor (по данным беты)
local MF_POSTS = {
    { fa = "A", map = 1433, x = 9.5, y = 71.0, name = "Три Угла, Красногорье" },
    { fa = "H", map = 1413, x = 50.0, y = 29.0, name = "Степи, к западу от Перекрёстка" },
}

local function ProfName(key) return L[PROF_RU[key] or key] end
local function SectionName(en) return (ns.PSEC and ns.PSEC[en]) or en end

local DB, known
local skills = {}          -- key -> {rank, max}
local cur                  -- выбранная профессия (key)
local panel, profList, recipeList, header, bar, back, secPopup
local searchText, secFilter = "", 0
local cardRecipe           -- открытая карточка (запись рецепта)

---------------------------------------------------------------------------
-- Данные
---------------------------------------------------------------------------

local function ProfByKey(key)
    for _, p in ipairs(ns.PROFS or {}) do if p.key == key then return p end end
end

local function ItemNameAny(id)
    if not id then return "?" end
    local cn = ns.CachedItemName(id)
    if cn then return cn end
    local raw = ns.PNAME and ns.PNAME[id]
    local en, ru
    if raw then en, ru = raw:match("^([^\t]*)\t?(.*)$") end
    local n = ns.Loc("i", id, (en and en ~= "") and en or nil, (ru and ru ~= "") and ru or nil)
    return n or ("#" .. id)
end

-- Название рецепта на языке клиента (для сверки с окном профессии)
local function ClientRecipeName(r)
    if r.s and GetSpellInfo then
        local ok, n = pcall(GetSpellInfo, r.s)
        if ok and type(n) == "string" and n ~= "" then return n end
    end
    return r.n
end

local nameCache = {}
local function RecipeName(r)
    local c = nameCache[r]
    if c then return c end
    if r.s and GetSpellInfo and ns.CLIENT_NAMES ~= false then
        local ok, n = pcall(GetSpellInfo, r.s)
        if ok and type(n) == "string" and n ~= "" then
            nameCache[r] = n
            return n
        end
    end
    if r.i then
        local n = ItemNameAny(r.i)
        if n and n:sub(1, 1) ~= "#" then return n end
    end
    return r.n
end

local function RecipeIcon(r)
    if r.i then return U().ItemIcon(r.i) end
    if r.s and GetSpellTexture then
        local ok, t = pcall(GetSpellTexture, r.s)
        if ok and t then return t end
    end
    return "Interface\\Icons\\INV_Misc_QuestionMark"
end

local function IsKnown(r)
    if not r.s then return false end
    if known and known[r.s] then return true end
    if IsPlayerSpell then
        local ok, v = pcall(IsPlayerSpell, r.s)
        if ok and v then return true end
    end
    if IsSpellKnown then
        local ok, v = pcall(IsSpellKnown, r.s)
        if ok and v then return true end
    end
    return false
end

local function ScanSkills()
    for k in pairs(skills) do skills[k] = nil end
    if not (GetNumSkillLines and GetSkillLineInfo) then return end
    local names = {}
    local ok, n = pcall(GetNumSkillLines)
    for i = 1, (ok and n or 0) do
        local ok2, name, isHeader, _, rank, _, _, maxRank = pcall(GetSkillLineInfo, i)
        if ok2 and name and not isHeader then names[name] = { rank or 0, maxRank or 0 } end
    end
    for _, p in ipairs(ns.PROFS or {}) do
        local cand = { ProfName(p.key), PROF_EN[p.key], PROF_RU[p.key] }
        for _, z in ipairs(PROF_ALL[p.key] or {}) do cand[#cand + 1] = z end
        if GetSpellInfo then
            local ok3, sn = pcall(GetSpellInfo, p.spell)
            if ok3 and sn then cand[#cand + 1] = sn end
        end
        for _, c in ipairs(cand) do
            if c and names[c] then skills[p.key] = names[c]; break end
        end
    end
end

-- Индексы для поиска вещей: кем создаётся, где нужна, какой рецепт учит.
local byItem, byReagent, byRecipeItem
local function BuildIndexes()
    if byItem then return end
    byItem, byReagent, byRecipeItem = {}, {}, {}
    for key, recs in pairs(ns.PREC or {}) do
        for _, r in ipairs(recs) do
            local e = { key = key, r = r }
            if r.i then byItem[r.i] = byItem[r.i] or {}; table.insert(byItem[r.i], e) end
            if r.src then byRecipeItem[r.src] = byRecipeItem[r.src] or {}; table.insert(byRecipeItem[r.src], e) end
            for i = 1, #r.r, 2 do
                local id = r.r[i]
                byReagent[id] = byReagent[id] or {}
                table.insert(byReagent[id], e)
            end
        end
    end
end

function ns.ProfIndex(kind, id)
    BuildIndexes()
    if kind == "item" then return byItem[id] end
    if kind == "reagent" then return byReagent[id] end
    if kind == "recipe" then return byRecipeItem[id] end
end
ns.ProfName = ProfName
ns.ProfRecipeName = RecipeName

---------------------------------------------------------------------------
-- Цвета и тексты
---------------------------------------------------------------------------

local C_ORANGE, C_YELLOW, C_GREEN, C_GREY, C_RED = "|cffff8040", "|cffffff00", "|cff40bf40", "|cff808080", "|cffff3030"

local function SkillNumbers(r)
    return C_ORANGE .. (r.l or "?") .. "|r " .. C_YELLOW .. (r.y or "?") .. "|r " .. C_GREEN .. (r.g or "?") .. "|r " .. C_GREY .. (r.x or "?") .. "|r"
end

-- Цвет рецепта для навыка игрока (как в окне профессии)
local function Difficulty(r, skill)
    if not skill then return nil end
    if r.l and skill < r.l then return C_RED end
    if r.y and skill < r.y then return C_ORANGE end
    if r.g and skill < r.g then return C_YELLOW end
    if r.x and skill < r.x then return C_GREEN end
    return C_GREY
end

local function SourceShort(r)
    if r.tr then return L["Тренер"] end
    if r.mf then return "|cff5fc48fMF " .. r.mf .. "|r" end
    if r.src then
        local q = r.sq
        if q and ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[q] and ITEM_QUALITY_COLORS[q].hex then
            local hex = ITEM_QUALITY_COLORS[q].hex
            if hex:sub(1, 2) ~= "|c" then hex = "|c" .. hex end
            return hex .. L["Рецепт"] .. "|r"
        end
        return L["Рецепт"]
    end
    return "?"
end

local function ReagentText(r, withBags)
    local parts = {}
    for i = 1, #r.r, 2 do
        local id, cnt = r.r[i], r.r[i + 1]
        local s = cnt .. "× " .. ItemNameAny(id)
        if withBags and GetItemCount then
            local have = GetItemCount(id, true) or 0
            s = s .. ((have >= cnt) and (" |cff40bf40(" .. have .. ")|r") or (" |cffff6060(" .. have .. ")|r"))
        end
        parts[#parts + 1] = s
    end
    return table.concat(parts, ", ")
end

local function StatusTag(r)
    if r.st == "n" then return " |cff73bfff★|r" end
    if r.st == "c" or r.st == "m" then return " |cffffd100◆|r" end
    return ""
end

---------------------------------------------------------------------------
-- Тренеры
---------------------------------------------------------------------------

local function Dist(m, x, y)
    if not (ns.PlayerWorld and C_Map and C_Map.GetWorldPosFromMapPos and CreateVector2D) then return nil end
    local cont, pos = ns.PlayerWorld()
    if not cont then return nil end
    local ok, c2, p2 = pcall(C_Map.GetWorldPosFromMapPos, m, CreateVector2D(x / 100, y / 100))
    if not ok or not c2 or c2 ~= cont or not p2 then return nil end
    local ax, ay = pos:GetXY()
    local bx, by = p2:GetXY()
    return math.sqrt((ax - bx) ^ 2 + (ay - by) ^ 2)
end

local function Trainers(key, minSkill)
    local fac = PlayerFac()
    local out = {}
    for _, t in ipairs((ns.PTRAIN or {})[key] or {}) do
        local cap = RANK_CAP[t.rk]
        if t.fr:find(fac, 1, true) and (not minSkill or not cap or cap >= minSkill) then
            out[#out + 1] = { t = t, d = Dist(t.m, t.x, t.y) }
        end
    end
    table.sort(out, function(a, b)
        if a.d and b.d then return a.d < b.d end
        if a.d or b.d then return a.d ~= nil end
        return (a.t.rk or 0) > (b.t.rk or 0)
    end)
    return out
end

local function TrainerName(t) return ns.Loc("n", t.id, t.n, t.r ~= "" and t.r or nil) end

local RANK_TEXT = { [2] = "до 150", [3] = "до 225", [4] = "до 300" }

local function TrainerLine(e)
    local t = e.t
    local s = TrainerName(t) .. " — " .. (ns.ZoneName and ns.ZoneName(t.m) or "") .. string.format(" %.0f, %.0f", t.x, t.y)
    if RANK_TEXT[t.rk] then s = s .. " · " .. L[RANK_TEXT[t.rk]] end
    if e.d then s = s .. string.format(L[" · ~%d м"], math.floor(e.d + 0.5)) end
    return s
end

local function GoTrainer(e)
    local t = e.t
    U().WaypointTarget({ map = t.m, x = t.x, y = t.y }, TrainerName(t) .. " (" .. ProfName(cur) .. ")")
end

---------------------------------------------------------------------------
-- Список рецептов
---------------------------------------------------------------------------

local function Lower(s) return U().LowerRU(s or "") end

local function Matches(r, q)
    if q == "" then return true end
    if Lower(RecipeName(r)):find(q, 1, true) or Lower(r.n):find(q, 1, true) then return true end
    for i = 1, #r.r, 2 do
        local id = r.r[i]
        if Lower(ItemNameAny(id)):find(q, 1, true) then return true end
        local raw = ns.PNAME and ns.PNAME[id]
        if raw and Lower(raw):find(q, 1, true) then return true end
    end
    return false
end

local function BuildRows()
    local recs = (ns.PREC or {})[cur] or {}
    local q = Lower(strtrim(searchText or ""))
    local rows = {}
    for _, r in ipairs(recs) do
        if (DB.sod or not r.sod or secFilter ~= 0)
            and (secFilter == 0 or r.sec == secFilter)
            and (not DB.onlyNew or r.st == "n")
            and (not DB.hideKnown or not IsKnown(r))
            and Matches(r, q) then
            rows[#rows + 1] = { kind = "recipe", r = r }
        end
    end
    return rows
end

local counts = {}
local function Counts(key)
    local c = counts[key]
    if c then return c end
    c = { all = 0, new = 0, mf = 0, sod = 0 }
    for _, r in ipairs((ns.PREC or {})[key] or {}) do
        if r.sod then c.sod = c.sod + 1 else
            c.all = c.all + 1
            if r.st == "n" then c.new = c.new + 1 end
            if r.mf then c.mf = c.mf + 1 end
        end
    end
    counts[key] = c
    return c
end

---------------------------------------------------------------------------
-- Карточка рецепта
---------------------------------------------------------------------------

local function CardRows(r, key)
    local rows = {}
    local function head(t) rows[#rows + 1] = { kind = "head", text = t } end
    local function note(t) rows[#rows + 1] = { kind = "note", text = t } end
    local function src(t) rows[#rows + 1] = t; t.kind = "src" end
    rows[#rows + 1] = { kind = "rhead", r = r }
    if r.st == "n" then
        note(L["|cff73bfff★ Новый рецепт Forever|r — в классике его не было."])
    elseif r.st == "c" or r.st == "m" then
        note(L["|cffffd100◆ Изменён в Forever.|r"] .. (r.note and (ns.LOCALE ~= "enUS" and L[" Что поменялось (англ.): "] or " ") .. "|cffbbbbbb" .. r.note .. "|r" or ""))
    end
    if r.sod then note(L["Рецепт из раздела Season of Discovery: он есть в клиенте Forever, но учат ли ему на бете — не подтверждено."]) end
    head(L["Навык"])
    local skill = skills[key] and skills[key][1]
    note(L["Выучить с: "] .. C_ORANGE .. (r.l or "?") .. "|r" .. (r.l and "" or L[" (для рецептов у тренера это знает только сервер)"]) ..
        "   " .. L["жёлтый: "] .. C_YELLOW .. (r.y or "?") .. "|r   " .. L["зелёный: "] .. C_GREEN .. (r.g or "?") .. "|r   " .. L["серый: "] .. C_GREY .. (r.x or "?") .. "|r")
    if skill then
        local d = Difficulty(r, skill)
        note(L["Твой навык: "] .. skill .. " — " .. (d == C_RED and (C_RED .. L["рано"] .. "|r") or d == C_ORANGE and (C_ORANGE .. L["оранжевый: навык растёт всегда"] .. "|r")
            or d == C_YELLOW and (C_YELLOW .. L["жёлтый: навык растёт часто"] .. "|r") or d == C_GREEN and (C_GREEN .. L["зелёный: навык растёт редко"] .. "|r")
            or (C_GREY .. L["серый: навык не растёт"] .. "|r")) .. (IsKnown(r) and ("  |cff40bf40" .. L["уже изучен"] .. "|r") or ""))
    end
    if r.i then
        head(L["Получишь"])
        rows[#rows + 1] = { kind = "item", id = r.i, right = (r.q and r.q > 1) and ("×" .. r.q) or nil, tip = L["Клик — где ещё достать эту вещь · Shift+клик — ссылка в чат"] }
    end
    if #r.r > 0 then
        head(L["Реагенты"] .. "  |cffaaaaaa" .. L["(в сумках и банке)"] .. "|r")
        for i = 1, #r.r, 2 do
            local id, cnt = r.r[i], r.r[i + 1]
            local have = GetItemCount and (GetItemCount(id, true) or 0) or nil
            local right = cnt .. "×"
            if have then right = ((have >= cnt) and "|cff40bf40" or "|cffff6060") .. have .. "/" .. cnt .. "|r" end
            rows[#rows + 1] = { kind = "item", id = id, right = right, tip = L["Клик — где достать (поиск вещей) · Shift+клик — ссылка в чат"] }
        end
    end
    head(L["Как выучить"])
    if r.tr then
        src({ text = L["У тренера профессии"] .. (r.l and (L[", с навыка "] .. r.l) or ""), sub = L["Ближайшие тренеры твоей фракции (клик — метка):"] })
        local list = Trainers(key, r.l)
        for i = 1, math.min(6, #list) do
            local e = list[i]
            src({ text = "   " .. TrainerLine(e), action = function() GoTrainer(e) end, tipAction = L["метка на тренера"] })
        end
        if #list == 0 then note(L["Тренеров в базе нет — спроси в столице."]) end
        if #list > 6 then note(L["…и ещё тренеров: "] .. (#list - 6)) end
    elseif r.src then
        rows[#rows + 1] = { kind = "item", id = r.src, right = r.bop and L["персональный"] or nil, tip = L["Клик — где выпадает рецепт (поиск вещей) · Shift+клик — ссылка в чат"] }
        if r.mf then
            src({ text = string.format(L["Покупается за Merchant's Favor: %d"], r.mf),
                sub = L["Favor дают за сданные ящики (Waylaid Crate падают с мобов с 10 уровня)."] })
            local fac = PlayerFac()
            for _, p in ipairs(MF_POSTS) do
                if p.fa == fac then
                    src({ text = "   " .. L[p.name] .. string.format(" %.1f, %.1f", p.x, p.y) .. L[" — торговцы рецептами"], sub = L["по данным беты, точка примерная"],
                        action = function() U().WaypointTarget({ map = p.map, x = p.x, y = p.y }, "Merchant's Favor") end, tipAction = L["метка"] })
                end
            end
        end
        local vend = ns.PVEND and ns.PVEND[r.src]
        if vend then
            local fac = PlayerFac()
            local shown = 0
            for _, v in ipairs(vend) do
                local n = ns.PVNPC[v[1]]
                if n then
                    local mine = n.fr:find(fac, 1, true)
                    local name = ns.Loc("n", v[1], n.n, n.r ~= "" and n.r or nil)
                    src({ text = L["Продаёт: "] .. name .. (mine and "" or L[" |cffff6060(не твоя фракция)|r"]),
                        right = v[2] == 1 and L["ограниченно"] or nil,
                        sub = (ns.ZoneName and ns.ZoneName(n.m) or "") .. string.format(" %.0f, %.0f", n.x, n.y) .. L[" · |cffff9f4cпо классике|r"],
                        action = function() U().WaypointTarget({ map = n.m, x = n.x, y = n.y }, name) end, tipAction = L["метка на торговца"] })
                    shown = shown + 1
                    if shown >= 6 then break end
                end
            end
        end
        local sr = ns._search and ns._search.SourceRows and ns._search.SourceRows(r.src)
        local nsrc = 0
        for _, x in ipairs(sr or {}) do if x.kind == "src" and not x.prof then nsrc = nsrc + 1 end end
        if nsrc > 0 then
            src({ text = string.format(L["Где выпадает рецепт — источников: %d"], nsrc), sub = L["откроется поиск вещей"],
                action = function() if ns.OpenSearch then ns.OpenSearch(); ns.ShowItemSources(r.src) end end, tipAction = L["открыть"] })
        elseif not r.mf and not vend then
            note(L["Где достать рецепт в Forever, пока никто не опубликовал."])
        end
    else
        note(L["Источник рецепта неизвестен."])
    end
    return rows
end

---------------------------------------------------------------------------
-- Строки списка
---------------------------------------------------------------------------

local function CreateRow(parent)
    local r = CreateFrame("Button", nil, parent)
    r:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    r.hl = ns.Skin.Hover(r)
    r.bg = ns.Skin.Head(r)
    r.icon = r:CreateTexture(nil, "ARTWORK")
    r.icon:SetSize(24, 24)
    r.icon:SetPoint("LEFT", 4, 0)
    r.text = r:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    r.text:SetJustifyH("LEFT")
    r.text:SetWordWrap(false)
    r.right = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    r.right:SetPoint("TOPRIGHT", -6, -4)
    r.right:SetJustifyH("RIGHT")
    r.right2 = r:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    r.right2:SetPoint("TOPRIGHT", r.right, "BOTTOMRIGHT", 0, -3)
    r.right2:SetJustifyH("RIGHT")
    r.sub = r:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    r.sub:SetJustifyH("LEFT")
    r.sub:SetWordWrap(false)
    r:SetScript("OnClick", function(self, button)
        local d = self.data
        if not d then return end
        if d.kind == "recipe" or d.kind == "rhead" then
            if IsShiftKeyDown() then
                local link = d.r.i and U().ItemLink(d.r.i) or (d.r.s and GetSpellLink and GetSpellLink(d.r.s))
                if link and ChatEdit_InsertLink then ChatEdit_InsertLink(link) end
                return
            end
            if d.kind == "recipe" then ns.ShowRecipe(cur, d.r) end
        elseif d.kind == "item" then
            if IsShiftKeyDown() then
                local link = U().ItemLink(d.id)
                if link and ChatEdit_InsertLink then ChatEdit_InsertLink(link) end
                return
            end
            if ns.OpenSearch then ns.OpenSearch(); if ns.ShowItemSources then ns.ShowItemSources(d.id) end end
        elseif d.action then
            d.action()
        end
    end)
    r:SetScript("OnEnter", function(self)
        local d = self.data
        if not d then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        if d.kind == "recipe" or d.kind == "rhead" then
            local rr = d.r
            ns.tipSuppress = true
            local ok = false
            if rr.i and GameTooltip.SetItemByID then ok = pcall(GameTooltip.SetItemByID, GameTooltip, rr.i) end
            if not ok and rr.s and GameTooltip.SetSpellByID then ok = pcall(GameTooltip.SetSpellByID, GameTooltip, rr.s) end
            ns.tipSuppress = false
            if not ok or GameTooltip:NumLines() == 0 then GameTooltip:SetText(RecipeName(rr), 1, 1, 1) end
            GameTooltip:AddLine(" ")
            GameTooltip:AddLine(L["Навык: "] .. SkillNumbers(rr), 1, 1, 1)
            if #rr.r > 0 then GameTooltip:AddLine(L["Реагенты: "] .. ReagentText(rr, true), 0.9, 0.9, 0.9, true) end
            if d.kind == "recipe" then GameTooltip:AddLine(L["Клик — подробнее: реагенты, где выучить · Shift+клик — ссылка"], 0.45, 0.75, 1, true) end
        elseif d.kind == "item" then
            ns.tipSuppress = true
            local ok = GameTooltip.SetItemByID and pcall(GameTooltip.SetItemByID, GameTooltip, d.id)
            ns.tipSuppress = false
            if not ok or GameTooltip:NumLines() == 0 then GameTooltip:SetText(ItemNameAny(d.id), 1, 1, 1) end
            if d.tip then GameTooltip:AddLine(d.tip, 0.45, 0.75, 1, true) end
        elseif d.kind == "note" then
            GameTooltip:SetText(d.text, 0.9, 0.9, 0.9, 1, true)
        elseif d.action then
            GameTooltip:SetText(d.text, 1, 1, 1, 1, true)
            if d.sub then GameTooltip:AddLine(d.sub, 0.8, 0.8, 0.8, true) end
            GameTooltip:AddLine(L["Клик — "] .. (d.tipAction or L["метка / открыть"]), 0.45, 0.75, 1)
        else
            GameTooltip:Hide()
            return
        end
        GameTooltip:Show()
    end)
    r:SetScript("OnLeave", function() GameTooltip:Hide() end)
    return r
end

local function QualityHex(id)
    local hex = id and U().ItemQualityHex(id)
    if not hex and id then U().RequestItem(id) end
    if hex and hex:sub(1, 2) ~= "|c" then hex = "|c" .. hex end
    return hex
end

local function UpdateRow(row, d)
    row.text:SetWordWrap(false)
    row.bg:Hide()
    row.icon:Hide()
    row.text:ClearAllPoints()
    row.sub:ClearAllPoints()
    row.sub:SetText("")
    row.right:SetText("")
    row.right2:SetText("")
    if d.kind == "recipe" or d.kind == "rhead" then
        local r = d.r
        row.icon:Show()
        row.icon:SetTexture(RecipeIcon(r))
        local skill = skills[cur] and skills[cur][1]
        local diff = Difficulty(r, skill)
        local hex = QualityHex(r.i) or "|cffffffff"
        local mark = IsKnown(r) and "|cff40bf40✓|r " or ""
        row.text:SetPoint("TOPLEFT", row.icon, "TOPRIGHT", 6, 1)
        row.text:SetPoint("RIGHT", row.right, "LEFT", -8, 0)
        row.text:SetText(mark .. (diff and (diff .. "•|r ") or "") .. hex .. RecipeName(r) .. "|r" .. ((r.q and r.q > 1) and (" |cffaaaaaa×" .. r.q .. "|r") or "") .. StatusTag(r))
        row.right:SetText(SkillNumbers(r))
        row.right2:SetText(SourceShort(r))
        row.sub:SetPoint("TOPLEFT", row.text, "BOTTOMLEFT", 0, -3)
        row.sub:SetPoint("RIGHT", row.right2, "LEFT", -8, 0)
        local secs = (ProfByKey(cur) or {}).secs or {}
        local sec = secs[r.sec] and SectionName(secs[r.sec]) or ""
        row.sub:SetText((d.kind == "recipe" and (sec .. " · ") or "") .. ReagentText(r, d.kind == "rhead"))
        if d.kind == "rhead" then row.bg:Show() end
        for i = 1, #r.r, 2 do if not ns.CachedItemName(r.r[i]) then U().RequestItem(r.r[i]) end end
    elseif d.kind == "item" then
        row.icon:Show()
        row.icon:SetTexture(U().ItemIcon(d.id))
        local hex = QualityHex(d.id) or "|cffd8d8d8"
        row.text:SetPoint("LEFT", row.icon, "RIGHT", 6, 0)
        row.text:SetPoint("RIGHT", row.right, "LEFT", -8, 0)
        row.text:SetText(hex .. ItemNameAny(d.id) .. "|r")
        row.right:ClearAllPoints()
        row.right:SetPoint("RIGHT", -6, 0)
        row.right:SetText(d.right or "")
    elseif d.kind == "head" then
        row.bg:Show()
        row.text:SetPoint("LEFT", 8, 0)
        row.text:SetPoint("RIGHT", -8, 0)
        row.text:SetText("|cffffd100" .. d.text .. "|r")
    elseif d.kind == "note" then
        row.text:SetWordWrap(true)
        row.text:SetPoint("TOPLEFT", 10, -3)
        row.text:SetPoint("BOTTOMRIGHT", -8, 3)
        row.text:SetJustifyV("MIDDLE")
        row.text:SetText("|cffc8c8c8" .. d.text .. "|r")
    else
        row.text:SetPoint("TOPLEFT", 10, d.sub and -4 or -11)
        row.text:SetPoint("RIGHT", row.right, "LEFT", -8, 0)
        row.text:SetText(d.text)
        row.right:ClearAllPoints()
        row.right:SetPoint("TOPRIGHT", -6, -4)
        row.right:SetText(d.right or "")
        if d.sub then
            row.sub:SetPoint("TOPLEFT", row.text, "BOTTOMLEFT", 0, -3)
            row.sub:SetPoint("RIGHT", -6, 0)
            row.sub:SetText(d.sub)
        end
    end
    if d.kind ~= "item" and d.kind ~= "src" then
        row.right:ClearAllPoints()
        row.right:SetPoint("TOPRIGHT", -6, -4)
    end
end

-- Левая колонка: профессии
local function CreateProfRow(parent)
    local r = CreateFrame("Button", nil, parent)
    ns.Skin.Hover(r)
    r.sel = ns.Skin.Sel(r)
    r.icon = r:CreateTexture(nil, "ARTWORK")
    r.icon:SetSize(20, 20)
    r.icon:SetPoint("LEFT", 4, 0)
    r.name = r:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    r.name:SetPoint("LEFT", r.icon, "RIGHT", 6, 0)
    r.name:SetPoint("RIGHT", -56, 0)
    r.name:SetJustifyH("LEFT")
    r.name:SetWordWrap(false)
    r.skill = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    r.skill:SetPoint("RIGHT", -4, 0)
    r:SetScript("OnClick", function(self)
        if not self.data or not self.data.p then return end
        cur = self.data.p.key
        DB.sel = cur
        secFilter, cardRecipe = 0, nil
        if secPopup then secPopup:Hide() end
        ns.ProfsRefresh(true)
    end)
    return r
end

local function UpdateProfRow(r, d)
    if d.head then
        r.icon:Hide()
        r.sel:Hide()
        r.name:SetText("|cff9a9a9a" .. d.head .. "|r")
        r.skill:SetText("")
        return
    end
    local p = d.p
    r.icon:Show()
    r.icon:SetTexture("Interface\\Icons\\" .. PROF_ICON[p.key])
    r.name:SetText(ProfName(p.key))
    local s = skills[p.key]
    r.skill:SetText(s and ("|cff40bf40" .. s[1] .. "|r|cff888888/" .. s[2] .. "|r") or "")
    if p.key == cur then r.sel:Show() else r.sel:Hide() end
end

---------------------------------------------------------------------------
-- Всплывающий выбор раздела
---------------------------------------------------------------------------

local function UpdateSecButton()
    if not bar then return end
    local p = ProfByKey(cur)
    if secFilter ~= 0 and p and p.secs[secFilter] then
        bar.sec:SetText(SectionName(p.secs[secFilter]) .. " ▾")
    else
        bar.sec:SetText(L["Раздел: "] .. L["все"] .. " ▾")
    end
end

local function ShowSecPopup()
    local p = ProfByKey(cur)
    if not p then return end
    if not secPopup then
        secPopup = CreateFrame("Frame", nil, panel, BackdropTemplateMixin and "BackdropTemplate" or nil)
        secPopup:SetFrameStrata("DIALOG")
        ns.Skin.Window(secPopup, false, 12)
        secPopup.buttons = {}
        secPopup:EnableMouse(true)
        secPopup:Hide()
    end
    if secPopup:IsShown() then secPopup:Hide() return end
    local items = { { 0, L["все разделы"] } }
    for i, s in ipairs(p.secs) do items[#items + 1] = { i, SectionName(s) } end
    local perCol, w, h = 17, 180, 18
    local cols = math.ceil(#items / perCol)
    for i, it in ipairs(items) do
        local b = secPopup.buttons[i]
        if not b then
            b = CreateFrame("Button", nil, secPopup)
            b:SetSize(w, h)
            ns.Skin.Hover(b)
            b.t = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            b.t:SetPoint("LEFT", 6, 0)
            b.t:SetPoint("RIGHT", -4, 0)
            b.t:SetJustifyH("LEFT")
            b.t:SetWordWrap(false)
            secPopup.buttons[i] = b
        end
        local col, row = math.floor((i - 1) / perCol), (i - 1) % perCol
        b:ClearAllPoints()
        b:SetPoint("TOPLEFT", 6 + col * w, -6 - row * h)
        b.t:SetText((it[1] == secFilter and "|cffffd100" or "") .. it[2])
        b:SetScript("OnClick", function()
            secFilter = it[1]
            secPopup:Hide()
            cardRecipe = nil
            ns.ProfsRefresh(true)
        end)
        b:Show()
    end
    for i = #items + 1, #secPopup.buttons do secPopup.buttons[i]:Hide() end
    secPopup:SetSize(12 + cols * w, 12 + math.min(#items, perCol) * h)
    secPopup:ClearAllPoints()
    secPopup:SetPoint("TOPLEFT", bar.sec, "BOTTOMLEFT", 0, -2)
    secPopup:Show()
end

---------------------------------------------------------------------------
-- Панель
---------------------------------------------------------------------------

local function UpdateHeader()
    local p = ProfByKey(cur)
    if not p then return end
    local c = Counts(cur)
    header.icon:SetTexture("Interface\\Icons\\" .. PROF_ICON[cur])
    header.title:SetText(ProfName(cur))
    local s = skills[cur]
    local parts = { s and (L["Твой навык: "] .. "|cff40bf40" .. s[1] .. "|r/" .. s[2]) or ("|cff9a9a9a" .. L["не изучена"] .. "|r") }
    parts[#parts + 1] = string.format(L["%d рецептов, новых в Forever: %d"], c.all, c.new)
    if c.mf > 0 then parts[#parts + 1] = string.format(L["за Merchant's Favor: %d"], c.mf) end
    header.sub:SetText(table.concat(parts, "  ·  "))
end

function ns.ProfsRefresh(resetOffset)
    if not panel or not DB then return end
    if not cur or not ProfByKey(cur) then cur = DB.sel or "alchemy" end
    if not ProfByKey(cur) then cur = ns.PROFS and ns.PROFS[1] and ns.PROFS[1].key end
    if not cur then return end
    ScanSkills()
    -- левая колонка
    local rows, cats = {}, { L["Основные профессии"], L["Сбор"], L["Вторичные навыки"] }
    local lastCat
    for _, p in ipairs(ns.PROFS or {}) do
        if p.cat ~= lastCat then rows[#rows + 1] = { head = cats[p.cat] }; lastCat = p.cat end
        rows[#rows + 1] = { p = p }
    end
    profList:SetData(rows, true)
    UpdateHeader()
    UpdateSecButton()
    bar.onlyNew:SetChecked(DB.onlyNew)
    bar.hideKnown:SetChecked(DB.hideKnown)
    bar.sod:SetChecked(DB.sod)
    if cardRecipe then
        bar:Hide()
        back:Show()
        recipeList:SetData(CardRows(cardRecipe, cur), not resetOffset)
        header.empty:SetText("")
        return
    end
    back:Hide()
    bar:Show()
    local data = BuildRows()
    recipeList:SetData(data, not resetOffset)
    header.empty:SetText(#data == 0 and L["Ничего не найдено. Сними фильтры или измени поиск."] or "")
end

function ns.ShowRecipe(key, r)
    if key then cur = key; if DB then DB.sel = key end end
    cardRecipe = r
    if secPopup then secPopup:Hide() end
    ns.ProfsRefresh(true)
end

function ns.CreateProfessionsPanel(parent)
    panel = CreateFrame("Frame", nil, parent)
    panel:SetScript("OnHide", function() if secPopup then secPopup:Hide() end end)

    local left = CreateFrame("Frame", nil, panel)
    left:SetPoint("TOPLEFT", 0, 0)
    left:SetPoint("BOTTOMLEFT", 0, 0)
    left:SetWidth(210)
    local lbg = ns.Skin.Panel(left)
    profList = U().CreateScrollList(left, 26, CreateProfRow, UpdateProfRow)
    profList:SetPoint("TOPLEFT", 2, -2)
    profList:SetPoint("BOTTOMRIGHT", -2, 2)

    local right = CreateFrame("Frame", nil, panel)
    right:SetPoint("TOPLEFT", left, "TOPRIGHT", 10, 0)
    right:SetPoint("BOTTOMRIGHT", 0, 0)

    header = {}
    header.icon = right:CreateTexture(nil, "ARTWORK")
    header.icon:SetSize(34, 34)
    header.icon:SetPoint("TOPLEFT", 0, 0)
    header.title = right:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    header.title:SetPoint("TOPLEFT", header.icon, "TOPRIGHT", 8, -1)
    header.title:SetPoint("RIGHT", -170, 0)
    header.title:SetJustifyH("LEFT")
    header.sub = right:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    header.sub:SetPoint("TOPLEFT", header.title, "BOTTOMLEFT", 0, -4)
    header.sub:SetPoint("RIGHT", -4, 0)
    header.sub:SetJustifyH("LEFT")
    header.sub:SetWordWrap(false)

    header.trainer = U().MakeButton(right, L["Ближайший тренер"], 160, function()
        local list = Trainers(cur)
        if list[1] then GoTrainer(list[1]) else Print(ProfName(cur) .. L[": тренеров твоей фракции в базе нет."]) end
    end)
    header.trainer:SetPoint("TOPRIGHT", 0, 0)
    header.trainer:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOMLEFT")
        GameTooltip:SetText(L["Тренеры: "] .. ProfName(cur), 1, 0.82, 0)
        local list = Trainers(cur)
        for i = 1, math.min(10, #list) do GameTooltip:AddLine(TrainerLine(list[i]), 1, 1, 1) end
        if #list == 0 then GameTooltip:AddLine(L["Тренеров твоей фракции в базе нет."], 0.7, 0.7, 0.7) end
        GameTooltip:AddLine(L["Клик — метка на ближайшего. Места — база Questie для Forever."], 0.45, 0.75, 1, true)
        GameTooltip:Show()
    end)
    header.trainer:SetScript("OnLeave", function() GameTooltip:Hide() end)

    -- фильтры
    bar = CreateFrame("Frame", nil, right)
    bar:SetPoint("TOPLEFT", header.icon, "BOTTOMLEFT", 0, -8)
    bar:SetPoint("RIGHT", 0, 0)
    bar:SetHeight(24)
    local box = CreateFrame("EditBox", "ForeverGuideProfSearch", bar, "InputBoxTemplate")
    box:SetAutoFocus(false)
    box:SetSize(150, 20)
    box:SetPoint("LEFT", 6, 0)
    box:SetMaxLetters(60)
    box.hint = box:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    box.hint:SetPoint("LEFT", 2, 0)
    box.hint:SetText(L["поиск рецепта / реагента"])
    local pending = 0
    box:SetScript("OnTextChanged", function(self, user)
        local t = self:GetText() or ""
        if t == "" then self.hint:Show() else self.hint:Hide() end
        if not user then return end
        pending = pending + 1
        local token = pending
        C_Timer.After(0.3, function()
            if token == pending then searchText = self:GetText() or ""; ns.ProfsRefresh(true) end
        end)
    end)
    box:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    box:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    bar.box = box
    bar.sec = U().MakeButton(bar, L["Раздел: "] .. L["все"], 190, ShowSecPopup)
    bar.sec:SetHeight(20)
    bar.sec:SetPoint("LEFT", box, "RIGHT", 6, 0)
    bar.onlyNew = U().MakeCheck(bar, L["Новые Forever"], function(v) DB.onlyNew = v; ns.ProfsRefresh(true) end)
    bar.onlyNew:SetPoint("LEFT", bar.sec, "RIGHT", 6, 0)
    if bar.sec.SetNormalFontObject then pcall(bar.sec.SetNormalFontObject, bar.sec, "GameFontNormalSmall") end
    if bar.sec.SetHighlightFontObject then pcall(bar.sec.SetHighlightFontObject, bar.sec, "GameFontHighlightSmall") end
    bar.hideKnown = U().MakeCheck(bar, L["Не изученные"], function(v) DB.hideKnown = v; ns.ProfsRefresh(true) end)
    bar.hideKnown:SetPoint("LEFT", bar.onlyNew, "RIGHT", 110, 0)
    bar.sod = U().MakeCheck(bar, "SoD", function(v) DB.sod = v; ns.ProfsRefresh(true) end)
    bar.sod:SetPoint("LEFT", bar.hideKnown, "RIGHT", 100, 0)
    bar.sod:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOMLEFT")
        GameTooltip:SetText("Season of Discovery", 1, 0.82, 0)
        GameTooltip:AddLine(L["Показать рецепты, которые клиент Forever хранит в разделе Season of Discovery. Учат ли им на бете — не подтверждено."], 1, 1, 1, true)
        GameTooltip:Show()
    end)
    bar.sod:SetScript("OnLeave", function() GameTooltip:Hide() end)

    back = U().MakeButton(right, L["« К рецептам"], 120, function() cardRecipe = nil; ns.ProfsRefresh() end)
    back:SetPoint("TOPLEFT", header.icon, "BOTTOMLEFT", 0, -8)
    back:Hide()

    local area = CreateFrame("Frame", nil, right)
    area:SetPoint("TOPLEFT", bar, "BOTTOMLEFT", 0, -4)
    area:SetPoint("BOTTOMRIGHT", 0, 0)
    local abg = ns.Skin.Panel(area)
    recipeList = U().CreateScrollList(area, 36, CreateRow, UpdateRow)
    recipeList:SetPoint("TOPLEFT", 2, -2)
    recipeList:SetPoint("BOTTOMRIGHT", -2, 2)
    header.empty = area:CreateFontString(nil, "OVERLAY", "GameFontDisable")
    header.empty:SetPoint("TOP", 0, -30)
    return panel
end

---------------------------------------------------------------------------
-- Изученные рецепты: окно профессии
---------------------------------------------------------------------------

local byNameCache
local function RecordByName(nameFn, count)
    if not known then return end
    if not byNameCache then
        byNameCache = {}
        for _, recs in pairs(ns.PREC or {}) do
            for _, r in ipairs(recs) do
                if r.s then byNameCache[ClientRecipeName(r)] = r.s end
            end
        end
    end
    local byName = byNameCache
    for i = 1, count do
        local ok, name, kind = pcall(nameFn, i)
        if ok and name and kind ~= "header" and byName[name] then known[byName[name]] = true end
    end
end

local function ScanTradeSkill()
    if not known then return end
    local n = GetNumTradeSkills and GetNumTradeSkills() or 0
    local got = false
    if GetTradeSkillRecipeLink then
        for i = 1, n do
            local ok, link = pcall(GetTradeSkillRecipeLink, i)
            local id = ok and link and tonumber(link:match("enchant:(%d+)") or link:match("spell:(%d+)"))
            if id then known[id] = true; got = true end
        end
    end
    if not got and GetTradeSkillInfo and n > 0 then RecordByName(GetTradeSkillInfo, n) end
end

local function ScanCraft()
    if not known or not GetNumCrafts then return end
    local n = GetNumCrafts() or 0
    local got = false
    if GetCraftRecipeLink then
        for i = 1, n do
            local ok, link = pcall(GetCraftRecipeLink, i)
            local id = ok and link and tonumber(link:match("enchant:(%d+)") or link:match("spell:(%d+)"))
            if id then known[id] = true; got = true end
        end
    end
    if not got and GetCraftInfo and n > 0 then
        RecordByName(function(i) local name, _, kind = GetCraftInfo(i); return name, kind end, n)
    end
end

local ev = CreateFrame("Frame")
for _, e in ipairs({ "PLAYER_LOGIN", "SKILL_LINES_CHANGED", "TRADE_SKILL_SHOW", "TRADE_SKILL_UPDATE",
    "CRAFT_SHOW", "CRAFT_UPDATE", "BAG_UPDATE_DELAYED" }) do
    pcall(ev.RegisterEvent, ev, e) -- у клиента может не быть части событий
end
local refreshPending = false
local scanPending = {}
local function SoftRefresh()
    if refreshPending or not (panel and panel:IsVisible()) then return end
    refreshPending = true
    C_Timer.After(0.4, function()
        refreshPending = false
        if panel and panel:IsVisible() then ns.ProfsRefresh() end
    end)
end
ev:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        local root = ForeverGuideDB
        if not root then ForeverGuideDB = {}; root = ForeverGuideDB end
        root.prof = root.prof or {}
        DB = root.prof
        DB.known = DB.known or {}
        local who = (UnitName("player") or "?") .. "-" .. ((GetRealmName and GetRealmName()) or "")
        DB.known[who] = DB.known[who] or {}
        known = DB.known[who]
        cur = DB.sel
        return
    end
    -- окно профессии: запоминаем изученные рецепты (не чаще раза в 3 секунды)
    if event == "TRADE_SKILL_SHOW" or event == "TRADE_SKILL_UPDATE" or event == "CRAFT_SHOW" or event == "CRAFT_UPDATE" then
        local isCraft = event:find("^CRAFT") ~= nil
        if scanPending[isCraft] then return end
        scanPending[isCraft] = true
        C_Timer.After(event:find("SHOW") and 0.2 or 3, function()
            scanPending[isCraft] = false
            if isCraft then ScanCraft() else ScanTradeSkill() end
            SoftRefresh()
        end)
        return
    end
    SoftRefresh()
end)
if ns.OnItemData then ns.OnItemData(SoftRefresh) end

-- для тестов
ns._prof = { BuildRows = BuildRows, CardRows = CardRows, Trainers = Trainers, RecipeName = RecipeName, Skills = function() return skills end,
    Lists = function() return profList, recipeList, bar, back end, ShowSecPopup = ShowSecPopup, Popup = function() return secPopup end,
    SetCur = function(k) cur = k end, SetSearch = function(t) searchText = t end, SetSec = function(i) secFilter = i end }
