-- Forever Library Books: точки книг на карте мира, прогресс сдачи, метки маршрута.

local ADDON, ns = ...
local L = ns.L

local PIN_TEMPLATE = "ForeverGuidePinTemplate"
local TEX_BOOK = "Interface\\Icons\\INV_Misc_Book_09"
local TEX_DONE = "Interface\\RaidFrame\\ReadyCheck-Ready"
local TEX_BAG = "Interface\\RaidFrame\\ReadyCheck-Waiting"
local TEX_NO = "Interface\\RaidFrame\\ReadyCheck-NotReady"
local TEX_LIBRARIAN = "Interface\\GossipFrame\\ActiveQuestIcon"
local function PREFIX() return L["|cff5fc48f[Путеводитель]|r "] end
local GOAL_NECK, GOAL_RING = 10, 20

local DEFAULTS = { pins = true, continent = true, hideDone = false, otherFaction = false, minimap = true, announce = true, booksEnabled = true }
ns.GetDB = function() return ForeverGuideDB end
local db

---------------------------------------------------------------------------
-- Защита от дисконнекта. Каждый запрос данных предмета уходит на сервер,
-- и если их слишком много, сервер отключает игрока. Поэтому:
--   * запросы идут очередью — не больше 3 в секунду;
--   * один предмет — не чаще раза в 10 минут (даже если сервер его не знает);
--   * имена/качество берём только из кэша клиента, без скрытых запросов;
--   * окна обновляются только когда пришёл предмет, который просили мы.
---------------------------------------------------------------------------
local reqQueue, reqQueued, reqLast, reqPending = {}, {}, {}, {}
local REQ_PER_TICK, REQ_INTERVAL, REQ_REPEAT, REQ_MAXQ = 3, 1.0, 600, 150
local reqTicking = false
local itemCallbacks = {}

local function Now() return (GetTime and GetTime()) or 0 end

-- true — в кэше клиента, false — нет, nil — клиент не умеет это проверить
function ns.ItemCached(id)
    if not id then return false end
    if C_Item and C_Item.IsItemDataCachedByID then
        local ok, v = pcall(C_Item.IsItemDataCachedByID, id)
        if ok then return v and true or false end
    end
    return nil
end

local function PumpRequests()
    reqTicking = false
    local sent = 0
    while sent < REQ_PER_TICK and #reqQueue > 0 do
        local id = table.remove(reqQueue, 1)
        reqQueued[id] = nil
        if ns.ItemCached(id) ~= true then
            reqLast[id] = Now()
            reqPending[id] = true
            if C_Item and C_Item.RequestLoadItemDataByID then pcall(C_Item.RequestLoadItemDataByID, id) end
            sent = sent + 1
        end
    end
    if #reqQueue > 0 and C_Timer and C_Timer.After then
        reqTicking = true
        C_Timer.After(REQ_INTERVAL, PumpRequests)
    end
end

function ns.RequestItem(id)
    id = tonumber(id)
    if not id or reqQueued[id] or reqPending[id] then return end
    if ns.ItemCached(id) == true then return end
    local last = reqLast[id]
    if last and Now() - last < REQ_REPEAT then return end
    if #reqQueue >= REQ_MAXQ then return end
    reqQueue[#reqQueue + 1] = id
    reqQueued[id] = true
    if not reqTicking then
        reqTicking = true
        if C_Timer and C_Timer.After then C_Timer.After(0.2, PumpRequests) else PumpRequests() end
    end
end

-- Имя предмета только из кэша клиента (ничего не спрашивает у сервера), на языке клиента
function ns.ClientItemName(id)
    if not id or ns.ItemCached(id) == false then return nil end
    if C_Item and C_Item.GetItemNameByID then
        local ok, n = pcall(C_Item.GetItemNameByID, id)
        if ok and type(n) == "string" and n ~= "" then return n end
    end
    return nil
end

-- Имя для показа: из клиента, только если язык аддона совпадает с языком клиента
function ns.CachedItemName(id)
    if ns.CLIENT_NAMES == false then return nil end
    return ns.ClientItemName(id)
end

function ns.CachedItemQuality(id)
    if not id or ns.ItemCached(id) == false then return nil end
    if C_Item and C_Item.GetItemQualityByID then
        local ok, q = pcall(C_Item.GetItemQualityByID, id)
        if ok then return q end
    end
    return nil
end

-- Выбор языка аддона. lang: код языка клиента ("ruRU", "enUS", "deDE", …, см. ns.LANGUAGES) или "auto" (как в игре).
function ns.ChooseLanguage(lang)
    local d = ForeverGuideDB
    if not d then return end
    local codes = ns.LANGUAGE_NAMES or {}
    if lang == "auto" then d.lang = nil elseif codes[lang] then d.lang = lang else return end
    local target = ns.NormLang and ns.NormLang(d.lang or ns.CLIENT_LOCALE) or (d.lang or ns.CLIENT_LOCALE)
    local function T(k) return ns.TextIn and ns.TextIn(target, k) or k end
    if target == ns.LOCALE then
        DEFAULT_CHAT_FRAME:AddMessage(T("|cff5fc48f[Путеводитель]|r ") .. T("язык аддона уже такой."))
        return
    end
    local text = T("Язык аддона сменится после перезагрузки интерфейса. Перезагрузить сейчас?")
    if StaticPopupDialogs and StaticPopup_Show then
        StaticPopupDialogs.FOREVERGUIDE_RELOAD = {
            text = text, button1 = T("Перезагрузить"), button2 = T("Позже"),
            OnAccept = function() if ReloadUI then ReloadUI() end end,
            timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3,
        }
        StaticPopup_Show("FOREVERGUIDE_RELOAD")
    else
        DEFAULT_CHAT_FRAME:AddMessage(T("|cff5fc48f[Путеводитель]|r ") .. text .. " /reload")
    end
end

-- Подписка на «пришёл предмет, который мы просили»
function ns.OnItemData(fn) itemCallbacks[#itemCallbacks + 1] = fn end

local itemFrame = CreateFrame("Frame")
pcall(itemFrame.RegisterEvent, itemFrame, "GET_ITEM_INFO_RECEIVED")
itemFrame:SetScript("OnEvent", function(_, _, id, success)
    id = tonumber(id)
    if not id or not reqPending[id] then return end
    reqPending[id] = nil
    if success == false then return end
    for _, fn in ipairs(itemCallbacks) do pcall(fn, id) end
end)

local MAPTYPE_CONTINENT = (Enum and Enum.UIMapType and Enum.UIMapType.Continent) or 2
local MAPTYPE_ZONE = (Enum and Enum.UIMapType and Enum.UIMapType.Zone) or 3

local function Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage(PREFIX() .. msg)
end

---------------------------------------------------------------------------
-- Статус книги
---------------------------------------------------------------------------

local function PlayerFaction()
    return (UnitFactionGroup("player")) or "Horde"
end

local function Available(b)
    return not b.faction or b.faction == PlayerFaction()
end

local function IsDone(questID)
    if C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted then
        return C_QuestLog.IsQuestFlaggedCompleted(questID) and true or false
    end
    if IsQuestFlaggedCompleted then
        return IsQuestFlaggedCompleted(questID) and true or false
    end
    return false
end

local function ItemCount(itemID)
    if C_Item and C_Item.GetItemCount then
        return C_Item.GetItemCount(itemID) or 0
    end
    if GetItemCount then
        return GetItemCount(itemID) or 0
    end
    return 0
end

local function OnQuest(questID)
    if C_QuestLog and C_QuestLog.IsOnQuest then
        return C_QuestLog.IsOnQuest(questID) and true or false
    end
    if C_QuestLog and C_QuestLog.GetLogIndexForQuestID then
        return C_QuestLog.GetLogIndexForQuestID(questID) ~= nil
    end
    return false
end

-- "done" | "bag" | "todo" | "faction"
local function Status(b)
    if IsDone(b.quest) then return "done" end
    if not Available(b) then return "faction" end
    if ItemCount(b.item) > 0 or OnQuest(b.quest) then return "bag" end
    return "todo"
end

local function BookName(b)
    local name = ns.CachedItemName(b.item)
    if name then return name end
    if ns.IS_RU then return b.ru end
    if ns.LZ and ns.LZ.i and ns.LZ.i[b.item] then return ns.LZ.i[b.item] end
    return b.en or b.ru
end

local function BookIcon(b)
    local icon
    if C_Item and C_Item.GetItemIconByID then
        icon = C_Item.GetItemIconByID(b.item)
    end
    if not icon and GetItemIcon then
        icon = GetItemIcon(b.item)
    end
    return icon or TEX_BOOK
end

local function Progress()
    local done, bag, avail = 0, 0, 0
    for _, b in ipairs(ns.BOOKS) do
        if Available(b) then
            avail = avail + 1
            local s = Status(b)
            if s == "done" then
                done = done + 1
            elseif s == "bag" then
                bag = bag + 1
            end
        end
    end
    return done, bag, avail
end

local function ZoneName(mapID)
    -- язык аддона может отличаться от клиента: тогда берём своё название зоны
    local own = ns.ZoneLocal and ns.ZoneLocal(mapID)
    if own and not ns.CLIENT_NAMES then return own end
    local info = C_Map and C_Map.GetMapInfo and C_Map.GetMapInfo(mapID)
    return (info and info.name) or own or (L["карта "] .. tostring(mapID))
end

local function Librarian()
    return ns.LIBRARIANS[PlayerFaction()] or ns.LIBRARIANS.Horde
end

-- Кому нести книгу: библиотекарю или (для сета 60 из SoD) учителю магии.
local function TurnInNPC(b)
    if b and b.trainer then
        return ns.TRAINERS[PlayerFaction()] or ns.TRAINERS.Horde
    end
    return Librarian()
end

---------------------------------------------------------------------------
-- Точки: книги + библиотекарь
---------------------------------------------------------------------------

local function BooksOn() return not db or db.booksEnabled ~= false end
ns.BooksOn = BooksOn

local function BuildEntries(booksOnly)
    local list = {}
    if not BooksOn() and not booksOnly then
        if ns.DungeonMapEntries then
            local ok, extra = pcall(ns.DungeonMapEntries)
            if ok and extra then return extra end
        end
        return list
    end
    for faction, lib in pairs(ns.LIBRARIANS) do
        if faction == PlayerFaction() or (db and db.otherFaction) then
            list[#list + 1] = { kind = "librarian", lib = lib, map = lib.map, x = lib.x, y = lib.y }
        end
    end
    for _, b in ipairs(ns.BOOKS) do
        for _, sp in ipairs(b.spawns) do
            list[#list + 1] = { kind = "book", book = b, map = sp[1], x = sp[2], y = sp[3], approx = sp[4] }
        end
    end
    if ns.DungeonMapEntries and not booksOnly then
        local ok, extra = pcall(ns.DungeonMapEntries)
        if ok and extra then
            for _, e in ipairs(extra) do list[#list + 1] = e end
        end
    end
    return list
end

local function Visible(e)
    if e.kind == "librarian" or e.kind == "dq" then return true end
    local s = Status(e.book)
    if s == "faction" and not db.otherFaction then return false end
    if s == "done" and db.hideDone then return false end
    return true
end

-- Проекция точки зоны на текущую карту (соседние зоны и материк).
local worldCache, continentCache = {}, {}

local function ContinentOf(mapID)
    local cached = continentCache[mapID]
    if cached ~= nil then return cached end
    local result, id, guard = false, mapID, 0
    while id and id > 0 and guard < 12 do
        local info = C_Map.GetMapInfo(id)
        if not info then break end
        if info.mapType == MAPTYPE_CONTINENT then
            result = id
            break
        end
        id = info.parentMapID
        guard = guard + 1
    end
    continentCache[mapID] = result
    return result
end

local function WorldPos(e)
    local key = e.map .. ":" .. e.x .. ":" .. e.y
    local w = worldCache[key]
    if w == nil then
        w = false
        if C_Map.GetWorldPosFromMapPos and CreateVector2D then
            local ok, cont, pos = pcall(C_Map.GetWorldPosFromMapPos, e.map, CreateVector2D(e.x / 100, e.y / 100))
            if ok and cont and pos then
                w = { cont, pos }
            end
        end
        worldCache[key] = w
    end
    return w or nil
end

local function Project(e, mapID, mapType)
    if e.map == mapID then
        return e.x / 100, e.y / 100
    end
    if mapType ~= MAPTYPE_ZONE and mapType ~= MAPTYPE_CONTINENT then return end
    if not C_Map.GetMapPosFromWorldPos then return end
    local c1 = ContinentOf(mapID)
    if not c1 or c1 ~= ContinentOf(e.map) then return end
    local w = WorldPos(e)
    if not w then return end
    local ok, _, pos = pcall(C_Map.GetMapPosFromWorldPos, w[1], w[2], mapID)
    if not ok or not pos then return end
    local x, y = pos:GetXY()
    if not x or x < 0 or x > 1 or y < 0 or y > 1 then return end
    return x, y
end

---------------------------------------------------------------------------
-- Метка маршрута
---------------------------------------------------------------------------

local function SetWaypoint(map, x, y, title)
    if TomTom and TomTom.AddWaypoint then
        TomTom:AddWaypoint(map, x / 100, y / 100, { title = title, persistent = false, minimap = true, world = true })
        return "TomTom"
    end
    if C_Map and C_Map.SetUserWaypoint and UiMapPoint and UiMapPoint.CreateFromCoordinates then
        local can = true
        if C_Map.CanSetUserWaypointOnMap then
            can = C_Map.CanSetUserWaypointOnMap(map)
        end
        if can then
            local ok = pcall(C_Map.SetUserWaypoint, UiMapPoint.CreateFromCoordinates(map, x / 100, y / 100))
            if ok then
                if C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint then
                    pcall(C_SuperTrack.SetSuperTrackedUserWaypoint, true)
                end
                return L["метка на карте"]
            end
        end
    end
    return nil
end

local function WaypointTo(e)
    if e.kind == "dq" then
        if e.onClick then e.onClick(e) end
        return
    end
    local title = e.kind == "librarian" and L[e.lib.name] or BookName(e.book)
    local how = SetWaypoint(e.map, e.x, e.y, title)
    local where = string.format("%s %.1f, %.1f", ZoneName(e.map), e.x, e.y)
    if how then
        Print(string.format("%s — %s (%s).", title, where, how))
    else
        Print(string.format(L["%s — %s. Метку поставить не получилось: введи координаты вручную или поставь TomTom."], title, where))
    end
end

---------------------------------------------------------------------------
-- Подсказка
---------------------------------------------------------------------------

local STATUS_TEXT = {
    done = { "Сдана", 0.37, 0.77, 0.56 },
    bag = { "В сумке — неси библиотекарю", 1, 0.82, 0 },
    todo = { "Не взята", 0.85, 0.85, 0.85 },
    faction = { "Твоя фракция её не принимает (по данным SoD)", 1, 0.4, 0.35 },
}

local function ShowTooltip(owner, e)
    local tip = GameTooltip
    tip:SetOwner(owner, "ANCHOR_RIGHT")
    if e.kind == "dq" then
        if e.tooltip then e.tooltip(tip, e) end
        tip:Show()
        return
    end
    if e.kind == "librarian" then
        local done, bag = Progress()
        tip:SetText(L[e.lib.name], 1, 0.82, 0)
        tip:AddLine(L["Библиотекарь. "] .. L[e.lib.place], 1, 1, 1)
        tip:AddLine(string.format(L["Сдано книг: %d · в сумке: %d"], done, bag), 0.37, 0.77, 0.56)
        tip:AddLine(string.format(L["%d книг — шея, %d — кольцо."], GOAL_NECK, GOAL_RING), 0.85, 0.85, 0.85)
        tip:AddLine(L["Квест на книгу появляется, только когда она уже в сумке."], 0.85, 0.85, 0.85, true)
    else
        local b = e.book
        local s = Status(b)
        local st = STATUS_TEXT[s]
        tip:SetText(BookName(b), 1, 1, 1)
        if s == "bag" and b.trainer then
            tip:AddLine(L["В сумке — неси учителю магии"], st[2], st[3], st[4])
        else
            tip:AddLine(L[st[1]], st[2], st[3], st[4])
        end
        tip:AddDoubleLine(L["Сет "] .. b.set, string.format("%s %.1f, %.1f", ZoneName(e.map), e.x, e.y), 0.7, 0.7, 0.7, 0.7, 0.7, 0.7)
        if b.note then
            tip:AddLine(L[b.note], 0.85, 0.85, 0.85, true)
        end
        if e.approx then
            tip:AddLine(L["Точка примерная."], 1, 0.6, 0.3)
        end
        if b.trainer then
            local t = TurnInNPC(b)
            tip:AddLine(L["В SoD сдавалась не библиотекарю, а учителю магии: "] .. L[t.name] .. ", " .. L[t.place] .. L[". Работает ли это в Forever, пока не подтверждено."], 1, 0.6, 0.3, true)
        end
    end
    tip:AddLine(L["Клик — поставить метку маршрута"], 0.45, 0.75, 1)
    tip:Show()
end

local function ApplyVisual(icon, badge, e, small)
    if e.kind == "dq" then
        icon:SetTexture(e.icon)
        icon:SetTexCoord(0, 1, 0, 1)
        icon:SetDesaturated(e.grey and true or false)
        icon:SetAlpha(e.grey and 0.7 or 1)
        if e.badge then
            badge:SetTexture(e.badge)
            badge:Show()
        else
            badge:Hide()
        end
        return
    end
    if e.kind == "librarian" then
        icon:SetTexture(TEX_LIBRARIAN)
        icon:SetTexCoord(0, 1, 0, 1)
        icon:SetDesaturated(false)
        icon:SetAlpha(1)
        badge:Hide()
        return
    end
    local s = Status(e.book)
    icon:SetTexture(BookIcon(e.book))
    icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    icon:SetDesaturated(s == "done" or s == "faction")
    icon:SetAlpha((s == "done" or s == "faction") and 0.55 or 1)
    if s == "done" then
        badge:SetTexture(TEX_DONE)
        badge:Show()
    elseif s == "bag" then
        badge:SetTexture(TEX_BAG)
        badge:Show()
    elseif s == "faction" then
        badge:SetTexture(TEX_NO)
        badge:Show()
    else
        badge:Hide()
    end
end

---------------------------------------------------------------------------
-- Пины карты мира (MapCanvas)
---------------------------------------------------------------------------

ForeverGuidePinMixin = CreateFromMixins(MapCanvasPinMixin)

function ForeverGuidePinMixin:OnLoad()
    self:UseFrameLevelType("PIN_FRAME_LEVEL_AREA_POI")
    self:SetScalingLimits(1, 1.0, 1.25)
    if self.SetPassThroughButtons then
        pcall(self.SetPassThroughButtons, self, "RightButton")
    end
end

function ForeverGuidePinMixin:OnAcquired(entry, x, y, small)
    self.entry = entry
    self:SetPosition(x, y)
    local size = small and 14 or 20
    if entry.kind == "librarian" or entry.kind == "dq" then size = small and 16 or 22 end
    self:SetSize(size, size)
    self.Badge:SetSize(size * 0.6, size * 0.6)
    ApplyVisual(self.Icon, self.Badge, entry, small)
end

function ForeverGuidePinMixin:OnReleased()
    self.entry = nil
end

function ForeverGuidePinMixin:OnMouseEnter()
    if self.entry then ShowTooltip(self, self.entry) end
end

function ForeverGuidePinMixin:OnMouseLeave()
    GameTooltip:Hide()
end

-- Карта сама вешает OnEnter/OnLeave/OnMouseUp на пин и вызывает эти методы.
function ForeverGuidePinMixin:OnClick(button)
    if button == "LeftButton" and self.entry then
        WaypointTo(self.entry)
    end
end

local Provider = CreateFromMixins(MapCanvasDataProviderMixin)

function Provider:RemoveAllData()
    self:GetMap():RemoveAllPinsByTemplate(PIN_TEMPLATE)
end

function Provider:RefreshAllData()
    self:RemoveAllData()
    if not db or not db.pins then return end
    local map = self:GetMap()
    local mapID = map:GetMapID()
    if not mapID then return end
    local info = C_Map.GetMapInfo(mapID)
    local mapType = info and info.mapType
    if mapType == MAPTYPE_CONTINENT and not db.continent then return end
    if mapType and mapType < MAPTYPE_CONTINENT then return end
    local small = mapType == MAPTYPE_CONTINENT
    for _, e in ipairs(BuildEntries()) do
        if Visible(e) then
            local x, y = Project(e, mapID, mapType)
            if x then
                map:AcquirePin(PIN_TEMPLATE, e, x, y, small)
            end
        end
    end
end

local providerAdded = false
local function AttachProvider()
    if providerAdded then return end
    if not (WorldMapFrame and WorldMapFrame.AddDataProvider) then return end
    WorldMapFrame:AddDataProvider(Provider)
    providerAdded = true
end

---------------------------------------------------------------------------
-- Миникарта (если есть HereBeDragons, например из Questie)
---------------------------------------------------------------------------

local HBDP
local miniFrames = {}
local MINI_REF = "ForeverGuide"

local function MiniFrame(i)
    local f = miniFrames[i]
    if f then return f end
    f = CreateFrame("Frame", nil, Minimap)
    f:SetSize(12, 12)
    f.Icon = f:CreateTexture(nil, "ARTWORK")
    f.Icon:SetAllPoints()
    f.Badge = f:CreateTexture(nil, "OVERLAY")
    f.Badge:SetSize(8, 8)
    f.Badge:SetPoint("BOTTOMRIGHT", 3, -3)
    f:EnableMouse(true)
    f:SetScript("OnEnter", function(self) if self.entry then ShowTooltip(self, self.entry) end end)
    f:SetScript("OnLeave", function() GameTooltip:Hide() end)
    miniFrames[i] = f
    return f
end

local function UpdateMinimap()
    if not HBDP then
        HBDP = LibStub and LibStub("HereBeDragons-Pins-2.0", true)
        if not HBDP then return end
    end
    HBDP:RemoveAllMinimapIcons(MINI_REF)
    if not db.minimap then return end
    local i = 0
    for _, e in ipairs(BuildEntries()) do
        local show = Visible(e)
        if show and e.kind == "book" and Status(e.book) == "done" then show = false end
        if show then
            i = i + 1
            local f = MiniFrame(i)
            f.entry = e
            ApplyVisual(f.Icon, f.Badge, e, true)
            HBDP:AddMinimapIconMap(MINI_REF, f, e.map, e.x / 100, e.y / 100, true, false)
        end
    end
end

---------------------------------------------------------------------------
-- Обновление
---------------------------------------------------------------------------

local refreshQueued = false
local function RefreshNow()
    refreshQueued = false
    if providerAdded and WorldMapFrame:IsShown() then
        Provider:RefreshAllData()
    end
    UpdateMinimap()
end

local function QueueRefresh()
    if refreshQueued then return end
    refreshQueued = true
    C_Timer.After(0.3, RefreshNow)
end

ns.Print = Print
ns.IsDone = IsDone
ns.OnQuest = OnQuest
ns.ZoneName = ZoneName
ns.SetWaypoint = SetWaypoint
ns.WorldPos = WorldPos
ns.QueueRefresh = QueueRefresh

---------------------------------------------------------------------------
-- Чат: список, ближайшая книга
---------------------------------------------------------------------------

local function PrintProgress()
    local done, bag, avail = Progress()
    local lib = Librarian()
    local goal
    if done >= GOAL_RING then
        goal = L["Кольцо доступно — квест у библиотекаря."]
    elseif done >= GOAL_NECK then
        goal = string.format(L["Шея доступна. До кольца: %d."], GOAL_RING - done)
    else
        goal = string.format(L["До шеи: %d, до кольца: %d."], GOAL_NECK - done, GOAL_RING - done)
    end
    Print(string.format(L["Сдано %d, в сумке %d (доступно твоей фракции: %d). %s Сдавать: %s, %s."], done, bag, avail, goal, L[lib.name], L[lib.place]))
end

local function PrintList()
    PrintProgress()
    local lastGroup
    for _, b in ipairs(ns.BOOKS) do
        local s = Status(b)
        if s == "todo" or s == "bag" then
            if b.group ~= lastGroup then
                DEFAULT_CHAT_FRAME:AddMessage("|cffffd100" .. L[ns.GROUPS[b.group] or ""] .. "|r")
                lastGroup = b.group
            end
            local sp = b.spawns[1]
            local mark = s == "bag" and L[" |cffffd100(в сумке)|r"] or ""
            DEFAULT_CHAT_FRAME:AddMessage(string.format(L["  %s — %s %.1f, %.1f · сет %d%s"], BookName(b), ZoneName(sp[1]), sp[2], sp[3], b.set, mark))
        end
    end
end

function ns.PlayerWorld()
    if not (C_Map.GetBestMapForUnit and C_Map.GetPlayerMapPosition and C_Map.GetWorldPosFromMapPos) then return end
    local m = C_Map.GetBestMapForUnit("player")
    if not m then return end
    local p = C_Map.GetPlayerMapPosition(m, "player")
    if not p then return end
    local ok, cont, pos = pcall(C_Map.GetWorldPosFromMapPos, m, p)
    if ok and cont and pos then return cont, pos end
end

local function NextBook()
    local cont, pos = ns.PlayerWorld()
    local best, bestDist, firstTodo
    for _, e in ipairs(BuildEntries()) do
        if e.kind == "book" and Status(e.book) == "todo" then
            firstTodo = firstTodo or e
            if cont then
                local w = WorldPos(e)
                if w and w[1] == cont then
                    local px, py = pos:GetXY()
                    local bx, by = w[2]:GetXY()
                    local d = (px - bx) ^ 2 + (py - by) ^ 2
                    if not bestDist or d < bestDist then
                        best, bestDist = e, d
                    end
                end
            end
        end
    end
    local target = best or firstTodo
    if not target then
        Print(L["Все доступные книги уже взяты или сданы."])
        return
    end
    if best then
        Print(string.format(L["Ближайшая несданная книга, ~%d м:"], math.floor(math.sqrt(bestDist) + 0.5)))
    end
    WaypointTo(target)
end

local function AddAllToTomTom()
    if not (TomTom and TomTom.AddWaypoint) then
        Print(L["TomTom не найден. Без него используй клик по точке или /книги след."])
        return
    end
    local n = 0
    for _, e in ipairs(BuildEntries()) do
        if e.kind == "book" and Status(e.book) == "todo" then
            TomTom:AddWaypoint(e.map, e.x / 100, e.y / 100, { title = BookName(e.book), persistent = false, minimap = true, world = true })
            n = n + 1
        end
    end
    Print(string.format(L["Добавлено меток в TomTom: %d."], n))
end

local function Toggle(key, onText, offText)
    db[key] = not db[key]
    Print(db[key] and onText or offText)
    QueueRefresh()
end

local function Help()
    Print(L["Команды:"])
    DEFAULT_CHAT_FRAME:AddMessage(L["  /книги — прогресс и список несданных книг"])
    DEFAULT_CHAT_FRAME:AddMessage(L["  /книги след — метка на ближайшую несданную книгу"])
    DEFAULT_CHAT_FRAME:AddMessage(L["  /книги карта — вкл/выкл точки на карте"])
    DEFAULT_CHAT_FRAME:AddMessage(L["  /книги материк — точки на карте материка"])
    DEFAULT_CHAT_FRAME:AddMessage(L["  /книги сданные — скрыть/показать сданные"])
    DEFAULT_CHAT_FRAME:AddMessage(L["  /книги все — показать книги другой фракции"])
    DEFAULT_CHAT_FRAME:AddMessage(L["  /книги миникарта — точки на миникарте (нужен HereBeDragons, есть в Questie)"])
    DEFAULT_CHAT_FRAME:AddMessage(L["  /книги tomtom — все несданные книги в TomTom"])
    DEFAULT_CHAT_FRAME:AddMessage(L["  /гид — окно Путеводителя: подземелья, поиск вещей, книги"])
    DEFAULT_CHAT_FRAME:AddMessage(L["  /книги окно — вкладка «Книги» в окне · /книги выкл | вкл — выключить/включить книги"])
    DEFAULT_CHAT_FRAME:AddMessage(L["  Английские алиасы: /books list | next | map | continent | done | all | minimap | tomtom"])
end

local COMMANDS = {
    [""] = PrintList, ["список"] = PrintList, ["list"] = PrintList,
    ["след"] = NextBook, ["next"] = NextBook, ["ближайшая"] = NextBook,
    ["карта"] = function() Toggle("pins", L["Точки на карте включены."], L["Точки на карте выключены."]) end,
    ["map"] = function() Toggle("pins", L["Точки на карте включены."], L["Точки на карте выключены."]) end,
    ["материк"] = function() Toggle("continent", L["Точки на карте материка включены."], L["Точки на карте материка выключены."]) end,
    ["continent"] = function() Toggle("continent", L["Точки на карте материка включены."], L["Точки на карте материка выключены."]) end,
    ["сданные"] = function() Toggle("hideDone", L["Сданные книги скрыты."], L["Сданные книги снова видны."]) end,
    ["done"] = function() Toggle("hideDone", L["Сданные книги скрыты."], L["Сданные книги снова видны."]) end,
    ["все"] = function() Toggle("otherFaction", L["Показываю и книги другой фракции."], L["Книги другой фракции скрыты."]) end,
    ["all"] = function() Toggle("otherFaction", L["Показываю и книги другой фракции."], L["Книги другой фракции скрыты."]) end,
    ["миникарта"] = function() Toggle("minimap", L["Точки на миникарте включены."], L["Точки на миникарте выключены."]) end,
    ["minimap"] = function() Toggle("minimap", L["Точки на миникарте включены."], L["Точки на миникарте выключены."]) end,
    ["tomtom"] = AddAllToTomTom, ["томтом"] = AddAllToTomTom,
    ["помощь"] = Help, ["help"] = Help,
    ["данж"] = function() if ns.ToggleDungeons then ns.ToggleDungeons() end end,
    ["dungeons"] = function() if ns.ToggleDungeons then ns.ToggleDungeons() end end,
    ["подземелья"] = function() if ns.ToggleDungeons then ns.ToggleDungeons() end end,
}

SLASH_FOREVERGUIDE_BOOKS1 = "/книги"
SLASH_FOREVERGUIDE_BOOKS2 = "/books"
SLASH_FOREVERGUIDE_BOOKS3 = "/flb"
local function SetBooksEnabled(v)
    db.booksEnabled = v and true or false
    Print(v and L["Книги включены: точки на карте, миникарте и сообщения."] or L["Книги выключены: их нет на карте, миникарте и в чате. Включить: /книги вкл или вкладка «Книги» в окне /гид."])
    QueueRefresh()
    if ns.BooksRefresh then ns.BooksRefresh() end
end
ns.SetBooksEnabled = SetBooksEnabled
COMMANDS["вкл"] = function() SetBooksEnabled(true) end
COMMANDS["on"] = COMMANDS["вкл"]
COMMANDS["выкл"] = function() SetBooksEnabled(false) end
COMMANDS["off"] = COMMANDS["выкл"]
COMMANDS["окно"] = function() if ns.OpenBooks then ns.OpenBooks() end end
COMMANDS["window"] = COMMANDS["окно"]

SlashCmdList.FOREVERGUIDE_BOOKS = function(msg)
    local cmd = strtrim(string.lower(msg or ""))
    local fn = COMMANDS[cmd] or COMMANDS[msg and strtrim(msg) or ""]
    local raw = msg and strtrim(msg) or ""
    local always = { ["вкл"] = true, ["on"] = true, ["выкл"] = true, ["off"] = true, ["окно"] = true, ["window"] = true,
        ["данж"] = true, ["dungeons"] = true, ["подземелья"] = true, ["помощь"] = true, ["help"] = true }
    if not BooksOn() and not always[raw] and not always[cmd] then
        Print(L["Книги выключены. Включить: /книги вкл (или вкладка «Книги» в окне /гид)."])
        return
    end
    if fn then
        fn()
    else
        Help()
    end
end

---------------------------------------------------------------------------
-- Вкладка «Книги» в окне аддона
---------------------------------------------------------------------------

local booksPanel
local STATUS_COLOR = {
    done = { "Сдана", "|cff5fc48f" }, bag = { "В сумке — неси", "|cffffd100" },
    todo = { "Не взята", "|cffffffff" }, faction = { "Другая фракция", "|cffff6655" },
}

local function BookRows()
    local rows, lastGroup = {}, nil
    for _, b in ipairs(ns.BOOKS) do
        local s = Status(b)
        local show = true
        if s == "faction" and not db.otherFaction then show = false end
        if s == "done" and db.hideDone then show = false end
        if show then
            if b.group ~= lastGroup then
                rows[#rows + 1] = { kind = "head", text = L[ns.GROUPS[b.group] or ""] }
                lastGroup = b.group
            end
            local sp = b.spawns[1]
            rows[#rows + 1] = { kind = "book", book = b, status = s,
                entry = { kind = "book", book = b, map = sp[1], x = sp[2], y = sp[3], approx = sp[4] } }
        end
    end
    return rows
end

local function ProgressText()
    local done, bag, avail = Progress()
    local lib = Librarian()
    local goal
    if done >= GOAL_RING then
        goal = L["кольцо уже доступно — квест у библиотекаря"]
    elseif done >= GOAL_NECK then
        goal = string.format(L["шея доступна, до кольца %d"], GOAL_RING - done)
    else
        goal = string.format(L["до шеи %d, до кольца %d"], GOAL_NECK - done, GOAL_RING - done)
    end
    return string.format(L["Сдано |cff5fc48f%d|r · в сумке |cffffd100%d|r · доступно твоей фракции %d — %s.\nСдавать: %s, %s."], done, bag, avail, goal, L[lib.name], L[lib.place])
end

function ns.CreateBooksPanel(parent)
    local UI = ns._ui
    local p = CreateFrame("Frame", nil, parent)
    booksPanel = p
    local bg = ns.Skin.Panel(p)

    p.enable = UI.MakeCheck(p, L["Книги включены: точки на карте и миникарте, сообщения в чате"], function(v) SetBooksEnabled(v) end)
    p.enable:SetPoint("TOPLEFT", 8, -6)

    p.progress = p:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    p.progress:SetPoint("TOPLEFT", 12, -34)
    p.progress:SetPoint("RIGHT", -12, 0)
    p.progress:SetJustifyH("LEFT")

    local opts = {
        { "pins", L["На карте"] }, { "continent", L["На карте материка"] }, { "hideDone", L["Скрыть сданные"] },
        { "otherFaction", L["Другой фракции"] }, { "minimap", L["На миникарте"] },
    }
    p.opts = {}
    local prev
    for i, o in ipairs(opts) do
        local cb = UI.MakeCheck(p, o[2], function(v)
            db[o[1]] = v
            QueueRefresh()
            ns.BooksRefresh()
        end)
        if i == 1 then cb:SetPoint("TOPLEFT", 8, -68) else cb:SetPoint("LEFT", prev, "RIGHT", 140, 0) end
        cb.key = o[1]
        p.opts[i] = cb
        prev = cb
    end

    p.next = UI.MakeButton(p, L["Ближайшая книга"], 150, function() NextBook() end)
    p.next:SetPoint("TOPLEFT", 12, -96)
    p.tomtom = UI.MakeButton(p, L["Все несданные в TomTom"], 190, function() AddAllToTomTom() end)
    p.tomtom:SetPoint("LEFT", p.next, "RIGHT", 6, 0)
    p.lib = UI.MakeButton(p, L["Метка на библиотекаря"], 180, function()
        local lib = Librarian()
        WaypointTo({ kind = "librarian", lib = lib, map = lib.map, x = lib.x, y = lib.y })
    end)
    p.lib:SetPoint("LEFT", p.tomtom, "RIGHT", 6, 0)

    p.off = p:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    p.off:SetPoint("LEFT", p.lib, "RIGHT", 12, 0)
    p.off:SetPoint("RIGHT", -12, 0)
    p.off:SetJustifyH("LEFT")

    local function createRow(parentList)
        local r = CreateFrame("Button", nil, parentList)
        r.hl = ns.Skin.Hover(r)
        r.bg = ns.Skin.Head(r)
        r.icon = r:CreateTexture(nil, "ARTWORK")
        r.icon:SetSize(22, 22)
        r.icon:SetPoint("LEFT", 6, 0)
        r.badge = r:CreateTexture(nil, "OVERLAY")
        r.badge:SetSize(12, 12)
        r.badge:SetPoint("BOTTOMRIGHT", r.icon, "BOTTOMRIGHT", 3, -3)
        r.name = r:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        r.name:SetJustifyH("LEFT")
        r.name:SetWordWrap(false)
        r.status = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        r.status:SetPoint("TOPRIGHT", -8, -5)
        r.sub = r:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        r.sub:SetJustifyH("LEFT")
        r.sub:SetWordWrap(false)
        r:SetScript("OnClick", function(self) if self.data and self.data.entry then WaypointTo(self.data.entry) end end)
        r:SetScript("OnEnter", function(self) if self.data and self.data.entry then ShowTooltip(self, self.data.entry) end end)
        r:SetScript("OnLeave", function() GameTooltip:Hide() end)
        return r
    end
    local function updateRow(r, d)
        r.name:ClearAllPoints()
        r.sub:ClearAllPoints()
        if d.kind == "head" then
            r.bg:Show(); r.icon:Hide(); r.badge:Hide(); r.sub:SetText(""); r.status:SetText("")
            r.name:SetPoint("LEFT", 10, 0)
            r.name:SetPoint("RIGHT", -10, 0)
            r.name:SetText("|cffffd100" .. d.text .. "|r")
            return
        end
        r.bg:Hide()
        r.icon:Show()
        ApplyVisual(r.icon, r.badge, d.entry, true)
        r.name:SetPoint("TOPLEFT", r.icon, "TOPRIGHT", 8, 1)
        r.name:SetPoint("RIGHT", r.status, "LEFT", -8, 0)
        local st = STATUS_COLOR[d.status] or STATUS_COLOR.todo
        local b = d.book
        r.name:SetText((d.status == "done" and "|cff8a8a8a" or "|cffffffff") .. BookName(b) .. "|r")
        r.status:SetText(st[2] .. (d.status == "bag" and b.trainer and L["В сумке — неси учителю магии"] or L[st[1]]) .. "|r")
        r.sub:SetPoint("TOPLEFT", r.name, "BOTTOMLEFT", 0, -2)
        r.sub:SetPoint("RIGHT", -8, 0)
        local e = d.entry
        r.sub:SetText(string.format(L["%s %.1f, %.1f · сет %d%s"], ZoneName(e.map), e.x, e.y, b.set, e.approx and L[" · точка примерная"] or ""))
    end
    p.list = UI.CreateScrollList(p, 34, createRow, updateRow)
    p.list:SetPoint("TOPLEFT", 2, -124)
    p.list:SetPoint("BOTTOMRIGHT", -2, 2)
    return p
end

function ns.BooksRefresh()
    local p = booksPanel
    if not p or not p:IsShown() or not db then return end
    p.enable:SetChecked(BooksOn())
    for _, cb in ipairs(p.opts) do cb:SetChecked(db[cb.key] and true or false) end
    p.progress:SetText(ProgressText())
    p.off:SetText(BooksOn() and "" or L["Книги выключены — на карте и в чате их нет."])
    p.list:SetData(BookRows(), true)
end

---------------------------------------------------------------------------
-- События
---------------------------------------------------------------------------

local QUEST_TO_BOOK, ITEM_TO_BOOK = {}, {}
for _, b in ipairs(ns.BOOKS) do
    QUEST_TO_BOOK[b.quest] = b
    ITEM_TO_BOOK[b.item] = b
end

local bagState = {}
local function SnapshotBags(announce)
    for _, b in ipairs(ns.BOOKS) do
        local has = ItemCount(b.item) > 0
        if announce and has and not bagState[b.item] and db.announce and BooksOn() and Available(b) and not IsDone(b.quest) then
            local lib = TurnInNPC(b)
            Print(string.format(L["%s в сумке. Неси: %s, %s."], BookName(b), L[lib.name], L[lib.place]))
        end
        bagState[b.item] = has
    end
end

local frame = CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("PLAYER_LOGIN")
frame:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" then
        if arg1 == ADDON then
            ForeverGuideDB = ForeverGuideDB or {}
            db = ForeverGuideDB
            for k, v in pairs(DEFAULTS) do
                if db[k] == nil then db[k] = v end
            end
            -- язык аддона, выбранный игроком (иначе — язык клиента)
            -- (вызываем всегда: к этому моменту загружены и китайские названия)
            if ns.SetLanguage then ns.SetLanguage(db.lang or ns.CLIENT_LOCALE) end
            -- названия на остальных языках больше не нужны (смена языка — через /reload)
            if ns.DropUnusedLocales then ns.DropUnusedLocales() end
        elseif arg1 == "Blizzard_WorldMap" then
            AttachProvider()
        end
    elseif event == "PLAYER_LOGIN" then
        AttachProvider()
        for _, b in ipairs(ns.BOOKS) do ns.RequestItem(b.item) end
        self:RegisterEvent("PLAYER_ENTERING_WORLD")
        self:RegisterEvent("QUEST_TURNED_IN")
        self:RegisterEvent("QUEST_ACCEPTED")
        self:RegisterEvent("QUEST_REMOVED")
        self:RegisterEvent("BAG_UPDATE_DELAYED")
        SnapshotBags(false)
        local done = Progress()
        if not db.welcomed then
            db.welcomed = true
            Print(L["привет! Это помощник по Forever:"])
            DEFAULT_CHAT_FRAME:AddMessage(L["  • |cffffd100/гид|r или кнопка-карта у миникарты — окно с вкладками:"])
            DEFAULT_CHAT_FRAME:AddMessage(L["    «Подземелья» — квесты с цепочками и наградой, добыча боссов;"])
            DEFAULT_CHAT_FRAME:AddMessage(L["    «Поиск вещей» — откуда падает любая вещь и с каким шансом;"])
            DEFAULT_CHAT_FRAME:AddMessage(L["    «Профессии» — все рецепты Forever: реагенты, навык, где выучить;"])
            DEFAULT_CHAT_FRAME:AddMessage(L["    «Книги» — библиотечные книги на карте, их можно выключить."])
            DEFAULT_CHAT_FRAME:AddMessage(L["  • |cffffd100/найти <вещь>|r — сразу к поиску. Наведи на вещь — внизу подсказки видно, откуда она."])
            DEFAULT_CHAT_FRAME:AddMessage(L["  • Язык аддона: кнопка «Язык» в окне или |cffffd100/гид язык <код>|r (ru, en, de, fr, es, mx, pt, ko, zh, tw, авто)"])
            db.langHint = true
            db.langHint10 = true
        elseif not db.langHint10 then
            db.langHint = true
            db.langHint10 = true
            Print(L["теперь 10 языков: кнопка «Язык» в окне или |cffffd100/гид язык <код>|r (ru, en, de, fr, es, mx, pt, ko, zh, tw, авто)"])
        elseif BooksOn() then
            Print(string.format(L["готов. Книг сдано: %d. Окно: /гид"], done))
        else
            Print(L["готов. Окно: /гид"])
        end
        if ns.OnLogin then ns.OnLogin() end
    elseif event == "PLAYER_ENTERING_WORLD" then
        AttachProvider()
        QueueRefresh()
    elseif event == "QUEST_TURNED_IN" then
        if ns.OnQuestChanged then ns.OnQuestChanged() end
        if QUEST_TO_BOOK[arg1] and BooksOn() then
            C_Timer.After(1, function()
                PrintProgress()
                QueueRefresh()
            end)
        else
            QueueRefresh()
        end
    elseif event == "BAG_UPDATE_DELAYED" then
        SnapshotBags(true)
        QueueRefresh()
    else
        if ns.OnQuestChanged then ns.OnQuestChanged() end
        QueueRefresh()
    end
end)
